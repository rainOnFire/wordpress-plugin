"use strict";
var ajaxurl = ep_data2.ajaxurl;
var loader_image = ep_data2.loading_image;
function iv_save_post (){
		tinyMCE.triggerSave();
	
		jQuery('#update_message').html(loader_image);
		var search_params={
			"action"  : 	"ep_finaluser_save_wp_post",
			"form_data":	jQuery("#new_post").serialize(),
			"_wpnonce":  	ep_data2.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				if(response.code=='success'){
					var url = ep_data2.all_post_url;					
					jQuery(location).attr('href',url);
				}
			}
		});
	}
function iv_update_post (){
	tinyMCE.triggerSave();		
	jQuery('#update_message').html(loader_image);
	var search_params={
		"action"  : 	"ep_finaluser_update_wp_post",
		"form_data":	jQuery("#edit_post").serialize(),
		"_wpnonce":  	ep_data2.finalwpnonce,
	};
	jQuery.ajax({
		url : ajaxurl,
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			if(response.code=='success'){
				var url = ep_data2.all_post_url;
				jQuery(location).attr('href',url);
			}
		}
	});
}
function add_custom_field(){
	jQuery('#custom_field_div').append('<div class="row form-group "><div class=" col-md-6"> <input type="text" class="form-control" name="custom_name[]" id="custom_name[]" value="" placeholder="Custom Field Name"> </div><div  class=" col-md-6"><textarea name="custom_value[]" id="custom_value[]"  class="form-control  col-md-12"  rows="1" placeholder="Value"></textarea></div></div>');
}
function  remove_post_image	(profile_image_id){
	jQuery('#'+profile_image_id).html('');
	jQuery('#feature_image_id').val('');
	jQuery('#post_image_edit').html('<button type="button" onclick="edit_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Add</button>');
}
function edit_post_image(profile_image_id){
	var image_gallery_frame;
	image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
		title: ep_data2.set_Image,
		button: {
			text: ep_data2.set_Image,
		},
		multiple: false,
		displayUserSettings: true,
	});
	image_gallery_frame.on( 'select', function() {
		var selection = image_gallery_frame.state().get('selection');
		selection.map( function( attachment ) {
			attachment = attachment.toJSON();
			if ( attachment.id ) {
				jQuery('#'+profile_image_id).html('<img  class="img-responsive"  src="'+attachment.sizes.thumbnail.url+'">');
				jQuery('#feature_image_id').val(attachment.id );
				jQuery('#post_image_edit').html('<button type="button" onclick="edit_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Edit</button>&nbsp;<button type="button" onclick="remove_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Remove</button>');
			}
		});
	});
	image_gallery_frame.open();
}
jQuery(function() {
	jQuery('#cpt_page').on('change', function (e) {
		var optionSelected = jQuery("option:selected", this);
		var valueSelected = this.value;
		var search_params={
			"action"  : 	"ep_finaluser_cpt_change",
			"select_data":	valueSelected,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#select_cpt').html(response.msg );
				jQuery('#iv_tags').html(response.tags );
			}
		});
	});
});