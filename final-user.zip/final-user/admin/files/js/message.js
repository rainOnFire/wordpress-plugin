"use strict";
var ajaxurl = ep_data_message.ajaxurl;
var loader_image = ep_data_message.loading_image;

function make_as_delete(){
	var search_params={
		"action"  :  "ep_finaluser_make_as_delete",
		"form_data": jQuery("#message_form").serialize(),
		"_wpnonce":  	ep_data_message.finalwpnonce,
	};
	jQuery.ajax({
		url : ajaxurl,
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var searchIDs = jQuery('input:checked').map(function(){
				var tid = jQuery(this).val();
				jQuery('#tr'+tid).remove();
			});
		}
	});
}
function make_as_unread(){
	var search_params={
		"action"  :  "ep_finaluser_make_as_unread",
		"form_data": jQuery("#message_form").serialize(),
		"_wpnonce":  	ep_data_message.finalwpnonce,
	};
	jQuery.ajax({
		url : ajaxurl,
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var searchIDs = jQuery('input:checked').map(function(){
				var tid = jQuery(this).val();
				jQuery('#tr'+tid).addClass('unread');
			});
		}
	});
}
function make_as_read(){
	var search_params={
		"action"  :  "ep_finaluser_make_as_read",
		"form_data": jQuery("#message_form").serialize(),
		"_wpnonce":  	ep_data_message.finalwpnonce,
	};
	jQuery.ajax({
		url : ajaxurl,
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var searchIDs = jQuery('input:checked').map(function(){
				var tid = jQuery(this).val();
				jQuery('#tr'+tid).removeClass('unread').addClass('');
			});
		}
	});
}
function select_message_all(sel_name) {
	if(jQuery("#"+sel_name+"_all").prop("checked") == true){
		jQuery("."+sel_name).prop("checked",jQuery("#"+sel_name+"_all").prop("checked"));
		}else{
		jQuery("."+sel_name).prop("checked", false);
	}
}