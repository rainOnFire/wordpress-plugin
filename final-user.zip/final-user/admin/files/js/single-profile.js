"use strict";
var ajaxurl = tiger_data.ajaxurl;	
var loader_image =  tiger_data.loading_image;
function iv_submit_review(){
		var isLogged =tiger_data.current_user_id;

                if (isLogged=="0") {
                     alert(tiger_data.login_review);
                } else {
					var form = jQuery("#iv_review_form");
					if (jQuery.trim(jQuery("#review_comment", form).val()) == "") {
						  alert("Please put your comment");
					} else {					
					   jQuery('#rmessage').html(loader_image);
					   var search_params={
						 "action"  :  "ep_finaluser_save_user_review",
						 "form_data": jQuery("#iv_review_form").serialize(),
						 "_wpnonce":  tiger_data.finalwpnonce,
					   };
					   jQuery.ajax({
						 url : ajaxurl,
						 dataType : "json",
						 type : "post",
						 data : search_params,
						 success : function(response){
						  jQuery('#re_form').html('<div class="col-sm-7 alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');

						}
					  });
				}
			}

	}

jQuery(function() {
	jQuery("#city").on('keyup', function (e) {
		if (e.keyCode == 13) {
			this.form.submit();
		}
	});
});
jQuery(document).ready(function($) {
	var getWidth = jQuery('.bootstrap-wrapper').width();
	if (getWidth < 780) {
		jQuery('.bootstrap-wrapper').addClass('narrow-width');
		} else {
		jQuery('.bootstrap-wrapper').removeClass('narrow-width');
	}
});
jQuery(document).ready(function($) {
	jQuery('.specialties-popover').hide();
	jQuery(".js-selector p").on("click", function () {
		jQuery('.specialties-popover').toggle();
	});
});
function call_popup(dir_id){
	jQuery('#dir_id').val(dir_id);
	jQuery('#myModalContact').modal('show');
}
jQuery(document).ready(function()
	{
		jQuery('ul.specialties_list li').on("click", function (e) {
			var select_val= jQuery(this).text();
			jQuery('#specialties').val(jQuery.trim(select_val));
			jQuery('#selected_specialty').html(select_val);
			jQuery('#all_specialties').hide();			
			if(jQuery.trim(select_val)=="RESET"){
				jQuery('#specialties').val('');
				jQuery('#search_form').submit();
				}else{
				jQuery('#search_form').submit();
			}
		});
	});
	var page = 2;
	function finaluser_loadmore(){
		
		jQuery('#loadmore_message').html(loader_image); 
		var search_params={
			"action"  : 	"ep_finaluser_loadmore",	
			"page":	page, 		
			"postuser":	tiger_data.postuser, 
			"_wpnonce":  tiger_data.finalwpnonce,
		};				
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){											
				jQuery('#loadmore_message').html('');
				jQuery('#loadmore_fupost').append(response.msg );
				jQuery('#loadbutton').html(response.loadbutton);
				if(response.loadbutton==""){
					jQuery('#loadbuttondiv').html('');
				}
			}
		});
		page++;
	}	
	function modal_send_message_iv(){
		var formc = jQuery("#message-modal");
		if (jQuery.trim(jQuery("#message-content",formc).val()) == "") {
			alert("Please put your message");
			} else {    
			var ajaxurl = tiger_data.ajaxurl;	
			var loader_image =  tiger_data.loading_image;
			jQuery('#update_message_popup').html(loader_image); 
			var search_params={
				"action"  : 	"ep_finaluser_message_send",	
				"form_data":	jQuery("#message-modal").serialize(), 
				"_wpnonce":  tiger_data.finalwpnonce,
			};				
			jQuery.ajax({					
				url : ajaxurl,					 
				dataType : "json",
				type : "post",
				data : search_params,
				success : function(response){											
					jQuery('#update_message_popup').html(response.msg );
					jQuery("#message-modal").trigger('reset');						
				}
			});
		}	
	}
	function contact_send_message_iv(){
		var formc = jQuery("#contact_form_2");
		if (jQuery.trim(jQuery("#message-content",formc).val()) == "") {
			alert("Please put your message");
			} else {    
			var ajaxurl = tiger_data.ajaxurl;	
			var loader_image =  tiger_data.loading_image;
			jQuery('#update_message_popup').html(loader_image); 
			var search_params={
				"action"  : 	"ep_finaluser_message_send",	
				"form_data":	jQuery("#contact_form_2").serialize(), 
				"_wpnonce":  tiger_data.finalwpnonce,
			};				
			jQuery.ajax({					
				url : ajaxurl,					 
				dataType : "json",
				type : "post",
				data : search_params,
				success : function(response){											
					jQuery('#update_message_popup').html(response.msg );
					jQuery("#contact_form_2").trigger('reset');						
				}
			});
		}	
	}
	function send_message_claim(){	
		var isLogged = tiger_data.current_user_id;                            
     
		var form = jQuery("#message-claim");			
		if (jQuery.trim(jQuery("#message-content", form).val()) == "") {
			alert("Please put your message");
			} else {
			var ajaxurl = tiger_data.ajaxurl;	
			var loader_image =  tiger_data.loading_image;
			jQuery('#update_message_claim').html(loader_image); 
			var search_params={
				"action"  : 	"ep_finaluser_claim_send",	
				"form_data":	jQuery("#message-claim").serialize(), 
				"_wpnonce":  tiger_data.finalwpnonce,
			};				
			jQuery.ajax({					
				url : ajaxurl,					 
				dataType : "json",
				type : "post",
				data : search_params,
				success : function(response){ 											
					jQuery('#update_message_claim').html('   '+response.msg );
					jQuery("#message-claim").trigger('reset');
				}
			});
		}
	//}	
}
function save_follow(id) {   
	var following=tiger_data.following;
	var follow=tiger_data.follow;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;
		var search_params={
			"action"  : 	"uou_tigerp_save_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 
				jQuery("#epfollow").html('<button class="p-button contact" onclick="save_unfollow('+id+')" >'+following+'</button>');
			}
		});
	}  
}
function save_unfollow(id,spanid) {
	var following=tiger_data.following;
	var follow=tiger_data.follow;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;								
		var search_params={
			"action"  : 	"uou_tigerp_save_un_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 
				jQuery("#epfollow").html('<button class="p-button contact" onclick="save_follow('+id+')" >'+follow+'</button>');
			}
		});
	}  
}	    
function save_follow_popup(id,spanid) {    
	var following=tiger_data.following;
	var follow=tiger_data.follow;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;
		var search_params={
			"action"  : 	"uou_tigerp_save_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 								
				jQuery("#"+jQuery.trim(spanid)).html('<a class="button follow mini_follow" onclick="save_unfollow_popup('+id+',\''+spanid+'\')" >'+following+'</a>');
			}
		});
	}  
}
function save_unfollow_popup(id,spanid) {
	var following=tiger_data.following;
	var follow=tiger_data.follow;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;								
		var search_params={
			"action"  : 	"uou_tigerp_save_un_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 
				jQuery("#"+jQuery.trim(spanid)).html('<a  class="button follow mini_follow" onclick="save_follow_popup('+id+',\''+spanid+'\')" >'+follow+'</a>');
			}
		});
	}  
}	     
function save_follow_dir(id) {   
	var following=tiger_data.following;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;
		var search_params={
			"action"  : 	"uou_tigerp_save_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 
				jQuery("#follow"+id).html('<a  class="tirtiary-button" onclick="save_unfollow_dir('+id+')" >'+following+'</a>');
			}
		});
	}  
}
function save_unfollow_dir(id,spanid) {
	var follow=tiger_data.follow;
	var isLogged = tiger_data.current_user_id;
	if (isLogged=="0") {                   
		alert(tiger_data.login_follw);
		} else { 
		var ajaxurl = tiger_data.ajaxurl;								
		var search_params={
			"action"  : 	"uou_tigerp_save_un_follow",	
			"data": "id=" + id,
			"_wpnonce":  tiger_data.finalwpnonce,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){ 
				jQuery("#follow"+id).html('<a  class="tirtiary-button"  onclick="save_follow_dir('+id+')" >'+follow+'</a>');
			}
		});
	}  
    }	    	