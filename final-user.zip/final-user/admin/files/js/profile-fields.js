"use strict";
var ajaxurl = ep_data5.ajaxurl;
var loader_image = ep_data5.loading_image;
	var i=ep_data5.i;
	var ii=ep_data5.ii;
	function update_profile_fields(){
		
		var search_params = {
			"action": 		"ep_finaluser_update_profile_fields",
			"form_data":	jQuery("#profile_fields").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url: ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {
				jQuery('#success_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');
				var url = ep_data5.url10;
				jQuery(location).attr('href',url);
			}
		});
	}
	function iv_add_field(){
		jQuery('#custom_field_div').append('<div class="row form-group " id="field_'+i+'"><div class=" col-sm-4"> <input type="text" class="form-control" name="meta_name[]" id="meta_name[]" value="" placeholder="Enter User Meta Name "> </div>	<div  class=" col-sm-4"><input type="text" class="form-control" name="meta_label[]" id="meta_label[]" value="" placeholder="Enter User Meta Label"></div><div  class=" col-sm-1"><label> </label></div> <div  class="checkbox col-sm-1"><label></label></div> <div  class=" checkbox col-sm-2"><button class="btn btn-danger btn-xs" onclick="return iv_remove_field('+i+');">Delete</button>');
		i=i+1;
	}
	function iv_remove_field(div_id){
		jQuery("#field_"+div_id).remove();
	}
	function iv_add_menu(){
		jQuery("#menu_custom_main").clone().appendTo("#custom_menu_div");
		ii=ii+1;
	}
	function iv_remove_menu(div_id){
		jQuery("#menu_"+div_id).remove();
	}
	// Tab
	function iv_add_tab(){
		jQuery("#tab_custom_main").clone().appendTo("#custom_tab_div");
		ii=ii+1;
	}
	function iv_remove_tab(div_id){
		jQuery("#tab"+div_id).remove();
	}