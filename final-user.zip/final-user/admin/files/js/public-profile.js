"use strict";
function call_popup_profile(){	
	jQuery('#myModalContact').modal('show');
}
function call_popup_report(){	
	jQuery('#myModalreport').modal('show');
}
jQuery(document).ready(function($) {
    jQuery('.specialties-popover').hide();
    var reportPopUp = jQuery('.p-report-button .specialties-popover');
    var sharePopUp = jQuery('.p-share-button .specialties-popover');
    jQuery(".p-report-button button").on("click", function () {
      console.log("clicked");
      jQuery(this).next('.specialties-popover').toggle();
      if(sharePopUp.show()) {
        sharePopUp.hide();
      }
    });

    jQuery(".p-share-button button").on("click", function () {
      jQuery(this).next('.specialties-popover').toggle();
      if(reportPopUp.show()) {
        reportPopUp.hide();
      }
    });


    jQuery('.p-photo-block .row').masonry({
      // set itemSelector so .grid-sizer is not used in layout
      itemSelector: '.col-sm-6',
      // use element for option
      columnWidth: '.col-md-4',
      percentPosition: true
    })
  });
 function photo_action() {
		 jQuery('.p-photo-block .row').masonry({
			  // set itemSelector so .grid-sizer is not used in layout
			  itemSelector: '.col-sm-6',
			  // use element for option
			  columnWidth: '.col-md-4',
			  percentPosition: true
			})
	}

jQuery(function() {
    jQuery("#tabphotos").on("click", function () {
        setTimeout(photo_action, 500);
    });
     jQuery("#tabvideos").on("click", function () {

        setTimeout(photo_action, 200);
    });

});

jQuery(".nav-tabs a").on("click", function (){
     jQuery(this).tab('show');
 });