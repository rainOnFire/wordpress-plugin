"use strict";
jQuery('document').ready(function($){
	var commentform=$('#commentform'); 
	commentform.prepend('<div id="comment-status" ></div>'); 
	var statusdiv=$('#comment-status'); 
	commentform.on("submit", function(){
		
		var formdata=commentform.serialize();
	
		statusdiv.html('<p>'+tiger_data.Processing+'</p>');
	
		var formurl=commentform.attr('action');

		$.ajax({
			type: 'post',
			url: formurl,
			data: formdata,
			error: function(XMLHttpRequest, textStatus, errorThrown)
			{
				statusdiv.html('<p class="ajax-error" >'+tiger_data.quickly+'</p>');
			},
			success: function(data, textStatus){
				if(data == "success" || textStatus == "success"){
					statusdiv.html('<p class="ajax-success" >'+tiger_data.thanks+'</p>');
					jQuery('#commentform').reset();
					}else{
					statusdiv.html('<p class="ajax-error" >'+tiger_data.pleasewait+'</p>');
					commentform.find('textarea[name=comment]').val('');
				}
			}
		});
		return false;
	});
});