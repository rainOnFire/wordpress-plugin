"use strict";
var ajaxurl = ep_data.ajaxurl;
var loader_image = ep_data.loading_image;
var pdf_image =ep_data.pdf_image;

jQuery(function(){	
	jQuery('#package_sel').on('change', function (e) {
		var optionSelected = jQuery("option:selected", this);
		var pack_id = this.value;
		jQuery("#package_id").val(pack_id);
		var ajaxurl = ep_data.ajaxurl;
		var search_params={
			"action"  			: "ep_finaluser_check_package_amount",	
			"coupon_code" 		:jQuery("#coupon_name").val(),
			"package_id" 		: pack_id,
			"package_amount" 	:ep_data.package_amount,
			"api_currency" 		:ep_data.currencyCode,
			"_wpnonce"				: ep_data.signup,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				if(response.code=='success'){							
					jQuery('#coupon-result').html(ep_data.right_icon);
					}else{
					jQuery('#coupon-result').html(ep_data.wrong_16x16);
				}
				jQuery('#p_amount').html(response.p_amount);							
				jQuery('#total').html(response.gtotal);
				jQuery('#discount').html(response.dis_amount);
			}
		});
	});	
});	


function update_profile_shipping (){	
		jQuery('#update_message').html(loader_image);
		var search_params={
			"action"  : 	"ep_finaluser_update_profile_shipping",
			"form_data":	jQuery("#profile_setting_form").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){

				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');

			}
		});

	}
function update_profile_billing (){		
		jQuery('#update_message').html(loader_image);
		var search_params={
			"action"  : 	"ep_finaluser_update_profile_billing",
			"form_data":	jQuery("#profile_setting_form").serialize(),
			 "_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
function remove_video(remove_div){
	jQuery('#'+remove_div).remove();
}
function addVideo(type){
	var typeicon="flaticon-technology-1";
	jQuery('#videosD').append('<div class="col-md-12"><span style="margin-left:-20px"><i class="'+typeicon+'" aria-hidden="true"></i></span><input type="text" name="'+type+'[]" id="'+type+'[]"  placeholder="add '+type+' full link" class="form-control"/></div>');
}
function update_videos (){	  
	   jQuery('#update_message_gallery').html(loader_image);
	   var search_params={
		 "action"  :  "ep_finaluser_update_profile_videos",
		 "form_data": jQuery("#profile_videos").serialize(),
		 "_wpnonce":  	ep_data.finalwpnonce,
	   };
	   jQuery.ajax({
		 url : ajaxurl,
		 dataType : "json",
		 type : "post",
		 data : search_params,
		 success : function(response){
		  jQuery('#update_message_gallery').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');

		}
	  });
}
jQuery(window).on('load',function(){
	if (jQuery("#user-data")[0]){	
		jQuery('#user-data').show();
		var oTable = jQuery('#user-data').dataTable();
		oTable.fnSort( [ [1,'DESC'] ] );
	}
});
	
jQuery(document).ready(function() {
		jQuery(".menu-click-button a").on("click", function(e) {
			e.preventDefault();
			jQuery(this).toggleClass('active');
			jQuery(".sidebar-area").toggleClass("active");
		});
	})
	function ep_save_facebooksetting(){		
		jQuery('#messagefacebook').html(loader_image);
		var search_params={
			"action"  :  "ep_finaluser_save_facebooksetting",
			"form_data": jQuery("#facebooksetting").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#messagefacebook').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function ep_send_compose (){		
		jQuery('#sent_message').html(loader_image);
		var message= jQuery('#replycontent').val();
		var search_params={
			"action"  :  "ep_finaluser_inbox_message_sent",
			"form_data": jQuery("#messagereplyform").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#sent_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
				jQuery('#replycontent').val('');
				jQuery('#to_user_ids').html('');
				jQuery('#mail_subject').val('');
			}
		});
	}
	function ep_send_message (){		
		jQuery('#sent_message').html(loader_image);
		var message= jQuery('#replycontent').val();
		var search_params={
			"action"  :  "ep_finaluser_inbox_message_reply",
			"form_data": jQuery("#messagereplyform").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#sent_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
				jQuery('#save_message').html('<div class="row"><div class="col-md-1"></div><div class="col-md-10">'+message+'</div><div class="col-md-1"></div></div><hr/>');
				jQuery('#replycontent').val('');
			}
		});
	}
	jQuery(document).ready(function($) {
		var getWidth = jQuery('.bootstrap-wrapper').width();
		if (getWidth < 780) {
			jQuery('.bootstrap-wrapper').addClass('narrow-width');
			} else {
			jQuery('.bootstrap-wrapper').removeClass('narrow-width');
		}
	});
	function edit_background_image(profile_image_id){
		var image_gallery_frame;
		image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
			// Set the title of the modal.
			title:  ep_data.Backgroung_Image,
			button: {
				text: ep_data.Backgroung_Image,
			},
			multiple: false,
			displayUserSettings: true,
		});
		image_gallery_frame.on( 'select', function() {
			var selection = image_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();
				if ( attachment.id ) {				
					var search_params = {
						"action":   "ep_finaluser_update_background_pic",
						"attachment_thum": attachment.sizes.thumbnail.url,
						"profile_pic_url_1": attachment.url,
						"finaluser_background_id" : attachment.id ,
						
					};
					jQuery.ajax({
						url: ajaxurl,
						dataType: "json",
						type: "post",
						data: search_params,
						success: function(response) {
							if(response=='success'){
								jQuery('#'+profile_image_id).html('<img  class=""  src="'+attachment.sizes.thumbnail.url+'">');
							}
						}
					});
				}
			});
		});
		image_gallery_frame.open();
	}
	function edit_profile_image(profile_image_id){
		var image_gallery_frame;
		image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
			
			title: ep_data.Profile_Image,
			button: {
				text: ep_data.Profile_Image,
			},
			multiple: false,
			displayUserSettings: true,
		});
		image_gallery_frame.on( 'select', function() {
			var selection = image_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();
				if ( attachment.id ) {				
					var search_params = {
						"action":   "ep_finaluser_update_profile_pic",
						"attachment_thum": attachment.sizes.thumbnail.url,
						"profile_pic_url_1": attachment.url,
					};
					jQuery.ajax({
						url: ajaxurl,
						dataType: "json",
						type: "post",
						data: search_params,
						success: function(response) {
							if(response=='success'){
								jQuery('#'+profile_image_id).html('<img  class=""  src="'+attachment.sizes.thumbnail.url+'">');
							}
						}
					});
				}
			});
		});
		image_gallery_frame.open();
	}
	function update_profile_setting (){	
		jQuery('#update_message').html(loader_image);
		var search_params={
			"action"  :  "ep_finaluser_update_profile_setting",
			"form_data": jQuery("#profile_setting_form").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function update_gallery_images (){		
		jQuery('#update_message_gallery').html(loader_image);
		var search_params={
			"action"  :  "ep_finaluser_update_profile_gallery_image",
			"form_data": jQuery("#profile_image_gallery").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message_gallery').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function iv_update_password (){	
		jQuery('#update_message_pass').html(loader_image);
		var search_params={
			"action"  :  "ep_finaluser_update_setting_password",
			"form_data": jQuery("#pass_word").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message_pass').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function edit_gallery_image(profile_image_id){
		var image_gallery_frame;
		var hidden_field_image_ids = jQuery('#gallery_image_ids').val();
		image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
			
			title:  'Gallery Images ',
			button: {
				text:  'Gallery Images',
			},
			multiple: true,
			displayUserSettings: true,
		});
		image_gallery_frame.on( 'select', function() {
			var selection = image_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();
				console.log(attachment);
				if ( attachment.id ) {
					jQuery('#'+profile_image_id).append('<div id="gallery_image_div'+attachment.id+'" class="col-md-3"><img  class="img-responsive"  src="'+attachment.sizes.thumbnail.url+'"><button type="button" onclick="remove_gallery_image(\'gallery_image_div'+attachment.id+'\', '+attachment.id+');"  class="btn btn-xs btn-danger">X</button> </div>');
					hidden_field_image_ids=hidden_field_image_ids+','+attachment.id ;
					jQuery('#gallery_image_ids').val(hidden_field_image_ids);
				}
			});
		});
		image_gallery_frame.open();
	}
	function  remove_gallery_image(img_remove_div,rid){
		var hidden_field_image_ids = jQuery('#gallery_image_ids').val();
		hidden_field_image_ids =hidden_field_image_ids.replace(rid, '');
		jQuery('#'+img_remove_div).remove();
		jQuery('#gallery_image_ids').val(hidden_field_image_ids);
	}
	//*****DOC Start****************
	function update_profile_doc (){	
		jQuery('#update_message_gallery').html(loader_image);
		var search_params={
			"action"  :  "ep_finaluser_update_profile_doc",
			"form_data": jQuery("#profile_image_gallery").serialize(),
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message_doc').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function edit_gallery_doc(profile_doc_id){
		
		var image_gallery_frame;
		var hidden_field_image_ids = jQuery('#gallery_doc_ids').val();
		image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
		
			title:  'PDF Doc ',
			button: {
				text:  'PDF DOC',
			},
			multiple: true,
			library: {type: 'application/pdf',},
			displayUserSettings: true,
		});
		image_gallery_frame.on( 'select', function() {
			var selection = image_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();
				console.log(attachment);
				if ( attachment.id ) {
					jQuery('#'+profile_doc_id).append('<div id="gallery_doc_div'+attachment.id+'" class="col-md-3"><img  class="img-responsive"  src="'+pdf_image+'"><button type="button" onclick="remove_gallery_doc(\'gallery_doc_div'+attachment.id+'\', '+attachment.id+');"  class="btn btn-xs btn-danger">X</button> </div>');
					hidden_field_image_ids=hidden_field_image_ids+','+attachment.id ;
					jQuery('#gallery_doc_ids').val(hidden_field_image_ids);
				}
			});
		});
		image_gallery_frame.open();
	}
	function  remove_gallery_doc(img_remove_div,rid){
		var hidden_field_image_ids = jQuery('#gallery_doc_ids').val();
		hidden_field_image_ids =hidden_field_image_ids.replace(rid, '');
		jQuery('#'+img_remove_div).remove();
		jQuery('#gallery_doc_ids').val(hidden_field_image_ids);
	}
	//******DOC End***********
	function remove_language(remove_div){
		jQuery('#'+remove_div).remove();
	}
	function remove_camera(remove_div){
		jQuery('#'+remove_div).remove();
	}
	function addGear(type){
		if(type=='camera'){var typeicon="flaticon-technology-1";}
		if(type=='lens'){var typeicon="flaticon-technology";}
		if(type=='misc'){var typeicon="flaticon-electricity";}
		jQuery('#gears').append('<span style="margin-left:-20px"><i class="'+typeicon+'" aria-hidden="true"></i></span><input type="text" name="'+type+'[]" id="'+type+'[]"  placeholder="add Expertise" class="form-control"/>');
	}
	function add_language(){
		var language_one =jQuery('#language_one').html();
		jQuery('#languages_all').append('<div class="clearfix"></div><hr>'+language_one+'');
	}
	function ep_remove_notification(){
		jQuery('#notification_message').html(loader_image);
		var search_params={
			"action"  : 	"ep_remove_notification",
			"_wpnonce":  	ep_data.finalwpnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#all_notifications').remove();
			}
		});
	}