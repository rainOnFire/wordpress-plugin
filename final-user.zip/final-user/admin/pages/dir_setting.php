<h3  class=""><?php esc_html_e('Directory Setting','finaluser');  ?><small></small>
</h3>
<br/>
<div id="update_message"> </div>
<form class="form-horizontal" role="form"  name='directory_settings' id='directory_settings'>
	<h4><?php esc_html_e('Profile Archive Page','finaluser');  ?> </h4>
	<hr>
	<?php
		$dir_approve_publish =get_option('_dir_approve_publish');
		$dir_archive=get_option('_dir_archive_page');
		if($dir_approve_publish==""){$dir_approve_publish='no';}
		$dir_claim_show=get_option('_dir_claim_show');
		if($dir_claim_show==""){$dir_claim_show='yes';}
	?>
	<?php
		$listing_author_link=get_option('listing_author_link');
		if($listing_author_link==""){$listing_author_link='author';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('User Profile Page link','finaluser');  ?></label>
		<div class="col-md-3">
			<label>
				<input type="radio" name="listing_author_link" id="listing_author_link" value='author' <?php echo ($listing_author_link=='author' ? 'checked':'' ); ?> >
				<?php echo get_author_posts_url('1'); ?>
			</label>
		</div>
		<div class="col-md-3">
			<label>
				<input type="radio"  name="listing_author_link" id="listing_author_link" value='link' <?php echo ($listing_author_link=='link' ? 'checked':'' );  ?> >
				<?php
					$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
					$reg_page_user='';
					if($iv_redirect_user!='defult'){
						$reg_page_user= get_permalink( $iv_redirect_user) ;
					}
				echo esc_url($reg_page_user); ?>?id=1
			</label>
		</div>
	</div>
	<?php
		$dir_listing_sort=get_option('_dir_listing_sort');
		if($dir_listing_sort==""){$dir_listing_sort='date';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Listings Order','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="dir_listing_sort" id="dir_listing_sort" value='date' <?php echo ($dir_listing_sort=='date' ? 'checked':'' ); ?> ><?php esc_html_e('Published Date','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="dir_listing_sort" id="dir_listing_sort" value='ASC' <?php echo ($dir_listing_sort=='ASC' ? 'checked':'' );  ?> > <?php esc_html_e('Alphabetically A-Z','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="dir_listing_sort" id="dir_listing_sort" value='DESC' <?php echo ($dir_listing_sort=='DESC' ? 'checked':'' );  ?> > <?php esc_html_e('Alphabetically Z-A','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$dir_display_status=get_option('_dir_display_status');
		if($dir_display_status==""){$dir_display_status='all';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Listings Display Status','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="dir_display_status" id="dir_display_status" value='publish' <?php echo ($dir_display_status=='publish' ? 'checked':'' ); ?> ><?php esc_html_e('Only Publish User','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="dir_display_status" id="dir_display_status" value='all' <?php echo ($dir_display_status=='all' ? 'checked':'' );  ?> > <?php esc_html_e('All Users','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$admin_approve_status=get_option('_admin_approve_status');
		if($admin_approve_status==""){$admin_approve_status='no';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Listings Approve By Admin','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="admin_approve_status" id="admin_approve_status" value='yes' <?php echo ($admin_approve_status=='yes' ? 'checked':'' ); ?> ><?php esc_html_e('Yes. Admin Will Approve','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="admin_approve_status" id="admin_approve_status" value='no' <?php echo ($admin_approve_status=='no' ? 'checked':'' );  ?> > <?php esc_html_e('No Need to Approve','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$user_email_address=get_option('_arch_emailaddress');
		if($user_email_address==""){$user_email_address='yes';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('User Email Address','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="user_email_address" id="user_email_address" value='yes' <?php echo ($user_email_address=='yes' ? 'checked':'' ); ?> ><?php esc_html_e('Show','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="user_email_address" id="user_email_address" value='no' <?php echo ($user_email_address=='no' ? 'checked':'' );  ?> > <?php esc_html_e('Hide','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$user_email_phone=get_option('_arch_user_phone');
		if($user_email_phone==""){$user_email_phone='yes';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('User Phone Number','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="user_email_phone" id="user_email_phone" value='yes' <?php echo ($user_email_phone=='yes' ? 'checked':'' ); ?> ><?php esc_html_e('Show','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="user_email_phone" id="user_email_phone" value='no' <?php echo ($user_email_phone=='no' ? 'checked':'' );  ?> > <?php esc_html_e('Hide','finaluser');  ?>
			</label>
		</div>
	</div>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Specialties ','finaluser');  ?></label>
		<?php
			$specialties=get_option('_dir_specialties');
			if($specialties==""){$specialties='Aerial, Architecture, Automotive, Event, Fashion, Food, Interior, Lifestye, Maternity,Newborns, Nature, Land';}
		?>
		<div class="col-md-6">
			<label>
				<textarea   name="specialties" id="specialties"  rows="10" cols="100" ><?php echo esc_html($specialties);?> </textarea>
			</label>
		</div>
	</div>
	<h4><?php esc_html_e('Profile Options','finaluser');  ?> </h4>
	<hr>
	<?php
		$profile_buddypress_image=get_option('_profile_buddypress_image');
		if($profile_buddypress_image==""){$profile_buddypress_image='pluginimage';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Image + Cover Image ','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_buddypress_image" id="profile_buddypress_image" value='pluginimage' <?php echo ($profile_buddypress_image=='pluginimage' ? 'checked':'' ); ?> ><?php esc_html_e('Use Plugin image','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_buddypress_image" id="profile_buddypress_image" value='buddypressimage' <?php echo ($profile_buddypress_image=='buddypressimage' ? 'checked':'' );  ?> > <?php esc_html_e('Use BuddyPress image','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_tab_active=get_option('_profile_tab_active');
		if($profile_tab_active==""){$profile_tab_active='photo';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Active Tab','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_tab_active" id="profile_tab_active" value='photo' <?php echo ($profile_tab_active=='photo' ? 'checked':'' ); ?> ><?php esc_html_e('Photo','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_tab_active" id="profile_tab_active" value='service' <?php echo ($profile_tab_active=='service' ? 'checked':'' );  ?> > <?php esc_html_e('Service','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_photo=get_option('_profile_photo');
		if($profile_photo==""){$profile_photo='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Photos','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_photo" id="profile_photo" value='show' <?php echo ($profile_photo=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Photos','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_photo" id="profile_photo" value='hide' <?php echo ($profile_photo=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Photos','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_service=get_option('_profile_service');
		if($profile_service==""){$profile_service='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Service','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_service" id="profile_service" value='show' <?php echo ($profile_service=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Service','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_service" id="profile_service" value='hide' <?php echo ($profile_service=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Service','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_follow=get_option('_profile_follow');
		if($profile_follow==""){$profile_follow='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Follow','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_follow" id="profile_follow" value='show' <?php echo ($profile_follow=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Follow','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_follow" id="profile_follow" value='hide' <?php echo ($profile_follow=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Follow','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_contact=get_option('_profile_contact');
		if($profile_contact==""){$profile_contact='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Contact','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_contact" id="profile_contact" value='show' <?php echo ($profile_contact=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Contact','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_contact" id="profile_contact" value='hide' <?php echo ($profile_contact=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Contact','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_map=get_option('_profile_map');
		if($profile_map==""){$profile_map='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Map','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_map" id="profile_map" value='show' <?php echo ($profile_map=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Map','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_map" id="profile_map" value='hide' <?php echo ($profile_map=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Map','finaluser');  ?>
			</label>
		</div>
	</div>
	<?php
		$profile_report=get_option('_profile_report');
		if($profile_report==""){$profile_report='show';}
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Profile Report','finaluser');  ?></label>
		<div class="col-md-2">
			<label>
				<input type="radio" name="profile_report" id="profile_report" value='show' <?php echo ($profile_report=='show' ? 'checked':'' ); ?> ><?php esc_html_e('Show Report','finaluser');  ?>
			</label>
		</div>
		<div class="col-md-2">
			<label>
				<input type="radio"  name="profile_report" id="profile_report" value='hide' <?php echo ($profile_report=='hide' ? 'checked':'' );  ?> > <?php esc_html_e('Hide Report','finaluser');  ?>
			</label>
		</div>
	</div>
	<h4><?php esc_html_e('Color Options','finaluser');  ?> </h4>
	<hr>
	<?php
		$dir_color=get_option('_dir_color');
		if($dir_color==""){$dir_color='#0099e5';}
		$dir_color=str_replace('#','',$dir_color);
	?>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Plugin Color','finaluser');  ?></label>
		<div class="col-md-6">
			<label>
				<input type="color" name="dir_color" id="dir_color" value='#<?php echo esc_html($dir_color);?>' >
			</label>
		</div>
	</div>
	<div class="form-group">
		<label  class="col-md-3 control-label"> <?php esc_html_e('Cron Job URL','finaluser');  ?>
		</label>
		<div class="col-md-6">
			<label>
				<b> <a href="<?php echo admin_url('admin-ajax.php'); ?>?action=ep_finaluser_cron_job"><?php echo admin_url('admin-ajax.php'); ?>?action=ep_finaluser_cron_job </a></b>
			</label>
		</div>
		<div class="col-md-3">
			<?php esc_html_e('Cron JOB Detail : Hide Listing( Package setting),Subscription Remainder email.', 'finaluser'); ?>
		</div>
	</div>
	<div class="form-group">
		<label  class="col-md-3 control-label"> </label>
		<div class="col-md-8">
			<button type="button" onclick="return  iv_update_dir_setting();" class="btn btn-success"><?php esc_html_e('Update', 'finaluser'); ?></button>
		</div>
	</div>
</form>
