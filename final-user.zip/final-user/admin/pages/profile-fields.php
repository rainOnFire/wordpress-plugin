<?php
	global $wpdb;
	global $current_user;
	$ii=1;
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-xs-12" id="submit-button-holder">
				<div class="pull-right"><button class="btn btn-info btn-lg" onclick="return update_profile_fields();"><?php esc_html_e('Update','finaluser');?> </button>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12"><h3 class="page-header"><?php esc_html_e('Update Profile Setting','finaluser');?> <br /><small> &nbsp;</small> </h3>
			</div>
		</div>
		<form id="profile_fields" name="profile_fields" class="form-horizontal" role="form" onsubmit="return false;">
			<div id="success_message">	</div>
			<div class="panel panel-success">
				<div class="panel-heading"><h4> <?php esc_html_e('My Account Menu','finaluser');?> </h4></div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-3" >	<h4><?php esc_html_e('My Account Title','finaluser');?></h4>
						</div>
						<div class="col-md-4" >
							<?php
								$account_menu_text=esc_html__( 'YOUR DETAILS','finaluser');
								if( get_option( '_ep_finaluser_menutop_title' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menutop_title');
								}
							?>
						<input type="text"  name="menutop_title" value="<?php echo esc_html($account_menu_text);?>"></td>
					</div>
				</div>
				<?php
					$active_tab=get_option('_myaccount_active_tab');
					$profile_page=get_option('_ep_finaluser_profile_page');
					$page_link= get_permalink( $profile_page);
				?>
				<table class="table table-hover">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e('#','finaluser'); ?></th>
							<th scope="col"><?php esc_html_e('Show/Hide','finaluser');?></th>
							<th scope="col"><?php esc_html_e('Active Tab','finaluser');?></th>
							<th scope="col"><?php esc_html_e('Menu Title / Label','finaluser');?></th>
							<th scope="col"><?php esc_html_e('Link','finaluser');?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th scope="row"></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_menuhome' ) ) {
									$account_menu_check= get_option('_ep_finaluser_menuhome');
								}
								$account_menu_text=esc_html__( 'Home','finaluser');
								if( get_option( '_ep_finaluser_menuhome_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menuhome_text');
								}
							?>
							<input type="checkbox" name="menuhome" id="menuhome" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								--
							</td>
							<td><input type="text"  name="textmenuhome" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>">
									<?php echo esc_url($page_link); ?>
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('1','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_mylevel' ) ) {
									$account_menu_check= get_option('_ep_finaluser_mylevel');
								}
								$account_menu_text=esc_html__( 'Upgrade My Account','finaluser');
								if( get_option( '_ep_finaluser_mylevel_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_mylevel_text');
								}
							?>
							<input type="checkbox" name="mylevel" id="mylevel" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='level')? 'checked':'' ?> value="level">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmylevel" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=level">
									<?php echo esc_url($page_link); ?>?&profile=level
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('2','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_menusetting' ) ) {
									$account_menu_check= get_option('_ep_finaluser_menusetting');
								}
								$account_menu_text=esc_html__( 'My Profile','finaluser');
								if( get_option( '_ep_finaluser_menusetting_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menusetting_text');
								}
							?>
							<input type="checkbox" name="menusetting" id="menusetting" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='setting')? 'checked':'' ?> value="setting">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmenusetting" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=setting">
									<?php echo esc_url($page_link); ?>?&profile=setting
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('3','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_menumyposts' ) ) {
									$account_menu_check= get_option('_ep_finaluser_menumyposts');
								}
								$account_menu_text=esc_html__( 'My Posts','finaluser');
								if( get_option( '_ep_finaluser_menumyposts_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menumyposts_text');
								}
							?>
							<input type="checkbox" name="menuposts" id="menuposts" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								--
							</td>
							<td><input type="text"  name="textmenuposts" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=all-posts">
									<?php echo esc_url($page_link); ?>?&profile=all-posts
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('4','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_menuallposts' ) ) {
									$account_menu_check= get_option('_ep_finaluser_menuallposts');
								}
								$account_menu_text=esc_html__( 'All Posts','finaluser');
								if( get_option( '_ep_finaluser_menuallposts_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menuallposts_text');
								}
							?>
							<input type="checkbox" name="menuallposts" id="menuallposts" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='all-posts')? 'checked':'' ?> value="all-posts">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmenuallposts" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=all-posts">
									<?php echo esc_url($page_link); ?>?&profile=all-posts
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('5','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_menunewpost' ) ) {
									$account_menu_check= get_option('_ep_finaluser_menunewpost');
								}
								$account_menu_text=esc_html__( 'Add New Post','finaluser');
								if( get_option( '_ep_finaluser_menunewpost_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_menunewpost_text');
								}
							?>
							<input type="checkbox" name="menunewpost" id="menunewpost" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='new-post')? 'checked':'' ?> value="new-post">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmenunewpost" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=new-post">
									<?php echo esc_url($page_link); ?>?&profile=new-post
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('6','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_images' ) ) {
									$account_menu_check= get_option('_ep_finaluser_images');
								}
								$account_menu_text=esc_html__( 'My Photos','finaluser');
								if( get_option( '_ep_finaluser_images_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_images_text');
								}
							?>
							<input type="checkbox" name="setting_images" id="setting_images" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='images')? 'checked':'' ?> value="images">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmenuphotos" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=images">
									<?php echo esc_url($page_link); ?>?&profile=images
								</a>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e('7','finaluser'); ?></th>
							<td><?php
								$account_menu_check='';
								if( get_option( '_ep_finaluser_videos' ) ) {
									$account_menu_check= get_option('_ep_finaluser_videos');
								}
								$account_menu_text=esc_html__( 'My Videos','finaluser');
								if( get_option( '_ep_finaluser_videos_text' ) ) {
									$account_menu_text= get_option('_ep_finaluser_videos_text');
								}
							?>
							<input type="checkbox" name="setting_videos" id="setting_videos" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
							</td>
							<td>
								<label>
									<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='videos')? 'checked':'' ?> value="videos">
									<?php esc_html_e('Active','finaluser');?>
								</label>
							</td>
							<td><input type="text"  name="textmenuvideos" value="<?php echo esc_html($account_menu_text);?>"></td>
							<td>
								<a href="<?php echo esc_url($page_link); ?>?&profile=videos">
									<?php echo esc_url($page_link); ?>?&profile=videos
								</a>
							</td>
						</tr>
						<tr>
							<tr>
								<th scope="row"><?php esc_html_e('8','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_doc' ) ) {
										$account_menu_check= get_option('_ep_finaluser_doc');
									}
									$account_menu_text=esc_html__( 'My Docs','finaluser');
									if( get_option( '_ep_finaluser_doc_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_doc_text');
									}
								?>
								<input type="checkbox" name="setting_doc" id="setting_doc" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='doc')? 'checked':'' ?> value="doc">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenudoc" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=doc">
										<?php echo esc_url($page_link); ?>?&profile=doc
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('8','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_activity' ) ) {
										$account_menu_check= get_option('_ep_finaluser_activity');
									}
									$account_menu_text=esc_html__( 'Activity','finaluser');
									if( get_option( '_ep_finaluser_activity_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_activity_text');
									}
								?>
								<input type="checkbox" name="setting_activity" id="setting_activity" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='activity')? 'checked':'' ?> value="activity">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenuactivity" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=activity">
										<?php echo esc_url($page_link); ?>?&profile=activity
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('9','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_notification' ) ) {
										$account_menu_check= get_option('_ep_finaluser_notification');
									}
									$account_menu_text=esc_html__( 'Notification','finaluser');
									if( get_option( '_ep_finaluser_notification_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_notification_text');
									}
								?>
								<input type="checkbox" name="setting_notification" id="setting_notification" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='notification')? 'checked':'' ?> value="notification">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenunotification" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=notification">
										<?php echo esc_url($page_link); ?>?&profile=notification
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('10','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_inbox' ) ) {
										$account_menu_check= get_option('_ep_finaluser_inbox');
									}
									$account_menu_text=esc_html__( 'Inbox','finaluser');
									if( get_option( '_ep_finaluser_inbox_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_inbox_text');
									}
								?>
								<input type="checkbox" name="setting_inbox" id="setting_inbox" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>--</td>
								<td><input type="text"  name="textmenuinbox" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=inbox">
										<?php echo esc_url($page_link); ?>?&profile=inbox
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('11','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_compose' ) ) {
										$account_menu_check= get_option('_ep_finaluser_compose');
									}
									$account_menu_text=esc_html__( 'Compose','finaluser');
									if( get_option( '_ep_finaluser_compose_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_compose_text');
									}
								?>
								<input type="checkbox" name="setting_compose" id="setting_compose" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='compose')? 'checked':'' ?> value="compose">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenucompose" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=compose">
										<?php echo esc_url($page_link); ?>?&profile=compose
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('13','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_inbox2' ) ) {
										$account_menu_check= get_option('_ep_finaluser_inbox2');
									}
									$account_menu_text=esc_html__( 'Inbox','finaluser');
									if( get_option( '_ep_finaluser_inbox2_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_inbox2_text');
									}
								?>
								<input type="checkbox" name="setting_inbox2" id="setting_inbox2" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='inbox')? 'checked':'' ?> value="inbox">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenuinbox2" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=inbox">
										<?php echo esc_url($page_link); ?>?&profile=inbox
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('13','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_sent' ) ) {
										$account_menu_check= get_option('_ep_finaluser_sent');
									}
									$account_menu_text=esc_html__( 'Sent','finaluser');
									if( get_option( '_ep_finaluser_sent_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_sent_text');
									}
								?>
								<input type="checkbox" name="setting_sent" id="setting_sent" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='sent')? 'checked':'' ?> value="sent">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenusent" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=sent">
										<?php echo esc_url($page_link); ?>?&profile=sent
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('14','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_woocommerce' ) ) {
										$account_menu_check= get_option('_ep_finaluser_woocommerce');
									}
									$account_menu_text=esc_html__( 'Woocommerce','finaluser');
									if( get_option( '_ep_finaluser_woocommerce_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_woocommerce_text');
									}
								?>
								<input type="checkbox" name="setting_woocommerce" id="setting_woocommerce" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									--
								</td>
								<td><input type="text"  name="textmenuwoocommerce" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=order">
										<?php echo esc_url($page_link); ?>?&profile=woocommerce
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('15','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_order' ) ) {
										$account_menu_check= get_option('_ep_finaluser_order');
									}
									$account_menu_text=esc_html__( 'My Orders','finaluser');
									if( get_option( '_ep_finaluser_order_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_order_text');
									}
								?>
								<input type="checkbox" name="setting_order" id="setting_order" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='order')? 'checked':'' ?> value="order">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenuorder" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=order">
										<?php echo esc_url($page_link); ?>?&profile=order
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('16','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_subscriptions' ) ) {
										$account_menu_check= get_option('_ep_finaluser_subscriptions');
									}
									$account_menu_text=esc_html__( 'My Subscriptions','finaluser');
									if( get_option( '_ep_finaluser_subscriptions_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_subscriptions_text');
									}
								?>
								<input type="checkbox" name="setting_subscriptions" id="setting_subscriptions" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='subscriptions')? 'checked':'' ?> value="subscriptions">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenusubscriptions" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=subscriptions">
										<?php echo esc_url($page_link); ?>?&profile=subscriptions
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('17','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_downloads' ) ) {
										$account_menu_check= get_option('_ep_finaluser_downloads');
									}
									$account_menu_text=esc_html__( 'Downloads','finaluser');
									if( get_option( '_ep_finaluser_downloads_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_downloads_text');
									}
								?>
								<input type="checkbox" name="setting_downloads" id="setting_downloads" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='downloads')? 'checked':'' ?> value="downloads">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenudownloads" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=downloads">
										<?php echo esc_url($page_link); ?>?&profile=downloads
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('18','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_billing' ) ) {
										$account_menu_check= get_option('_ep_finaluser_billing');
									}
									$account_menu_text=esc_html__( 'Billing Address','finaluser');
									if( get_option( '_ep_finaluser_billing_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_billing_text');
									}
								?>
								<input type="checkbox" name="setting_billing" id="setting_billing" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='billing')? 'checked':'' ?> value="billing">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenubilling" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=billing">
										<?php echo esc_url($page_link); ?>?&profile=billing
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('19','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_shipping' ) ) {
										$account_menu_check= get_option('_ep_finaluser_shipping');
									}
									$account_menu_text=esc_html__( 'Shipping Address','finaluser');
									if( get_option( '_ep_finaluser_shipping_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_shipping_text');
									}
								?>
								<input type="checkbox" name="setting_shipping" id="setting_shipping" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='shipping')? 'checked':'' ?> value="shipping">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenushipping" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=shipping">
										<?php echo esc_url($page_link); ?>?&profile=shipping
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('20','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_password' ) ) {
										$account_menu_check= get_option('_ep_finaluser_password');
									}
									$account_menu_text=esc_html__( 'Password','finaluser');
									if( get_option( '_ep_finaluser_password_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_password_text');
									}
								?>
								<input type="checkbox" name="setting_password" id="setting_password" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='myaccount_active_tab' id='myaccount_active_tab'  type="radio" <?php echo ($active_tab=='password')? 'checked':'' ?> value="password">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textmenupassword" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
									<a href="<?php echo esc_url($page_link); ?>?&profile=password">
										<?php echo esc_url($page_link); ?>?&profile=password
									</a>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('21','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_profile' ) ) {
										$account_menu_check= get_option('_ep_finaluser_profile');
									}
									$account_menu_text=esc_html__( 'Public Profile','finaluser');
									if( get_option( '_ep_finaluser_profile_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_profile_text');
									}
								?>
								<input type="checkbox" name="setting_profile" id="setting_profile" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									--
								</td>
								<td><input type="text"  name="textmenuprofile" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('22','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_signout' ) ) {
										$account_menu_check= get_option('_ep_finaluser_signout');
									}
									$account_menu_text=esc_html__( 'Sign Out','finaluser');
									if( get_option( '_ep_finaluser_signout_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_signout_text');
									}
								?>
								<input type="checkbox" name="setting_signout" id="setting_signout" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									--
								</td>
								<td><input type="text"  name="textmenusignout" value="<?php echo esc_html($account_menu_text);?>"></td>
								<td>
								</td>
							</tr>
						</tbody>
					</table>
					<div id="custom_menu_div">
						<?php
							$args = array(
							'child_of'     => 0,
							'sort_order'   => 'ASC',
							'sort_column'  => 'post_title',
							'hierarchical' => 1,
							'post_type' => 'page'
							);
							$old_custom_menu = array();
							if(get_option('ep_finaluser_profile_menu')){
								$old_custom_menu=get_option('ep_finaluser_profile_menu' );
							}
							$ii=1;
							if($old_custom_menu!=''){
								foreach ( $old_custom_menu as $field_key => $field_value ) {
								?>
								<div class="row form-group " id="menu_<?php echo esc_html($ii); ?>">
									<div class=" col-sm-3">
										<input type="text" class="form-control" name="menu_title[]" id="menu_title[]"  value="<?php echo esc_html($field_key); ?>" placeholder=" <?php esc_html_e('Enter Menu Title','finaluser'); ?>">
									</div>
									<div  class=" col-sm-2">
										<?php esc_html_e('Menu Content page','finaluser');?>
									</div>
									<div  class=" col-sm-5">
										<?php
											if ( $pages = get_pages( $args ) ){
												echo "<select name='menu_link[]' id='menu_link[]'  class='form-control'>";
												foreach ( $pages as $page ) {
													echo "<option value='".esc_html($page->ID)."' ".($field_value==$page->ID ? 'selected':'').">".esc_html($page->post_title)."</option>";
												}
												echo "</select>";
											}
										?>
									</div>
									<div  class=" col-sm-2">
										<button class="btn btn-danger btn-xs" onclick="return iv_remove_menu('<?php echo esc_html($ii); ?>');"><?php esc_html_e('Delete','finaluser');?></button>
									</div>
								</div>
								<?php
									$ii++;
								}
							}
						?>
					</div>
					<div class="vhide">
						<div class="row form-group " id="menu_custom_main" >
							<div class=" col-sm-3">
								<input type="text" class="form-control" name="menu_title[]" id="menu_title[]"  value="" placeholder=" <?php esc_html_e('Enter Menu Title','finaluser'); ?>">
							</div>
							<div  class=" col-sm-2">
								<?php esc_html_e('Menu Content page','finaluser');?>
							</div>
							<div  class=" col-sm-5">
								<?php
									if ( $pages = get_pages( $args ) ){
										echo "<select name='menu_link[]' id='menu_link[]'  class='form-control'>";
										foreach ( $pages as $page ) {
											echo "<option value='".esc_html($page->ID)."' >".esc_html($page->post_title)."</option>";
										}
										echo "</select>";
									}
								?>
							</div>
						</div>
					</div>
					<div class="col-xs-12">
						<button class="btn btn-warning btn-xs" onclick="return iv_add_menu();"><?php esc_html_e('Add More','finaluser');?> </button>
					</div>
				</div>
			</div>
			<div class="panel panel-info">
				<div class="panel-heading"><h4><?php esc_html_e('Public Profile Tab','finaluser');?> </h4></div>
				<div class="panel-body">
					<?php
						$active_tab=get_option('_pprofile_tab_active');
						if($active_tab==""){$active_tab='pprofile';}
					?>
					<table class="table table-hover">
						<thead>
							<tr>
								<th scope="col"><?php esc_html_e('#','finaluser'); ?></th>
								<th scope="col"><?php esc_html_e('Show/Hide','finaluser');?></th>
								<th scope="col"><?php esc_html_e('Active Tab','finaluser');?></th>
								<th scope="col"><?php esc_html_e('Tab Title / Label','finaluser');?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row"><?php esc_html_e('1','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_pvideos' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_pvideos');
									}
									$account_menu_text=esc_html__( 'Videos','finaluser');
									if( get_option( '_ep_finaluser_pvideos_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_pvideos_text');
									}
								?>
								<input type="checkbox" name="pvideos" id="pvideos" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='pvideos')? 'checked':'' ?> value="pvideos">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textvideos" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('2','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_photos' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_photos');
									}
									$account_menu_text=esc_html__( 'Photos','finaluser');
									if( get_option( '_ep_finaluser_pphotos_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_pphotos_text');
									}
								?>
								<input type="checkbox" name="pphotos" id="pphotos" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='pphotos')? 'checked':'' ?> value="pphotos">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textphotos" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('3','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_pprofile' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_pprofile');
									}
									$account_menu_text=esc_html__( 'Profile','finaluser');
									if( get_option( '_ep_finaluser_pprofile_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_pprofile_text');
									}
								?>
								<input type="checkbox" name="pprofile" id="pprofile" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='pprofile')? 'checked':'' ?> value="pprofile">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textprofile" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('4','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_previews' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_previews');
									}
									$account_menu_text=esc_html__( 'Reviews','finaluser');
									if( get_option( '_ep_finaluser_previews_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_previews_text');
									}
								?>
								<input type="checkbox" name="previews" id="previews" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='previews')? 'checked':'' ?> value="previews">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textreviews" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('5','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_ppost' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_ppost');
									}
									$account_menu_text=esc_html__( 'Posts','finaluser');
									if( get_option( '_ep_finaluser_ppost_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_ppost_text');
									}
								?>
								<input type="checkbox" name="ppost" id="ppost" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='ppost')? 'checked':'' ?> value="ppost">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textpost" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('6','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_pdocs' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_pdocs');
									}
									$account_menu_text=esc_html__( 'Docs','finaluser');
									if( get_option( '_ep_finaluser_pdocs_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_pdocs_text');
									}
								?>
								<input type="checkbox" name="pdocs" id="pdocs" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='pdocs')? 'checked':'' ?> value="pdocs">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textdocs" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e('7','finaluser'); ?></th>
								<td><?php
									$account_menu_check='';
									if( get_option( '_ep_finaluser_public_pfacebook' ) ) {
										$account_menu_check= get_option('_ep_finaluser_public_pfacebook');
									}
									$account_menu_text=esc_html__( 'Facebook Feed','finaluser');
									if( get_option( '_ep_finaluser_public_pfacebook_text' ) ) {
										$account_menu_text= get_option('_ep_finaluser_public_pfacebook_text');
									}
								?>
								<input type="checkbox" name="pfacebook" id="pfacebook" value="hide" <?php echo ($account_menu_check=='hide'? 'checked':'' ); ?> > <?php esc_html_e('Hide','finaluser');?>
								</td>
								<td>
									<label>
										<input name='pp_active_tab' id='pp_active_tab'  type="radio" <?php echo ($active_tab=='pfacebook')? 'checked':'' ?> value="pfacebook">
										<?php esc_html_e('Active','finaluser');?>
									</label>
								</td>
								<td><input type="text"  name="textpfacebook" value="<?php echo esc_html($account_menu_text);?>"></td>
							</tr>
						</tbody>
					</table>
					<div id="custom_tab_div">
						<?php
							$args = array(
							'child_of'     => 0,
							'sort_order'   => 'ASC',
							'sort_column'  => 'post_title',
							'hierarchical' => 1,
							'post_type' => 'page'
							);
							$old_custom_menu = array();
							if(get_option('ep_finaluser_profile_pptab')){
								$old_custom_menu=get_option('ep_finaluser_profile_pptab' );
							}
							$ii=1;
							if($old_custom_menu!=''){
								foreach ( $old_custom_menu as $field_key => $field_value ) {
								?>
								<div class="row form-group " id="tab<?php echo esc_html($ii); ?>">
									<div class=" col-sm-3">
										<input type="text" class="form-control" name="tab_title[]" id="tab_title[]"  value="<?php echo esc_html($field_key); ?>" placeholder="<?php esc_html_e('Enter Tab Title ','finaluser'); ?>">
									</div>
									<div  class=" col-sm-2">
										<?php esc_html_e('Tab Content page','finaluser');?>
									</div>
									<div  class=" col-sm-5">
										<?php
											if ( $pages = get_pages( $args ) ){
												echo "<select name='tab_link[]' id='tab_link[]'  class='form-control'>";
												foreach ( $pages as $page ) {
													echo "<option value='{$page->ID}' ".($field_value==$page->ID ? 'selected':'').">{$page->post_title}</option>";
												}
												echo "</select>";
											}
										?>
									</div>
									<div  class=" col-sm-2">
										<button class="btn btn-danger btn-xs" onclick="return iv_remove_tab('<?php echo esc_html($ii); ?>');"><?php esc_html_e('Delete','finaluser');?></button>
									</div>
								</div>
								<?php
									$ii++;
								}
							}
						?>
					</div>
					<div class="vhide">
						<div class="row form-group " id="tab_custom_main" >
							<div class=" col-sm-3">
								<input type="text" class="form-control" name="tab_title[]" id="tab_title[]"  value="" placeholder="<?php esc_html_e('Enter Tab Title','finaluser'); ?>">
							</div>
							<div  class=" col-sm-2">
								<?php esc_html_e('Tab Content page','finaluser');?>
							</div>
							<div  class=" col-sm-5">
								<?php
									if ( $pages = get_pages( $args ) ){
										echo "<select name='tab_link[]' id='tab_link[]'  class='form-control'>";
										foreach ( $pages as $page ) {
											echo "<option value='{$page->ID}' >{$page->post_title}</option>";
										}
										echo "</select>";
									}
								?>
							</div>
						</div>
					</div>
					<div class="col-xs-12">
						<button class="btn btn-warning btn-xs" onclick="return iv_add_tab();"><?php esc_html_e('Add More','finaluser');?> </button>
					</div>
				</div>
			</div>
			<div class="panel panel-info">
				<div class="panel-heading"><h4><?php esc_html_e('User Profile Fields +Signup Form Fields','finaluser');?> </h4></div>
				<div class="panel-body">
					<div class="row ">
						<div class="col-sm-4 ">
							<h4><?php esc_html_e('User Meta Name','finaluser');?> </h4>
						</div>
						<div class="col-sm-4">
							<h4><?php esc_html_e('Display Label','finaluser');?> </h4>
						</div>
						<div class="col-sm-1">
							<h4><?php esc_html_e('Signup Form','finaluser');?> </h4>
						</div>
						<div class="col-sm-1">
							<h4><?php esc_html_e('Require','finaluser');?> </h4>
						</div>
						<div class="col-sm-2">
							<h4><?php esc_html_e('Action','finaluser');?> </h4>
						</div>
					</div>
					<div id="custom_field_div">
						<?php
							$default_fields = array();
							$field_set=get_option('ep_finaluser_profile_fields' );
							if($field_set!=""){
								$default_fields=get_option('ep_finaluser_profile_fields' );
								}else{
								$default_fields['first_name']='First Name';
								$default_fields['last_name']='Last Name';
								$default_fields['phone']='Phone Number';
								$default_fields['mobile']='Mobile Number';
								$default_fields['web_site']='Website Url';
							}
							$i=1;
							$sign_up_array=  get_option( 'ep_finaluser_signup_fields' );
							$require_array=  get_option( 'ep_finaluser_signup_require' );
							foreach ( $default_fields as $field_key => $field_value ) {
								$sign_up='no';
								if(isset($sign_up_array[$field_key]) && $sign_up_array[$field_key] == 'yes') {
									$sign_up='yes';
								}
								$require='no';
								if(isset($require_array[$field_key]) && $require_array[$field_key] == 'yes') {
									$require='yes';
								}
								echo '<div class="row form-group " id="field_'.$i.'"><div class=" col-sm-4"> <input type="text" class="form-control" name="meta_name[]" id="meta_name[]" value="'.$field_key . '" placeholder="Enter User Meta Name "> </div>
								<div  class=" col-sm-4">
								<input type="text" class="form-control" name="meta_label[]" id="meta_label[]" value="'.$field_value . '" placeholder="Enter User Meta Label">
								</div>
								<div class="checkbox col-sm-1">
								<label>
								<input type="checkbox" name="signup[]" id="signup[]" value="'.$field_key.'" '.($sign_up=='yes'? 'checked':'' ).' >
								</label>
								</div>
								<div class="checkbox col-sm-1">
								<label>
								<input type="checkbox" name="srequire[]" id="srequire[]" value="'.$field_key.'" '. ($require=='yes'? 'checked':'' ).' >
								</label>
								</div>
								<div  class=" col-sm-2">';
							?>
							<button class="btn btn-danger btn-xs" onclick="return iv_remove_field('<?php echo esc_html($i); ?>');"><?php esc_html_e('Delete','finaluser');?> </button>
						</div>
					</div>
					<?php
						$i++;
					}
				?>
			</div>
			<div class="col-xs-12">
				<button class="btn btn-warning btn-xs" onclick="return iv_add_field();"><?php esc_html_e('Add More','finaluser');?> </button>
			</div>
		</div>
	</div>
</form>
<div class="row">
	<div class="col-xs-12">
		<div align="center">
			<div id="loading"></div>
			<button class="btn btn-info btn-lg" onclick="return update_profile_fields();"><?php esc_html_e('Update','finaluser');?>  </button>
		</div>
		<p>&nbsp;</p>
	</div>
</div>
</div>
</div>
<?php
	wp_enqueue_script('ep_finaluser-profile-fields', finaluser_URLPATH.'admin/files/js/profile-fields.js', array('jquery'), $ver = true, true );
	wp_localize_script('ep_finaluser-profile-fields', 'ep_data5', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'current_user_id'	=>get_current_user_id(),
	'i'					=>  $i,
	'ii'				=> $ii,
	'Backgroung_Image'	=> esc_html__( 'Backgroung Image','finaluser'),
	'url10'				=> '?&page=wp-ep_finaluser-profile-form', 
	'finalwpnonce'		=>  wp_create_nonce("settings"),
	) );
?>
