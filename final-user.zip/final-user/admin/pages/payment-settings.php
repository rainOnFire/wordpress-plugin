<?php
	global $wpdb;
	$newpost_id='';
	$post_name='ep_finaluser_paypal_setting';
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name));
	if(isset($row->ID )){
		$newpost_id= $row->ID;
	}
	$paypal_mode=get_post_meta( $newpost_id,'ep_finaluser_paypal_mode',true);
	$newpost_id='';
	$post_name='ep_finaluser_stripe_setting';
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name ));
	if(isset($row->ID )){
		$newpost_id= $row->ID;
	}
	$stripe_mode=get_post_meta( $newpost_id,'ep_finaluser_stripe_mode',true);
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12">
				<h3 class="page-header" > <?php esc_html_e('Payment Gateways','finaluser'); ?> </h3>
				<div class="col-md-12" id="update_message">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="update_message"> </div>
				<table class="table">
					<thead>
						<tr>
						  <th><?php esc_html_e('#','finaluser'); ?></th>
						  <th><?php esc_html_e('Gateways Name','finaluser'); ?></th>
						  <th><?php esc_html_e('Mode','finaluser'); ?></th>
						  <th><?php esc_html_e('Status','finaluser'); ?></th>
						  <th><?php esc_html_e('Action','finaluser'); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
						  <td><?php esc_html_e('1','finaluser'); ?></td>
						  <td> <label>
								<input name='payment_gateway' id='payment_gateway'  type="radio" <?php echo (get_option('ep_finaluser_payment_gateway')=='paypal-express')? 'checked':'' ?> value="paypal-express">
								<?php esc_html_e('Paypal','finaluser'); ?>
							</label>
						  </td>
						  <td><?php echo strtoupper($paypal_mode); ?></td>
						  <td><?php echo (get_option('ep_finaluser_payment_gateway')=='paypal-express')? 'Active':'Inactive' ?> </td>
							<td><a class="btn btn-primary btn-xs" href="?page=wp-ep_finaluser-payment-paypal"> <?php esc_html_e('Edit Setting','finaluser'); ?></a></td>
						</tr>
						<tr>
						  <td><?php esc_html_e('2','finaluser'); ?></td>
						  <td>
								<label>
									<input name='payment_gateway' id='payment_gateway'  type="radio" <?php echo (get_option('ep_finaluser_payment_gateway')=='stripe')? 'checked':'' ?>  value="stripe">
									<?php esc_html_e('Stripe','finaluser'); ?>
								</label> </td>
								<td><?php echo strtoupper($stripe_mode); ?></td>
								<td><?php echo (get_option('ep_finaluser_payment_gateway')=='stripe')? 'Active':'Inactive' ?></td>
								<td> <a class="btn btn-primary btn-xs" href="?page=wp-ep_finaluser-payment-stripe"> <?php esc_html_e('Edit Setting','finaluser'); ?></a> </td>
						</tr>
						<?php
							if ( class_exists( 'WooCommerce' ) ) {
							?>
							<tr>
								<td><?php esc_html_e( '3', 'finaluser' );?></td>
								<td><input name='payment_gateway' id='payment_gateway'  type="radio" <?php echo (get_option('ep_finaluser_payment_gateway')=='woocommerce')? 'checked':'' ?>  value="woocommerce">
									<b><?php esc_html_e('WooCommerce','finaluser'); ?></b> <?php esc_html_e('[You need to select the payment gateway from woocommerce settings]','finaluser'); ?>
								</label> </td>
								<td></td>
								<td><?php echo (get_option('ep_finaluser_payment_gateway')=='woocommerce')? 'Active':'Inactive' ?></td>
								<td>  </td>
						</tr>
						<?php
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</div>
