<?php
	global $wpdb;
	$currencies = array();
	$currencies['AUD'] ='$';$currencies['CAD'] ='$';
	$currencies['EUR'] ='€';$currencies['GBP'] ='£';
	$currencies['JPY'] ='¥';$currencies['USD'] ='$';
	$currencies['NZD'] ='$';$currencies['CHF'] ='Fr';
	$currencies['HKD'] ='$';$currencies['SGD'] ='$';
	$currencies['SEK'] ='kr';$currencies['DKK'] ='kr';
	$currencies['PLN'] ='zł';$currencies['NOK'] ='kr';
	$currencies['HUF'] ='Ft';$currencies['CZK'] ='Kč';
	$currencies['ILS'] ='₪';$currencies['MXN'] ='$';
	$currencies['BRL'] ='R$';$currencies['PHP'] ='₱';
	$currencies['MYR'] ='RM';$currencies['AUD'] ='$';
	$currencies['TWD'] ='NT$';$currencies['THB'] ='฿';
	$currencies['TRY'] ='TRY';	$currencies['CNY'] ='¥';
	if(isset($_REQUEST['id']))  {
	}
	if(isset($_REQUEST['delete_id']))  {
		$post_id=$_REQUEST['delete_id'];
		$recurring= get_post_meta($post_id, 'ep_finaluser_package_recurring', true);
		if($recurring=='on'){
			$iv_gateway = get_option('ep_finaluser_payment_gateway');
			if($iv_gateway=='stripe'){
				include(finaluser_DIR . '/admin/files/init.php');			
				$post_name2='ep_finaluser_stripe_setting';
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name2 ));
				if(isset($row->ID )){
					$stripe_id= $row->ID;
				}
				$post_package = get_post($post_id);
				$p_name = $post_package->post_name;
				$stripe_mode=get_post_meta( $stripe_id,'ep_finaluser_stripe_mode',true);
				if($stripe_mode=='test'){
					$stripe_api =get_post_meta($stripe_id, 'ep_finaluser_stripe_secret_test',true);
					}else{
					$stripe_api =get_post_meta($stripe_id, 'ep_finaluser_stripe_live_secret_key',true);
				}
				$plan='';
				\Stripe\Stripe::setApiKey($stripe_api);
				$have_plan=1;
				try {
					$plan = \Stripe\Plan::retrieve($p_name);
					} catch (Exception $e) {
					$have_plan=0;
					print_r($e); die();
				}
				if($have_plan=1){
					$plan->delete();				
				}
			}
		}
		wp_delete_post($post_id);
		delete_post_meta($post_id,true);
		$message="Deleted Successfully";
	}
	if(isset($_REQUEST['form_submit']))  {
		$message="Update Successfully ";
	}
  $api_currency= get_option('_ep_finaluser_api_currency' );
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row ">
			<div class="col-md-12" id="submit-button-holder">
				<div class="pull-right ">
					<a class="btn btn-info "  href="<?php echo finaluser_ADMINPATH; ?>admin.php?page=wp-ep_finaluser-package-create">
						<?php esc_html_e('Create A New Package', 'finaluser'); ?>
					</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 table-responsive">
				<h3  class=""><?php esc_html_e('All Package / Membership Level', 'finaluser'); ?>  <small></small>
					<small >
						<?php
							if (isset($_REQUEST['form_submit']) AND $_REQUEST['form_submit'] <> "") {
							}
							if (isset($message) AND $message <> "") {
								echo  '<span style="color: #0000FF;"> [ '.$message.' ]</span>';
							}
						?>
					</small>
				</h3>
				<div class="panel panel-info">
					<div class="panel-body">
						<table class="table table-striped col-md-12">
							<thead >
								<tr>
									<th ><?php esc_html_e('Package Name','finaluser'); ?></th>
									<th ><?php esc_html_e('Amount','finaluser'); ?></th>
									<th><?php esc_html_e('Link','finaluser'); ?></th>
									<th><?php esc_html_e('User Role','finaluser'); ?></th>
									<th><?php esc_html_e('Status','finaluser'); ?></th>
									<th ><?php esc_html_e('Action','finaluser'); ?> </th>
								</tr>
							</thead>
							<tbody>
								<?php
									$currency=$api_currency ;
									$currency_symbol=(isset($currencies[$currency]) ? $currencies[$currency] :$currency );
									global $wpdb, $post;
									$sql="SELECT * FROM $wpdb->posts WHERE post_type = 'ep_finaluser_pack'";
									$membership_pack = $wpdb->get_results($sql);
									$total_package=count($membership_pack);
									if(sizeof($membership_pack)>0){
										$i=0;
										foreach ( $membership_pack as $row )
										{
											echo'<tr>';
											echo '<td>'. $row->post_title.'</td>';
											$amount='';
											if(get_post_meta($row->ID, 'ep_finaluser_package_cost', true)!="" AND get_post_meta($row->ID, 'ep_finaluser_package_cost', true)!="0"){
												$amount= get_post_meta($row->ID, 'ep_finaluser_package_cost', true).' '.$currency;
												}else{
												$amount= '0 '.$currency;
											}
											$recurring= get_post_meta($row->ID, 'ep_finaluser_package_recurring', true);
											if($recurring == 'on'){
												$count_arb=get_post_meta($row->ID, 'ep_finaluser_package_recurring_cycle_count', true);
												if($count_arb=="" or $count_arb=="1"){
													$recurring_text=" per ".' '.get_post_meta($row->ID, 'ep_finaluser_package_recurring_cycle_type', true);
													}else{
													$recurring_text=' per '.$count_arb.' '.get_post_meta($row->ID, 'ep_finaluser_package_recurring_cycle_type', true).'s';
												}
												}else{
												$recurring_text=' &nbsp; ';
											}
											$recurring= get_post_meta($row->ID, 'ep_finaluser_package_recurring', true);
											if($recurring == 'on'){
												$amount= get_post_meta($row->ID, 'ep_finaluser_package_recurring_cost_initial', true).' '.$currency;
												$amount=$amount. ' / '.$recurring_text;
											}
											echo '<td>'. $amount.'</td>';
											$page_name_reg=get_option('_ep_finaluser_registration' );
											echo '<td><a target="blank" href="'.get_page_link($page_name_reg).'?&package_id='.$row->ID.'">'.get_page_link($page_name_reg).'?&package_id='.$row->ID.' </a>
											</td>';
											echo '<td>'. $row->post_title.'</td>';
										?>
										<td>
											<div id="status_<?php echo esc_html($row->ID); ?>">
												<?php
													if($row->post_status=="draft"){
														$pac_msg='Active';
														}else{
														$pac_msg='Inactive';
													}
												?>
												<button class="btn btn-info btn-xs" onclick="return iv_package_status_change('<?php echo esc_html($row->ID); ?>','<?php echo esc_html($row->post_status); ?>');"><?php echo esc_html($pac_msg); ?></button>
											</div>
											<?php
												echo" </td> ";
												echo '<td>  <a class="btn btn-primary btn-xs" href="?page=wp-ep_finaluser-package-update&id='.$row->ID.'"> Edit</a> <a href="?page=wp-ep_finaluser-package-all&delete_id='.esc_html($row->ID).'" class="btn btn-danger btn-xs" onclick="return confirm(\'Are you sure to delete this package?\');">Delete</a></td>';
												echo'</tr>';
												$i++;
											}
											}else{
											echo "	<br/>
											<br/><tr><td> <h4>".esc_html__( 'Package List is Empty', 'finaluser' )."</h4></td></tr>";
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="">
						<a class="btn btn-info "  href="<?php echo finaluser_ADMINPATH; ?>admin.php?page=wp-ep_finaluser-package-create">
							<?php esc_html_e('Create A New Package', 'finaluser'); ?>
						</a>
					</div>
				</div>
			</div>
			<br/>
			<div class="panel panel-info">
				<div class="panel-body">
					<div class=" col-md-12  bs-callout bs-callout-info">
						<?php esc_html_e('User role "Basic" is created on the plugin activation. Paid exprired or unsuccessful payment user will set on the "Basic" user role.', 'finaluser'); ?>
					</div>
					<div class="clearfix"></div>
					<ul class=" list-group col-md-6">
						<li class="list-group-item"><?php esc_html_e('Short Code :', 'finaluser'); ?> <code>[ep_finaluser_price_table]  </code></li>
						<li class="list-group-item"><?php esc_html_e('PHP Code :', 'finaluser'); ?><code>
							&lt;?php
							echo do_shortcode('[ep_finaluser_price_table ]');
						?&gt;</code>
						</li>
						<li class="list-group-item">
							<?php esc_html_e('Package Page :', 'finaluser'); ?>
							<?php
								$ep_finaluser_price_table=get_option('_ep_finaluser_price_table');
							?>
							<a class="btn btn-info btn-xs " href="<?php echo get_permalink( $ep_finaluser_price_table ); ?>" target="blank"><?php esc_html_e('View Page', 'finaluser'); ?></a>
						</li>
					</ul>
					<div class="clearfix"></div>
					<div class="  bs-callout bs-callout-info">
						<?php esc_html_e('Note: You can use other available pricing table. The package link URL will go on "Sign UP " button.', 'finaluser'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>	