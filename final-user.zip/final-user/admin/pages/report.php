<?php
	wp_enqueue_style('wp-ep_finaluser-report-11', finaluser_URLPATH . 'admin/files/css/report/normalize.css');
	wp_enqueue_script('ep_finaluser-report-12', finaluser_URLPATH . 'admin/files/js/amcharts.js');
	global $wpdb;
	$api_currency= get_option('_ep_finaluser_api_currency' );
	$sql="SELECT * FROM $wpdb->posts WHERE post_type = 'ep_finaluser_pack' ";
	$membership_pack = $wpdb->get_results($sql);
	$total_package=count($membership_pack);
	$package_count= array();
	$package_count_report= array();
	$package_amount= array();
	$package_amount_report= array();
	$total=0;
	$total_user=0;
	if(sizeof($membership_pack)>0){
		$i=0;
		foreach ( $membership_pack as $row )
		{
			$role_row=get_post_meta($row->ID,'ep_finaluser_package_user_role',true);
			$packge_cost=get_post_meta($row->ID,'ep_finaluser_package_cost',true);
			$user_query = new WP_User_Query( array( 'role' => $role_row) );
			$user_query->total_users ;
			$package_count[$i]['Package']=$row->post_title;
			$package_count[$i]['value']=$user_query->total_users;
			$package_count_report[$i]=$row->post_title .': '.$user_query->total_users .' Users';
			$total_user=$total_user + $user_query->total_users ;
			$i++;
		}
	}
	$sql_history="SELECT `post_title`,sum(`post_content`)as amount FROM `wp_posts` WHERE  `post_type`='iv_payment'  and post_status='publish' and post_title <>'Bidding Cost'  and post_title <>'Bidding Deposit' group by `post_title`";
	$payment_history = $wpdb->get_results($sql_history);
	$ii=0;	$amount=0;
	if(sizeof($payment_history)>0){
		foreach ( $payment_history as $row2 )
		{
			$package_amount[$ii]['Package']=$row2->post_title;
			$package_amount[$ii]['value']= $row2->amount;
			$package_amount_report[$ii]= $row2->post_title.': ' . $row2->amount.' '.$api_currency ;
			$total=$total+$row2->amount;
			$ii++;
		}
	}
	$user_chart= array();
	$sql="select count(*) as total_users ,date(user_registered) as reg_date from $wpdb->users group by reg_date having total_users > 0 ";
	$users_all = $wpdb->get_results($sql);
	$user_chart_string='';
	if(sizeof($users_all)>0){
		$i=0;
		foreach ( $users_all as $row )
		{
			$user_chart[$i]['udate']=date('Y-m-d',strtotime($row->reg_date));
			$user_chart[$i]['value']= $row->total_users;
			$i++;
		}
	}
	$package_count_json= json_encode($package_count);
	$package_amount_json= json_encode($package_amount);
	$user_chart_string= json_encode($user_chart);
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">		
		<div class="row ">
			<div class="col-md-12">
				<table width="100%">
					<tr>
						<td width="50%"> <div class="panel panel-info">
							<div  id="package_user" class="wdht">
							</div>
							<div class="panel-body">
								<?php
									$i=1;
									foreach($package_count_report as $pac){
										echo '<br/>'.esc_html($i).'. '.esc_html($pac);
										$i++;
									}
								?>
								<br/>
								<strong><?php esc_html_e('Total :','finaluser'); ?> <?php echo esc_html($total_user).' '; esc_html_e( 'Users', 'finaluser' )?>  </strong>
							</div>
						</div>
						</td>
						<td width="50%">
							<div class="panel panel-info">
								<div  id="package_amount" class="wdht">
								</div>
								<div class="panel-body">
									<?php
										$iii=1;
										foreach($package_amount_report as $pac){
											echo '<br/>'.esc_html($iii).esc_html($pac);
											$iii++;
										}
									?>
									<br/>
								</div>
							</div>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="panel panel-info">
			<div class="panel-body">
				<h3  class="page-header"><?php esc_html_e('User Registration Chart','finaluser'); ?><small></small></h3>
				<div class="col-md-12">
					<div id="chart-line" class="wdht"></div>
				</div>
			</div>
		</div>	
	</div>
</div>
<?php
	wp_enqueue_script('wp-finaluser-report', finaluser_URLPATH.'admin/files/js/report.js', array('jquery'), $ver = true, true );
	wp_localize_script('wp-finaluser-report', 'report_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',	
	'adminnonce'=> wp_create_nonce("admin"),
	'pathToImages' =>  finaluser_URLPATH.'admin/files/images/',
	'pii'	=>$ii,
	'pi'	=> $i,
	'package_count_json'=> $package_count,
	'package_amount_json'=> $package_amount,
	'user_chart_string'=> $user_chart,
	) );
	?>	