<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12">
				<h3 class="page-header" ><?php esc_html_e('My Account','finaluser');?> <small>  </small> </h3>
			</div>
		</div>
		<div class="form-group col-md-12 row">
			<div class="row ">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Short Code','finaluser');?> </label>
				<div class="col-md-4" >
					[ep_finaluser_profile_template]
				</div>
				<div class="col-md-4" id="success_message">
				</div>
			</div>
			<div class="row ">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Php Code','finaluser');?> </label>
				<div class="col-md-10" >
					<p>
						&lt;?php
						echo do_shortcode('[ep_finaluser_profile_template]');
					?&gt;</p>
				</div>
			</div>
			<div class="row ">
				<label for="text" class="col-md-2 control-label"> <?php esc_html_e('My Account Page','finaluser');?> </label>
				<div class="col-md-10" >
					<?php
						$form_wizard=get_option('_ep_finaluser_profile_page');
					?>
					<a class="btn btn-info btn-xs " href="<?php echo get_permalink( $form_wizard ); ?>" target="blank"><?php esc_html_e('View Page','finaluser');?> </a>
				</div>
			</div>
			<div class="row ">
				<label for="text" class="col-md-2 control-label"> <?php esc_html_e('Profile Fields Setting','finaluser');?> </label>
				<div class="col-md-12" >
					<?php
						include ('profile-fields.php');
					?>
				</div>
			</div>
			<br/>
		</div>
	</div>
</div>