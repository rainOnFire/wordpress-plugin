<?php
	global $wpdb;			
	$email_body = get_option( 'ep_finaluser_signup_email');
	$signup_email_subject = get_option( 'ep_finaluser_signup_email_subject');			
					
		$admin_mail = get_option('admin_email');	
		if( get_option( 'admin_email_ep_finaluser' )==FALSE ) {
			$admin_mail = get_option('admin_email');						 
		}else{
			$admin_mail = get_option('admin_email_ep_finaluser');								
		}						
		$wp_title = get_bloginfo();
	
	$user_info = get_userdata( $user_id);	
					
	
	// Email for Admin		
				
	
	$email_body = str_replace("[user_name]", $user_info->display_name, $email_body);
	$email_body = str_replace("[iv_member_user_name]", $user_info->display_name, $email_body);
	$email_body = str_replace("[iv_member_password]", $userdata['user_pass'], $email_body);	
			
	$cilent_email_address =$user_info->user_email; 
					
	
			
	$auto_subject=  $signup_email_subject; 
							
	$headers = array("From: " . $wp_title . " <" . $admin_mail . ">", "Content-Type: text/html");
	$h = implode("\r\n", $headers) . "\r\n";
	wp_mail($cilent_email_address, $auto_subject, $email_body, $h);
			

					
					// Send Mailchimp
					
		// Send Mailchimp
					
			$firstname='';
			$lastname='';
			$words= array();
			if(isset($data_a['epfu_member_fname'])){
				if(isset($data_a['epfu_member_fname'])){
					$firstname =sanitize_text_field($data_a['epfu_member_fname']);
				}
				if(isset($data_a['epfu_member_lname'])){
					$lastname = sanitize_text_field($data_a['epfu_member_lname']);
				}									
				
			}else{
				if(isset($data_a['epfu_member_user_name'])){
					$firstname = sanitize_text_field($data_a['epfu_member_user_name']);
				}
			}	
							
			if( ! class_exists('MailChimp' ) ) {
				require(finaluser_DIR . '/inc/MailChimp.php');
			}
			$epfu_mailchimp_api_key='';
			if( get_option( 'ep_finaluser_mailchimp_api_key' )==FALSE ) {
				$epfu_mailchimp_api_key = get_option('ep_finaluser_mailchimp_api_key');						 
			}else{
				$epfu_mailchimp_api_key = get_option('ep_finaluser_mailchimp_api_key');								
			}						
			
			$MailChimp = new MailChimp($epfu_mailchimp_api_key);
			$list_id=get_option('ep_finaluser_mailchimp_list');
			
			$MailChimp->post("lists/$list_id/members", [
				'email_address' => $cilent_email_address,
				'status'        => 'subscribed',
			]);
			
			
			
			
	// End Send Mailchimp
	
	

