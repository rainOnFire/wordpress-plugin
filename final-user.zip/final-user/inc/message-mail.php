<?php
	global $wpdb;	
	$email_body = get_option( 'ep_finaluser_contact_email');
	$contact_email_subject = get_option( 'ep_finaluser_contact_email_subject');			
	$admin_mail = get_option('admin_email');	
	if( get_option( 'admin_email_ep_finaluser' )==FALSE ) {
		$admin_mail = get_option('admin_email');						 
		}else{
		$admin_mail = get_option('admin_email_ep_finaluser');								
	}						
	$bcc_message='';
	if( get_option( '_ep_finaluser_bcc_message' ) ) {
		$bcc_message= get_option('_ep_finaluser_bcc_message'); 
	}	
	$wp_title = get_bloginfo();
	parse_str($_POST['form_data'], $form_data);
	$dir_id=$form_data['dir_id'];	
	$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
	$reg_page_user='';
	if($iv_redirect_user!='defult'){
		$reg_page_user= get_permalink( $iv_redirect_user) ;
	} 
	$get_userdata= get_userdata($dir_id);
	$reg_page_u=$reg_page_user.'?&id='.$dir_id;
	$dir_title= '<a href="'.$reg_page_u.'">'.$get_userdata->user_login .'</a>';		
	// Email for Client	
	$user_info = get_userdata( $dir_id);		
	$client_email_address =$user_info->user_email;
	$visitor_email_address='';
	$visitor_email_address=$form_data['email_address'];
	$email_body = str_replace("[iv_member_sender_email]", $form_data['email_address'], $email_body);
	$email_body = str_replace("[iv_member_directory]", $dir_title, $email_body);
	$email_body = str_replace("[iv_member_message]", $form_data['message-content'], $email_body);	
	$auto_subject=  $contact_email_subject; 
	$headers = array("From: " . $wp_title . " <" . $admin_mail . ">", "Reply-To: ".$client_email_address  ,"Content-Type: text/html");
	$h = implode("\r\n", $headers) . "\r\n";
	wp_mail($client_email_address, $auto_subject, $email_body, $h);
	// Contact Email 
	$contact_email= get_post_meta($dir_id,'contact-email',true); 
	if($client_email_address!=$contact_email){
		$h = implode("\r\n", $headers) . "\r\n";
		wp_mail($contact_email, $auto_subject, $email_body, $h);	
	}	
	if($bcc_message=='yes'){
		$h = implode("\r\n", $headers) . "\r\n";
		wp_mail($admin_mail, $auto_subject, $email_body, $h);	
	}	
	//***************************** BuddyPress
	if ( is_user_logged_in() ) {					
		if(function_exists('bp_is_active')){				
			global $bp, $wpdb;
			$current_user = wp_get_current_user();
			$user_id=$current_user->ID;					
			$sql="SELECT * FROM ".$wpdb->prefix."bp_messages_messages group by thread_id";
			$all_thread = $wpdb->get_results($sql);
			$thread_count =count($all_thread);
			$thread_id= $thread_count+1;
			$i=0;
			// Messages******************
			$wpdb->insert($wpdb->prefix.'bp_messages_messages', array(
			'thread_id' => $thread_id,
			'sender_id' => $user_id,
			'subject' => $auto_subject, 
			'message' => $form_data['message-content'], 
			'date_sent' => current_time('mysql', 1), 							
			));
			$lastid = $wpdb->insert_id;	
			// sender_only
			$wpdb->insert($wpdb->prefix.'bp_messages_recipients', array(
			'user_id' => $user_id,
			'thread_id' => $thread_id,
			'unread_count' => '0', 
			'sender_only' => '1', 						
			));
			$recipient=$dir_id;		
			// sender_only
			$wpdb->insert($wpdb->prefix.'bp_messages_recipients', array(
			'user_id' => $recipient,
			'thread_id' => $thread_id,
			'unread_count' => '1', 
			'sender_only' => '0', 						
			));							
			// wp_bp_notifications 
			$wpdb->insert($wpdb->prefix.'bp_notifications', array(
			'user_id' => $recipient ,
			'item_id' => $lastid,
			'secondary_item_id' => $user_id, 
			'component_name' => 'messages', 		
			'component_action' => 'new_message', 	
			'date_notified' => current_time('mysql', 1), 	
			'is_new' => '1', 					
			));
		}				
	}	