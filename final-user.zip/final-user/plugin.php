<?php
	/**
		*
		*
		* @version 1.2.5
		* @package Main
		* @author e-plugin.com
	*/
	/*
		Plugin Name: Final User - WP Front-end User Profiles
		Plugin URI: http://e-plugin.com/
		Description: Build Paid or free user profile site using Wordpress.No programming knowledge required.
		Author: e-plugins
		Author URI: http://e-plugin.com/
		Version: 1.2.5
		Text Domain: finaluser
		License: GPLv3
	*/
	// Exit if accessed directly
	if (!defined('ABSPATH')) {
		exit;
	}
	if (!class_exists('finaluser')) {  	
		final class finaluser {
			private static $instance;
			/**
				* The Plug-in version.
				*
				* @var string
			*/
			public $version = "1.2.5";
			/**
				* The minimal required version of WordPress for this plug-in to function correctly.
				*
				* @var string
			*/
			public $wp_version = "3.5";
			public static function instance() {
				if (!isset(self::$instance) && !(self::$instance instanceof finaluser)) {
					self::$instance = new finaluser;
				}
				return self::$instance;
			}
			/**
				* Construct and start the other plug-in functionality
			*/
			public function __construct() {
				//
				// 1. Plug-in requirements
				//
				if (!$this->check_requirements()) {
					return;
				}
				//
				// 2. Declare constants and load dependencies
				//
				$this->define_constants();
				$this->load_dependencies();
				//
				// 3. Activation Hooks
				//
				register_activation_hook(__FILE__, array(&$this, 'activate'));
				register_deactivation_hook(__FILE__, array(&$this, 'deactivate'));
				register_uninstall_hook(__FILE__, 'finaluser::uninstall');
				//
				// 4. Load Widget
				//
				add_action('widgets_init', array(&$this, 'register_widget'));
				//
				// 5. i18n
				//
				add_action('init', array(&$this, 'i18n'));
				//
				// 6. Actions
				//
				add_action('wp_ajax_ep_finaluser_user_exist_check', array($this, 'ep_finaluser_user_exist_check'));
				add_action('wp_ajax_nopriv_ep_finaluser_user_exist_check', array($this, 'ep_finaluser_user_exist_check'));
				add_action('wp_ajax_ep_finaluser_check_coupon', array($this, 'ep_finaluser_check_coupon'));
				add_action('wp_ajax_nopriv_ep_finaluser_check_coupon', array($this, 'ep_finaluser_check_coupon'));					
				add_action('wp_ajax_ep_finaluser_check_package_amount', array($this, 'ep_finaluser_check_package_amount'));
				add_action('wp_ajax_nopriv_ep_finaluser_check_package_amount', array($this, 'ep_finaluser_check_package_amount'));
				add_action('wp_ajax_ep_finaluser_update_profile_pic', array($this, 'ep_finaluser_update_profile_pic'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_profile_pic', array($this, 'ep_finaluser_update_profile_pic'));
				add_action('wp_ajax_ep_finaluser_update_background_pic', array($this, 'ep_finaluser_update_background_pic'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_background_pic', array($this, 'ep_finaluser_update_background_pic'));
				add_action('wp_ajax_ep_finaluser_update_profile_setting', array($this, 'ep_finaluser_update_profile_setting'));				
				add_action('wp_ajax_ep_finaluser_update_profile_gallery_image', array($this, 'ep_finaluser_update_profile_gallery_image'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_profile_gallery_image', array($this, 'ep_finaluser_update_profile_gallery_image'));
				add_action('wp_ajax_ep_finaluser_update_profile_doc', array($this, 'ep_finaluser_update_profile_doc'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_profile_doc', array($this, 'ep_finaluser_update_profile_doc'));
				add_action('wp_ajax_ep_finaluser_update_profile_videos', array($this, 'ep_finaluser_update_profile_videos'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_profile_videos', array($this, 'ep_finaluser_update_profile_videos'));
				add_action('wp_ajax_ep_finaluser_save_user_review', array($this, 'ep_finaluser_save_user_review'));
				add_action('wp_ajax_nopriv_ep_finaluser_save_user_review', array($this, 'ep_finaluser_save_user_review'));
				add_action('wp_ajax_ep_finaluser_save_wp_post', array($this, 'ep_finaluser_save_wp_post'));		
				add_action('wp_ajax_ep_finaluser_update_setting_password', array($this, 'ep_finaluser_update_setting_password'));
				add_action('wp_ajax_ep_finaluser_check_login', array($this, 'ep_finaluser_check_login'));
				add_action('wp_ajax_nopriv_ep_finaluser_check_login', array($this, 'ep_finaluser_check_login'));
				add_action('wp_ajax_ep_finaluser_forget_password', array($this, 'ep_finaluser_forget_password'));
				add_action('wp_ajax_nopriv_ep_finaluser_forget_password', array($this, 'ep_finaluser_forget_password'));
				add_action('wp_ajax_ep_finaluser_cancel_stripe', array($this, 'ep_finaluser_cancel_stripe'));
				add_action('wp_ajax_nopriv_ep_finaluser_cancel_stripe', array($this, 'ep_finaluser_cancel_stripe'));
				add_action('wp_ajax_ep_finaluser_cancel_paypal', array($this, 'ep_finaluser_cancel_paypal'));
				add_action('wp_ajax_nopriv_ep_finaluser_cancel_paypal', array($this, 'ep_finaluser_cancel_paypal'));
				add_action('wp_ajax_ep_finaluser_profile_stripe_upgrade', array($this, 'ep_finaluser_profile_stripe_upgrade'));
				add_action('wp_ajax_nopriv_ep_finaluser_profile_stripe_upgrade', array($this, 'ep_finaluser_profile_stripe_upgrade'));		add_action('wp_ajax_ep_finaluser_cpt_change', array($this, 'ep_finaluser_cpt_change'));
				add_action('wp_ajax_nopriv_ep_finaluser_cpt_change', array($this, 'ep_finaluser_cpt_change'));	
				add_action('wp_ajax_ep_finaluser_paypal_notify_url', array($this, 'ep_finaluser_paypal_notify_url'));
				add_action('wp_ajax_nopriv_ep_finaluser_paypal_notify_url', array($this, 'ep_finaluser_paypal_notify_url'));	
				add_action('wp_ajax_ep_finaluser_message_send', array($this, 'ep_finaluser_message_send'));
				add_action('wp_ajax_nopriv_ep_finaluser_message_send', array($this, 'ep_finaluser_message_send'));	
				add_action('wp_ajax_ep_finaluser_save_facebooksetting', array($this, 'ep_finaluser_save_facebooksetting'));
				add_action('wp_ajax_ep_finaluser_claim_send', array($this, 'ep_finaluser_claim_send'));
				add_action('wp_ajax_nopriv_ep_finaluser_claim_send', array($this, 'ep_finaluser_claim_send'));	
				add_action('wp_ajax_ep_remove_notification', array($this, 'ep_remove_notification'));
				add_action('wp_ajax_nopriv_ep_remove_notification', array($this, 'ep_remove_notification'));
				add_action('wp_ajax_ep_finaluser_inbox_message_reply', array($this, 'ep_finaluser_inbox_message_reply'));
				add_action('wp_ajax_ep_finaluser_inbox_message_sent', array($this, 'ep_finaluser_inbox_message_sent'));					
				add_action('wp_ajax_ep_finaluser_cron_job', array($this, 'ep_finaluser_cron_job'));
				add_action('wp_ajax_nopriv_ep_finaluser_cron_job', array($this, 'ep_finaluser_cron_job'));	
				add_action('wp_ajax_ep_finaluser_update_profile_billing', array($this, 'ep_finaluser_update_profile_billing'));
				add_action('wp_ajax_nopriv_ep_finaluser_update_profile_billing', array($this, 'ep_finaluser_update_profile_billing'));
				add_action('wp_ajax_ep_finaluser_update_profile_shipping', array($this, 'ep_finaluser_update_profile_shipping'));
				add_action('wp_ajax_ep_finaluser_loadmore', array($this, 'ep_finaluser_loadmore'));
				add_action('wp_ajax_nopriv_ep_finaluser_loadmore', array($this, 'ep_finaluser_loadmore'));
				add_action('wp_ajax_ep_finaluser_update_wp_post', array($this, 'ep_finaluser_update_wp_post'));				
				//follow
				add_action('wp_ajax_uou_tigerp_save_follow', array($this, 'uou_tigerp_save_follow'));
				add_action('wp_ajax_nopriv_uou_tigerp_save_follow', array($this, 'uou_tigerp_save_follow'));
				add_action('wp_ajax_uou_tigerp_save_un_follow', array($this, 'uou_tigerp_save_un_follow'));
				add_action('wp_ajax_ep_finaluser_make_as_read', array($this, 'ep_finaluser_make_as_read'));
				add_action('wp_ajax_ep_finaluser_make_as_unread', array($this, 'ep_finaluser_make_as_unread'));
				add_action('wp_ajax_ep_finaluser_make_as_delete', array($this, 'ep_finaluser_make_as_delete'));
				add_action('plugins_loaded', array($this, 'start'));	
				add_action( 'init', array($this, 'ep_finaluser_paypal_form_submit') );
				add_action( 'init', array($this, 'ep_finaluser_stripe_form_submit') );
				add_action( 'wp_loaded', array($this, 'ep_finaluser_woocommerce_form_submit') );					
				add_action('wp_login', array($this, 'check_expiry_date'));					
				add_action('pre_get_posts',array($this, 'iv_restrict_media_library') );
				add_action('init', array($this, 'remove_admin_bar') );	
				// For Visual Composer 
				add_action('vc_before_init',array($this, 'dir_vc_signup') );
				add_action('vc_before_init',array($this, 'dir_vc_user_login') );
				add_action('vc_before_init',array($this, 'dir_vc_my_account') );
				add_action('vc_before_init',array($this, 'dir_vc_public_profile') );
				add_action('vc_before_init',array($this, 'dir_vc_user_directory') );										
				// 7. Shortcode						
				add_shortcode('ep_finaluser_price_table', array($this, 'ep_finaluser_price_table_func'));				
				add_shortcode('ep_finaluser_form_wizard', array($this, 'ep_finaluser_form_wizard_func'));
				add_shortcode('ep_finaluser_profile_template', array($this, 'ep_finaluser_profile_template_func'));
				add_shortcode('ep_finaluser_profile_public', array($this, 'ep_finaluser_profile_public_func'));
				add_shortcode('ep_finaluser_login', array($this, 'ep_finaluser_login_func'));
				add_shortcode('ep_finaluser_user_directory', array($this, 'ep_finaluser_user_directory_func'));
				add_shortcode('finaluser_directory_filter', array($this, 'ep_finaluser_directory_filter_func'));
				add_shortcode('slider_search', array($this, 'pd_search_box_func'));
				add_shortcode('ep_finaluser_reminder_email_cron', array($this, 'ep_finaluser_reminder_email_cron_func'));
				// 8. Filter
				add_filter('user_contactmethods', array($this, 'modify_contact_methods') );					
				add_filter( 'template_include', array($this, 'include_template_function'), 9, 2  );	
				add_action( 'template_redirect', array($this,'author_template_redirect' ), 9, 2  );
				add_action( 'init', array($this, 'iv_review_post_type') );	
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'iv_plugin_action_links' ) );						
			}
			/**
				* Define constants needed across the plug-in.
			*/
			private function define_constants() {
				if (!defined('finaluser_BASENAME')) define('finaluser_BASENAME', plugin_basename(__FILE__));				
				if (!defined('finaluser_DIR')) define('finaluser_DIR', dirname(__FILE__));
				if (!defined('finaluser_FOLDER'))define('finaluser_FOLDER', plugin_basename(dirname(__FILE__)));
				if (!defined('finaluser_ABSPATH'))define('finaluser_ABSPATH', trailingslashit(str_replace("\\", "/", WP_PLUGIN_DIR . '/' . plugin_basename(dirname(__FILE__)))));
				if (!defined('finaluser_URLPATH'))define('finaluser_URLPATH', trailingslashit(WP_PLUGIN_URL . '/' . plugin_basename(dirname(__FILE__))));
				if (!defined('finaluser_ADMINPATH'))define('finaluser_ADMINPATH', get_admin_url());
				$filename = get_template_directory()."/finaluser/";
				if (!file_exists($filename)) {					
					if (!defined('finaluser_template'))define( 'finaluser_template', finaluser_ABSPATH.'template/' );
					}else{
					if (!defined('finaluser_template'))define( 'finaluser_template', $filename);
				}	
			}				
			/**
				* Loads PHP files that required by the plug-in
			*/			
			public function remove_admin_bar() {
				$iv_hide = get_option( '_ep_finaluser_hide_admin_bar');
				if(trim($iv_hide) ==''){$iv_hide='yes';}
				if (!current_user_can('administrator') && !is_admin()) {
					if($iv_hide=='yes'){							
						show_admin_bar(false);
					}
				}	
			}
			public function iv_plugin_action_links( $links ) {				
				$plugin_links = array(
				'<a href="admin.php?page=wp-ep_finaluser">' . esc_html__( 'Settings', 'finaluser' ) . '</a>',
				'<a href="'.esc_url('www.help.eplug-ins.com/finaluser/').'">' . esc_html__( 'Docs', 'finaluser' ) . '</a>',				'<a href="'.esc_url('www.codecanyon.net/item/final-user-wp-frontend-user-profiles/22231050/comments').'">' . esc_html__( 'Support', 'finaluser' ) . '</a>',
				);
				return array_merge( $plugin_links, $links );
			}	
			public function include_template_function( $template_path ) {
				$all_re_page = array();
				$all_re_page=get_option('_iv_membership_redirect_page',true);
				$current_role='';
				if(is_user_logged_in()==1){
					global $current_user;
					$user = new WP_User( $current_user->ID );
					if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
						foreach ( $user->roles as $role ){
							$current_role= $role; 
							break;
						}	
					}
					}else{
					$current_role='visitor';
				}	
				
				global $wp;
				$current_url = home_url(add_query_arg(array(),$wp->request));
				$urlmain = parse_url($current_url);
				if(isset($all_re_page['url'])){
					$ii=0;												
					foreach($all_re_page['url'] as $row1){ $save_url='';
						if(isset($all_re_page['url'][$ii])){ 
							if (filter_var($all_re_page['url'][$ii], FILTER_VALIDATE_URL) === FALSE) { 
								}else{ 
								$current_url2= str_replace('/','',$current_url);
								$row_url=str_replace('/','',$all_re_page['url'][$ii]);
								if(strcmp($current_url2,$row_url)==0){
									$blocked_roles=explode(',',$all_re_page['roles'][$ii]);
									if(in_array($current_role,$blocked_roles)){ 
										$redirect_link= get_the_permalink($all_re_page['redirectto'][$ii]);												
										$redirect_link2=str_replace('/','',$redirect_link);											
										if(strcmp($current_url2,$redirect_link2)!=0){// Prevent Infinitte Loop 
											wp_redirect($redirect_link);
											exit();
										}	
									}											
								}
							}									
						}
						$ii++;
					}		
				}
				return $template_path;
			}	
			public function author_template_redirect(){
				if ( is_author() ) {
					$listing_author_link=get_option('listing_author_link');	
					if($listing_author_link==""){$listing_author_link='author';}
					if($listing_author_link=='author'){		
						include( finaluser_template. 'profile-public/single-profile.php' );
						exit;
					}
				}
			}
			public function dir_vc_signup() {
				vc_map( array(
				"name" => esc_html__(  "Signup ", "finaluser" ),
				"base" => "ep_finaluser_form_wizard",
				'icon' =>  finaluser_URLPATH.'/assets/images/vc-icon.png',
				"class" => "",
				"category" => esc_html__(  "finaluser Trainer", "finaluser"),
				"params" => array(
				array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__(  "Style Name", "finaluser" ),
				"param_name" => "Default",
				"value" => esc_html__(  "Default", "finaluser" ),
				"description" => esc_html__(  ".", "finaluser" )
				)
				)
				) );
			}
			public function dir_vc_my_account() {
				vc_map( array(
				"name" => esc_html__(  "My Acount ", "finaluser" ),
				"base" => "ep_finaluser_profile_template",
				'icon' =>  finaluser_URLPATH.'/assets/images/vc-icon.png',
				"class" => "",
				"category" => esc_html__(  "finaluser Trainer", "finaluser"),
				"params" => array(
				array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__(  "Style Name", "finaluser" ),
				"param_name" => "Default",
				"value" => esc_html__(  "Default", "finaluser" ),
				"description" => esc_html__(  ".", "finaluser" )
				)
				)
				) );
			}
			public function dir_vc_public_profile() {
				vc_map( array(
				"name" => esc_html__(  "Public Profile ", "finaluser" ),
				"base" => "ep_finaluser_profile_public",
				'icon' =>  finaluser_URLPATH.'/assets/images/vc-icon.png',
				"class" => "",
				"category" => esc_html__(  "finaluser Trainer", "finaluser"),
				"params" => array(
				array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__(  "Style Name", "finaluser" ),
				"param_name" => "Default",
				"value" => esc_html__(  "Default", "finaluser" ),
				"description" => esc_html__(  "You can select the style from wp-admin e.g : style-1 , style-2 ", "finaluser" )
				)
				)
				) );
			}
			public function dir_vc_user_directory() {
				vc_map( array(
				"name" => esc_html__(  "User Directory ", "finaluser" ),
				"base" => "ep_finaluser_user_directory",
				'icon' =>  finaluser_URLPATH.'/assets/images/vc-icon.png',
				"class" => "",
				"category" => esc_html__(  "finaluser Trainer", "finaluser"),
				"params" => array(
				array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__(  "Show  number of user / Page", "finaluser" ),
				"param_name" => "per_page",
				"value" => esc_html__(  "12", "finaluser" ),
				"description" => esc_html__(  "You can set the number : 10,20 ", "finaluser" )
				)
				)
				) );
			}
			public function dir_vc_user_login() {
				vc_map( array(
				"name" => esc_html__(  "Login", "finaluser" ),
				"base" => "ep_finaluser_login",
				'icon' =>  finaluser_URLPATH.'/assets/images/vc-icon.png',
				"class" => "",
				"category" => esc_html__(  "finaluser Trainer", "finaluser"),
				"params" => array(
				array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__(  " Login", "finaluser" ),
				"param_name" => "style",
				"value" => esc_html__(  "Default", "finaluser" ),
				"description" => esc_html__(  "Default ", "finaluser" )
				)
				)
				) );
			}
			public function author_public_profile() {
				$author = get_the_author();	
				$iv_redirect = get_option( '_ep_finaluser_profile_public_page');
				if($iv_redirect!='defult'){ 
					$reg_page= get_permalink( $iv_redirect) ; 
					return    $reg_page.'?&id='.$author; 
					exit;
				}
			}
			public function iv_registration_redirect(){
				$iv_redirect = get_option( 'ep_finaluser_signup_redirect');
				if($iv_redirect!='defult'){
					$reg_page= get_permalink( $iv_redirect); 
					wp_redirect( $reg_page );
					exit;
				}	
			}
			public function ep_finaluser_login_func(){
				ob_start();	
				global $current_user;		
				if($current_user->ID==0){		
					include(finaluser_template. 'private-profile/profile-login.php');
					}else{						
					include( finaluser_template. 'private-profile/profile-template-1.php');
				}				
				$content = ob_get_clean();
				return $content;
			}
			public function ep_finaluser_forget_password(){
				parse_str($_POST['form_data'], $data_a);
				if( ! email_exists($data_a['forget_email']) ) {
					echo json_encode(array("code" => "not-success","msg"=>"There is no user registered with that email address."));
					exit(0);
					} else {
					require_once( finaluser_ABSPATH. 'inc/forget-mail.php');
					echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
					exit(0);
				}
			}
			public function pd_search_box_func($atts = ''){
				ob_start();	
				include( finaluser_template. 'user-directory/slider-search.php');
				$content = ob_get_clean();
				return $content;
			}
			public function ep_finaluser_update_wp_post(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;global $wpdb;	
				parse_str($_POST['form_data'], $form_data);
				$allowed_html = wp_kses_allowed_html( 'post' );
				$post_status= sanitize_text_field(strtolower(trim($form_data['post_status'])));
				$post_status= ($post_status=='publish'?'pending':$post_status);
				$my_post = array();
				$my_post['ID'] = sanitize_text_field($form_data['user_post_id']);
				$my_post['post_title'] = sanitize_text_field($form_data['title']);
				$my_post['post_content'] = wp_kses( $form_data['edit_post_content'], $allowed_html) ;	
				$my_post['post_status'] = $post_status;
				$curr_post_id=$my_post['ID'];						
				$post_edit = get_post($curr_post_id); 
				if ( $post_edit->post_author != $current_user->ID) {
					echo json_encode(array("code" => "success","msg"=>"This is not your post"));
					exit(0);
				}
				$post_title='';	$edit_post_content='';	
				if(isset($form_data['title'] )){
					$post_title='';
					$post_title=sanitize_text_field($form_data['title']);						 
				}	
				if(isset($form_data['edit_post_content'] )){
					$edit_post_content='';
					$edit_post_content=wp_kses( $form_data['edit_post_content'], $allowed_html);						 
				}
				$query = $wpdb->prepare("UPDATE {$wpdb->prefix}posts SET post_title='%s', post_content='%s', post_status='%s'   WHERE id='%s' LIMIT 1", $post_title,$edit_post_content,$post_status,$form_data['user_post_id']);
				$wpdb->query($query);		
				if(isset($form_data['feature_image_id'] ) AND $form_data['feature_image_id']!='' ){
					$attach_id =sanitize_text_field($form_data['feature_image_id']);
					set_post_thumbnail( $form_data['user_post_id'], $attach_id );
					}else{
					$attach_id='0';
					delete_post_thumbnail( $form_data['user_post_id'] );
				}
				if(isset($form_data['postcats'])){
				}
				$category_ids = array($form_data['postcats']);						
				wp_set_post_categories($form_data['user_post_id'], $form_data['postcats']);
				$custom_fields = get_post_custom($form_data['user_post_id']);
				foreach ( $custom_fields as $field_key => $field_values ) {
					if(!isset($field_values[0])){ continue;}
					if(in_array($field_key,array("_edit_lock","_edit_last"))) {continue;}
					$underscore_str=substr($field_key,0,1);
					if($underscore_str!='_'){
						delete_post_meta($form_data['user_post_id'] ,$field_key); 
					}
				}					
				if(isset($form_data['custom_name'] )){
					$custom_metas= $form_data['custom_name'] ;
					$custom_value = $form_data['custom_value'] ;
					$i=0;
					foreach($custom_metas  as $one_meta){
						if(isset($custom_metas[$i]) and isset($custom_value[$i]) ){
							if($custom_metas[$i] !=''){
								update_post_meta($form_data['user_post_id'], sanitize_text_field($custom_metas[$i]), sanitize_text_field($custom_value[$i])); 
							}
						}
						$i++;	
					}
				}	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_loadmore(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				$loadbutton=esc_html__(  'Load More', 'finaluser' );
				$paged = $_POST['page'];
				$postuser= $_POST['postuser'];
				$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page' => '10',
				'author' => $postuser,
				'paged' => $paged,
				);
				$my_posts = new WP_Query( $args );
				if ( $my_posts->have_posts() ){
					while ( $my_posts->have_posts() ) : $my_posts->the_post() ;
					$post1->ID= $my_posts->post->ID ;
					$content=$content.'<div class="row">
					<div class="col-sm-12">									
					<div class="review-block-title "><h4><strong><a href="'.esc_url( get_the_permalink($post1->ID) ).'">'. get_the_title( $post1->ID).'</a></strong></h4></div>
					<div class="review-block-description ">'. wp_trim_words( $my_posts->post->post_content, 30,'...' ).' <a href="'.esc_url( get_the_permalink($post1->ID) ).'">'.esc_html__(  'More', 'finaluser' ).'</a></div></div></div><hr>';						 
					endwhile;
					}else{
					$loadbutton="";
				}			
				echo json_encode(array("code" => "success","msg"=>$content,"loadbutton"=>$loadbutton));
				exit(0);
			}
			public function ep_finaluser_check_login(){
				parse_str($_POST['form_data'], $form_data);
				global $user;
				$creds = array();
				$creds['user_login'] =$form_data['username'];
				$creds['user_password'] =  $form_data['password'];
				$creds['remember'] =  (isset($form_data['remember']) ?'true' : 'false');
				$secure_cookie = is_ssl() ? true : false;
				$user = wp_signon( $creds, $secure_cookie );
				if ( is_wp_error($user) ) {
					echo json_encode(array("code" => "not-success","msg"=>$user->get_error_message()));
					exit(0);
				}
				if ( !is_wp_error($user) ) {
					$iv_redirect = get_option( '_ep_finaluser_profile_page');
					if($iv_redirect!='defult'){
						if ( function_exists('icl_object_id') ) {
							$iv_redirect = icl_object_id($iv_redirect, 'page', true);
						}	
						$reg_page= get_permalink( $iv_redirect); 
						echo json_encode(array("code" => "success","msg"=>$reg_page));
						exit(0);
					}
				}		
			}
			public function ep_finaluser_cpt_change(){
				$custom_post_type = $_POST['select_data'];
				if($custom_post_type=='post'){
					$cat_type= 'category';
					$args2 = array(
					'type'                     => $custom_post_type,
					'orderby'                  => 'name',
					'order'                    => 'ASC',
					'hide_empty'        	   => false,
					'hierarchical'             => 0,							
					'taxonomy'                 => $cat_type,
					'pad_counts'               => false
					);
					$categories = get_categories( $args2 );
					if ( $categories && !is_wp_error( $categories ) ) {
						$val_cat2='<select name="postcats" id="postcats" class="form-control">';
						$val_cat2=$val_cat2.'<option  value="">'.esc_html__( 'Any Category','finaluser').'</option>';
						foreach ( $categories as $term ) {
							$val_cat2=$val_cat2. '<option  value="'.$term->slug.'" >'.$term->name.'</option>';
						}
						$val_cat2=$val_cat2.'</select>';
					}	
					}else{
					$cat_type= $custom_post_type.'-category';
					$taxonomy = $custom_post_type;
					$terms = get_terms($taxonomy);
					if ( $terms && !is_wp_error( $terms ) ) :										 
					$val_cat2='<select name="postcats" id="postcats" class="form-control">';
					$val_cat2=$val_cat2.'<option  value="">'.esc_html__( 'Any Category','finaluser').'</option>';
					foreach ( $terms as $term ) {
						$val_cat2=$val_cat2. '<option  value="'.$term->slug.'" >'.$term->name.'</option>';
					}
					$val_cat2=$val_cat2.'</select>';
					endif;
				}
				$args3 = array(
				'type'                     => $custom_post_type,				
				'orderby'                  => 'name',
				'order'                    => 'ASC',
				'hide_empty'               => 0,
				'hierarchical'             => 1,
				'exclude'                  => '',
				'include'                  => '',
				'number'                   => '',
				'taxonomy'                 => $custom_post_type.'_tag',
				'pad_counts'               => false
				);
				$tags='';
				$p_tag = get_categories( $args3 );												
				if ( $p_tag && !is_wp_error( $p_tag ) ) :
				foreach ( $p_tag as $term ) {
					$tags=$tags.'<div class="col-md-4"><label class="form-group"><input type="checkbox" name="tag_arr[]" id="tag_arr[]" value="'. $term->slug.'"> '.$term->name.'</label></div>';
				}
				endif;
				echo json_encode(array("msg" => $val_cat2,"tags" => $tags));
				exit(0);
			}
			public function get_unique_user_values(){
				global $wpdb;						
				$res=array();
				$i=0;
				$user_query = new WP_User_Query( array( 'number' => 99999999 ) );		
				foreach($user_query->results as $user) {
					$name_display=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
					$name_display= (trim($name_display)!=""? $name_display :  $user->display_name );
					$res[$i]['value']=$user->ID;
					$res[$i]['label']=$name_display;
					$i++;
				}	
				return json_encode($res);
			}
			public function ep_finaluser_directory_filter_func($atts = ''){
				ob_start();						
				include( finaluser_template. 'user-directory/directory-filter.php');				
				$content = ob_get_clean();
				return $content;	
			}
			public function ep_finaluser_user_directory_func($atts = ''){
				global $current_user;						 
				if(isset($atts['style']) and $atts['style']!="" ){
					$tempale=$atts['style']; 
					}else{
					$tempale=get_option('ep_finaluser_user_directory'); 
				}
				if($tempale==''){
					$tempale='style-2';
				}	
				ob_start();						 
				include( finaluser_template. 'user-directory/directory-template-2.php');
				$content = ob_get_clean();
				return $content;						
			}
			public function ep_finaluser_profile_public_func($atts = '') {						
				ob_start();						 
				include( finaluser_template. 'profile-public/profile-template-2.php');						
				$content = ob_get_clean();	
				return $content;
			}
			public function ep_finaluser_cancel_paypal(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $wpdb;
				global $current_user;
				parse_str($_POST['form_data'], $form_data);
				if( ! class_exists('Paypal' ) ) {
					require_once(finaluser_DIR . '/inc/class-paypal.php');
				}
				$post_name='ep_finaluser_paypal_setting';						
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name ));
				$paypal_id='0';
				if(isset($row->ID )){
					$paypal_id= $row->ID;
				}
				$paypal_api_currency=get_post_meta($paypal_id, 'ep_finaluser_paypal_api_currency', true);
				$paypal_username=get_post_meta($paypal_id, 'ep_finaluser_paypal_username',true);
				$paypal_api_password=get_post_meta($paypal_id, 'ep_finaluser_paypal_api_password', true);
				$paypal_api_signature=get_post_meta($paypal_id, 'ep_finaluser_paypal_api_signature', true);
				$credentials = array();
				$credentials['USER'] = (isset($paypal_username)) ? $paypal_username : '';
				$credentials['PWD'] = (isset($paypal_api_password)) ? $paypal_api_password : '';
				$credentials['SIGNATURE'] = (isset($paypal_api_signature)) ? $paypal_api_signature : '';
				$paypal_mode=get_post_meta($paypal_id, 'ep_finaluser_paypal_mode', true);
				$currencyCode = $paypal_api_currency;
				$sandbox = ($paypal_mode == 'live') ? '' : 'sandbox.';
				$sandboxBool = (!empty($sandbox)) ? true : false;
				$paypal = new Paypal($credentials,$sandboxBool);
				$oldProfile = get_user_meta($current_user->ID,'iv_paypal_recurring_profile_id',true);
				if (!empty($oldProfile)) {
					$cancelParams = array(
					'PROFILEID' => $oldProfile,
					'ACTION' => 'Cancel'
					);
					$paypal -> request('ManageRecurringPaymentsProfileStatus',$cancelParams);
					update_user_meta($current_user->ID,'iv_paypal_recurring_profile_id','');
					update_user_meta($current_user->ID,'iv_cancel_reason', sanitize_text_field($form_data['cancel_text'])); 
					update_user_meta($current_user->ID,'ep_finaluser_payment_status', 'cancel'); 
					echo json_encode(array("code" => "success","msg"=>esc_html__( 'Cancel Successfully', 'finaluser' )));
					exit(0);							
					}else{
					echo json_encode(array("code" => "not","msg"=>"Unable to Cancel "));
					exit(0);	
				}
			}
			public function  ep_finaluser_profile_stripe_upgrade(){
				require_once(finaluser_DIR . '/admin/files/init.php');
				global $wpdb;
				global $current_user;
				parse_str($_POST['form_data'], $form_data);	
				$newpost_id='';
				$post_name='ep_finaluser_stripe_setting';
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name ));
				if(isset($row->ID )){
					$newpost_id= $row->ID;
				}
				$stripe_mode=get_post_meta( $newpost_id,'ep_finaluser_stripe_mode',true);	
				if($stripe_mode=='test'){
					$stripe_api =get_post_meta($newpost_id, 'ep_finaluser_stripe_secret_test',true);	
					}else{
					$stripe_api =get_post_meta($newpost_id, 'ep_finaluser_stripe_live_secret_key',true);	
				}
				\Stripe\Stripe::setApiKey($stripe_api);					
				// For  cancel ----
				$arb_status =	get_user_meta($current_user->ID, 'ep_finaluser_payment_status', true);
				$cust_id = get_user_meta($current_user->ID,'ep_finaluser_stripe_cust_id',true);
				$sub_id = get_user_meta($current_user->ID,'ep_finaluser_stripe_subscrip_id',true);
				if($sub_id!=''){	
					try{
						$iv_cancel_stripe = \Stripe\Customer::retrieve($form_data['cust_id']);
						$iv_cancel_stripe->subscriptions->retrieve($form_data['sub_id'])->cancel();
						} catch (Exception $e) {
					}
					update_user_meta($current_user->ID,'ep_finaluser_payment_status', 'cancel'); 
					update_user_meta($current_user->ID,'ep_finaluser_stripe_subscrip_id','');
				}
				$response='';
				parse_str($_POST['form_data'], $form_data);
				require_once(finaluser_DIR . '/admin/pages/payment-inc/stripe-upgrade.php');
				echo json_encode(array("code" => "success","msg"=>$response));
				exit(0);
			}
			public function ep_finaluser_cancel_stripe(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				require_once(finaluser_DIR . '/admin/files/init.php');
				global $wpdb;
				global $current_user;
				parse_str($_POST['form_data'], $form_data);	
				$newpost_id='';
				$post_name='ep_finaluser_stripe_setting';
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ", $post_name ));
				if(isset($row->ID )){
					$newpost_id= $row->ID;
				}
				$stripe_mode=get_post_meta( $newpost_id,'ep_finaluser_stripe_mode',true);	
				if($stripe_mode=='test'){
					$stripe_api =get_post_meta($newpost_id, 'ep_finaluser_stripe_secret_test',true);	
					}else{
					$stripe_api =get_post_meta($newpost_id, 'ep_finaluser_stripe_live_secret_key',true);	
				}
				parse_str($_POST['form_data'], $form_data);
				\Stripe\Stripe::setApiKey($stripe_api);
				try{
					$iv_cancel_stripe = \Stripe\Customer::retrieve($form_data['cust_id']);
					$iv_cancel_stripe->subscriptions->retrieve($form_data['sub_id'])->cancel();
					} catch (Exception $e) {
				}
				update_user_meta($current_user->ID,'iv_cancel_reason', sanitize_text_field($form_data['cancel_text'])); 
				update_user_meta($current_user->ID,'ep_finaluser_payment_status', 'cancel'); 
				update_user_meta($current_user->ID,'ep_finaluser_stripe_subscrip_id','');
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Cancel Successfully', 'finaluser' )));
				exit(0);
			}
			public function iv_review_post_type() {
				$labels = array(
				'name'                => _x( 'Review', 'Post Type General Name', 'finaluser' ),
				'singular_name'       => _x( 'Review', 'Post Type Singular Name', 'finaluser' ),
				'menu_name'           => esc_html__(  'Review', 'finaluser' ),
				'name_admin_bar'      => esc_html__(  'Review', 'finaluser' ),
				'parent_item_colon'   => esc_html__(  'Parent Item:', 'finaluser' ),
				'all_items'           => esc_html__(  'All Items', 'finaluser' ),
				'add_new_item'        => esc_html__(  'Add New Item', 'finaluser' ),
				'add_new'             => esc_html__(  'Add New', 'finaluser' ),
				'new_item'            => esc_html__(  'New Item', 'finaluser' ),
				'edit_item'           => esc_html__(  'Edit Item', 'finaluser' ),
				'update_item'         => esc_html__(  'Update Item', 'finaluser' ),
				'view_item'           => esc_html__(  'View Item', 'finaluser' ),
				'search_items'        => esc_html__(  'Search Item', 'finaluser' ),
				'not_found'           => esc_html__(  'Not found', 'finaluser' ),
				'not_found_in_trash'  => esc_html__(  'Not found in Trash', 'finaluser' ),
				);
				$args = array(
				'label'               => esc_html__(  'Review', 'finaluser' ),
				'description'         => esc_html__(  'Review ', 'finaluser' ),
				'labels'              => $labels,
				'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'comments', 'post-formats','custom-fields' ),
				'taxonomies'          => array(  'post_tag' ),
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'menu_position'       => 5,
				'show_in_admin_bar'   => true,
				'show_in_nav_menus'   => true,
				'can_export'          => true,
				'has_archive'         => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'capability_type'     => 'post',
				);
				register_post_type( 'iv_review', $args );
			}	
			public function  ep_finaluser_stripe_form_func(){
				require_once(finaluser_ABSPATH.'files/short_code_file/iv_stripe_form_display.php');
			}
			//follow
			public function uou_tigerp_save_follow(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				parse_str($_POST['data'], $form_data);					
				$profile_user_id=$form_data['id'];
				$current_user_id=get_current_user_id();
				$old_favorites= get_user_meta($profile_user_id,'_follower',true);
				$old_favorites = str_replace(get_current_user_id(), '',  $old_favorites);
				$new_favorites=$old_favorites.', '.get_current_user_id();
				update_user_meta($profile_user_id,'_follower',$new_favorites);						
				$old_favorites2=get_user_meta(get_current_user_id(),'_following', true);						
				$old_favorites2 = str_replace($profile_user_id ,'',  $old_favorites2);						
				$new_favorites2=$old_favorites2.', '.$profile_user_id;
				update_user_meta(get_current_user_id(),'_following',$new_favorites2);
				echo json_encode(array("msg" => 'success'));
				exit(0);	
			}
			public function ep_finaluser_make_as_unread(){
				parse_str($_POST['form_data'], $form_data);
				global $wpdb;																		
				$user_id=get_current_user_id();						
				if(sizeof($form_data['selectmail'])>0){
					foreach($form_data['selectmail'] as $thread_id){									
						$query =$wpdb->prepare( "UPDATE {$wpdb->prefix}bp_messages_recipients SET unread_count='1'   WHERE thread_id='%s' AND sender_only=0 AND user_id='%s' LIMIT 1", $thread_id,$user_id);
						$wpdb->query($query);							
					}
				}
				echo json_encode(array("msg" => 'success'));
				exit(0);	
			}
			public function ep_finaluser_make_as_delete(){
				parse_str($_POST['form_data'], $form_data);
				global $wpdb;																		
				$user_id=get_current_user_id();						
				if(sizeof($form_data['selectmail'])>0){
					foreach($form_data['selectmail'] as $thread_id){									
						$query = $wpdb->prepare("UPDATE {$wpdb->prefix}bp_messages_recipients SET is_deleted='1'   WHERE thread_id='%s' AND sender_only=0 AND user_id='%s' LIMIT 1",$thread_id,$user_id );
						$wpdb->query($query);							
					}
				}
				echo json_encode(array("msg" => 'success'));
				exit(0);	
			}
			public function ep_finaluser_make_as_read(){
				parse_str($_POST['form_data'], $form_data);
				global $wpdb;																		
				$user_id=get_current_user_id();						
				if(sizeof($form_data['selectmail'])>0){
					foreach($form_data['selectmail'] as $thread_id){									
						$query = $wpdb->prepare("UPDATE {$wpdb->prefix}bp_messages_recipients SET unread_count='0'   WHERE thread_id='%s' AND sender_only=0 AND user_id='%s' LIMIT 1",$thread_id,$user_id );
						$wpdb->query($query);							
					}
				}
				echo json_encode(array("msg" => 'success'));
				exit(0);	
			}
			public function uou_tigerp_save_un_follow(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				parse_str($_POST['data'], $form_data);					
				$profile_user_id=$form_data['id'];
				$old_favorites= get_user_meta($profile_user_id,'_follower',true);
				$old_favorites = str_replace(get_current_user_id(), '',  $old_favorites);
				update_user_meta($profile_user_id,'_follower',$old_favorites);	
				$old_favorites2=get_user_meta(get_current_user_id(),'_following', true);						
				$old_favorites2 = str_replace($profile_user_id ,'',  $old_favorites2);						
				$new_favorites2=$old_favorites2;
				update_user_meta(get_current_user_id(),'_following',$new_favorites2);
				echo json_encode(array("msg" => 'success'));
				exit(0);	
			}
			
			public function ep_finaluser_update_setting_password(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;
				parse_str($_POST['form_data'], $form_data);						
				if ( wp_check_password( sanitize_text_field($form_data['c_pass']), $current_user->user_pass, $current_user->ID) ){
					if($form_data['r_pass']!=$form_data['n_pass']){
						echo json_encode(array("code" => "not", "msg"=>esc_html__( 'New Password & Re Password are not same.', 'finaluser' )));
						exit(0);
						}else{
						wp_set_password( sanitize_text_field($form_data['n_pass']), $current_user->ID);
						echo json_encode(array("code" => "success","msg"=> esc_html__( 'Updated Successfully', 'finaluser' )));
						exit(0);
					}
					}else{
					echo json_encode(array("code" => "not", "msg"=>esc_html__( 'Current password is wrong. ', 'finaluser' )));
					exit(0);
				}
			}
			public function ep_finaluser_save_wp_post(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;global $wpdb;	
				parse_str($_POST['form_data'], $form_data);
				$allowed_html = wp_kses_allowed_html( 'post' );
				$my_post = array();
				$post_title='';	$edit_post_content='';	
				if(isset($form_data['title'] )){
					$post_title='';
					$post_title=sanitize_text_field($form_data['title']);						 
				}
				$edit_post_content='';	
				if(isset($form_data['new_post_content'] )){									
					$edit_post_content=	wp_kses( $form_data['new_post_content'], $allowed_html) ;			 
				}
				$post_status= sanitize_text_field(strtolower(trim($form_data['post_status'])));
				$post_status= ($post_status=='publish'?'pending':$post_status);
				$my_post['post_title'] = $post_title;
				$my_post['post_content'] = $edit_post_content;
				$my_post['post_status'] = $post_status;
				$newpost_id= wp_insert_post( $my_post );
				$post_type = $form_data['cpt_page'];
				if($post_type!=''){
					$query = $wpdb->prepare("UPDATE {$wpdb->prefix}posts SET post_type='%s' WHERE id='%s' LIMIT 1", $post_type,$newpost_id );
					$wpdb->query($query);										
				}
				// WPML Start******
				if ( function_exists('icl_object_id') ) {
					include_once( WP_PLUGIN_DIR . '/sitepress-multilingual-cms/inc/wpml-api.php' );
					$_POST['icl_post_language'] = $language_code = ICL_LANGUAGE_CODE;
					$query = $wpdb->prepare("UPDATE {$wpdb->prefix}icl_translations SET element_type='post_%s' WHERE element_id='%s' LIMIT 1" ,$post_type,$newpost_id);
					$wpdb->query($query);					
				}
				// End WPML**********
				if(isset($form_data['feature_image_id'] )){
					$attach_id =$form_data['feature_image_id'];
					set_post_thumbnail( $newpost_id, $attach_id );
				}
				if(isset($form_data['postcats'] )){ 
					wp_set_post_categories($newpost_id, $form_data['postcats'] );
				}
				if(isset($form_data['custom_name'] )){
					$custom_metas= $form_data['custom_name'] ;
					$custom_value = $form_data['custom_value'] ;
					$i=0;
					foreach($custom_metas  as $one_meta){
						if(isset($custom_metas[$i]) and isset($custom_value[$i]) ){
							if($custom_metas[$i] !=''){
								update_post_meta($newpost_id, $custom_metas[$i], sanitize_text_field($custom_value[$i])); 
							}
						}
						$i++;	
					}
				}	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_save_user_review(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;global $wpdb;	
				parse_str($_POST['form_data'], $form_data);						
				$post_type = 'iv_review';
				$my_post= array();						
				$my_post['post_author'] = $form_data['listing_author'];	
				$my_post['post_title'] = sanitize_text_field($form_data['review_subject']);
				$my_post['post_content'] = sanitize_textarea_field($form_data['review_comment']);
				$my_post['post_status'] = 'publish';
				$my_post['post_type'] = 'iv_review';
				$args = array(
				'post_type' => $post_type, 
				'meta_query' =>array(
				'relation' => 'AND',
				array(
				'key'     => 'review_submitter',
				'value'   => $current_user->ID,
				'compare' => '='
				),
				),
				);
				$the_query_review = new WP_Query( $args );
				if ( $the_query_review->have_posts() ) :
				while ( $the_query_review->have_posts() ) : $the_query_review->the_post();
				$id = get_the_ID();
				wp_delete_post($id);
				endwhile;
				endif;
				$newpost_id= wp_insert_post( $my_post );					
				$query = $wpdb->prepare("UPDATE {$wpdb->prefix}posts SET post_type='%s' WHERE id='%s' LIMIT 1",$post_type,$newpost_id   );
				$wpdb->query($query);										
				$review_value=1;
				if(isset($form_data['star']) ){$review_value=$form_data['star'];}
				update_post_meta($newpost_id, 'review_submitter', $current_user->ID); 	
				update_post_meta($newpost_id, 'review_value', $review_value); 	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_videos(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;
				parse_str($_POST['form_data'], $form_data);						
				$i=0;
				for($i=0;$i<60;$i++){
					delete_user_meta($current_user->ID, 'video'.$i); 
				}		
				if(isset($form_data['video'] )){
					$video= $form_data['video'];					
					$i=0;															
					for($i=0;$i<60;$i++){	
						if(isset($video[$i])){
						update_user_meta($current_user->ID, 'video'.$i, $video[$i]); 									}
					}
				}
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_gallery_image(){
				global $current_user;
				parse_str($_POST['form_data'], $form_data);	
				update_user_meta($current_user->ID, 'image_gallery_ids', $form_data['gallery_image_ids']); 
				$Specialities =esc_html__( 'Aerial, Architecture, Automotive, Event, Fashion, Food, Interior, Lifestye, Maternity,Newborns, Nature,Land','finaluser');
				$field_set=get_option('_dir_specialties' );
				if($field_set!=""){
					$Specialities=get_option('_dir_specialties' );
				}
				$i=1;
				$Specialities_fields= explode(",",$Specialities);
				foreach ( $Specialities_fields as $field_value ) { 
					$new_field_value=str_replace(' ','', $field_value);
					delete_user_meta($current_user->ID, 'sphotos_ids_'.$new_field_value); 
				}
				$profile_specialities='';
				foreach ( $Specialities_fields as $field_value ) { 
					$new_field_value=str_replace(' ','', $field_value);
					$new_field_value=str_replace('/','', $new_field_value);
					$new_field_value=str_replace('&','', $new_field_value);
					$new_field_value=str_replace("'",'', $new_field_value);
					update_user_meta($current_user->ID, 'sphotos_ids_'.$new_field_value, $form_data['gallery_ids_'.$new_field_value]); 
					if($form_data['gallery_ids_'.$new_field_value]!=''){ 								
						$profile_specialities=trim($profile_specialities).','.trim($field_value);
					}						
				}
				$specialties=get_user_meta($current_user->ID, 'specialties', true);
				$specialities_fields= explode(",",$Specialities);
				if(sizeof($specialities_fields)<1){ 
					update_user_meta($current_user->ID, 'specialties', $profile_specialities); 
				}
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_doc(){
				global $current_user;
				parse_str($_POST['form_data'], $form_data);	
				update_user_meta($current_user->ID, 'profile_doc_ids', $form_data['gallery_doc_ids']); 	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_shipping(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;			
				parse_str($_POST['form_data'], $form_data);		
				update_user_meta($current_user->ID,'shipping_first_name', sanitize_text_field($form_data['first_name'])); 
				update_user_meta($current_user->ID,'shipping_last_name', sanitize_text_field($form_data['last_name'])); 
				update_user_meta($current_user->ID,'shipping_company', sanitize_text_field($form_data['company'])); 
				update_user_meta($current_user->ID,'shipping_phone', sanitize_text_field($form_data['phone'])); 
				update_user_meta($current_user->ID,'shipping_address_1', sanitize_text_field($form_data['address'])); 
				update_user_meta($current_user->ID,'shipping_address_2', sanitize_text_field($form_data['address']));
				update_user_meta($current_user->ID,'shipping_city', sanitize_text_field($form_data['city']));	
				update_user_meta($current_user->ID,'shipping_state', sanitize_text_field($form_data['state']));						
				update_user_meta($current_user->ID,'shipping_postcode', sanitize_text_field($form_data['zip']));	
				update_user_meta($current_user->ID,'shipping_country', sanitize_text_field($form_data['country']));	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_billing(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;			
				parse_str($_POST['form_data'], $form_data);		
				update_user_meta($current_user->ID,'billing_first_name', sanitize_text_field($form_data['first_name'])); 
				update_user_meta($current_user->ID,'billing_last_name', sanitize_text_field($form_data['last_name'])); 
				update_user_meta($current_user->ID,'billing_company', sanitize_text_field($form_data['company'])); 
				update_user_meta($current_user->ID,'billing_phone', sanitize_text_field($form_data['phone'])); 
				update_user_meta($current_user->ID,'billing_address_1', sanitize_text_field($form_data['address'])); 
				update_user_meta($current_user->ID,'billing_address_2', sanitize_text_field($form_data['address']));
				update_user_meta($current_user->ID,'billing_city', sanitize_text_field($form_data['city']));	
				update_user_meta($current_user->ID,'billing_state', sanitize_text_field($form_data['state']));						
				update_user_meta($current_user->ID,'billing_postcode', sanitize_text_field($form_data['zip']));	
				update_user_meta($current_user->ID,'billing_country', sanitize_text_field($form_data['country']));	
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function ep_finaluser_update_profile_setting(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				global $current_user;
				parse_str($_POST['form_data'], $form_data);	
				if(array_key_exists('wp_capabilities',$form_data)){
					wp_die( 'Are you cheating:wp_capabilities?' );		
				}	
				foreach ( $form_data as $field_key => $field_value ) { 
					if($field_key!='wp_capabilities'){
						update_user_meta($current_user->ID,$field_key, sanitize_text_field($field_value)); 
					}
				}
				update_user_meta($current_user->ID,'profile_title', sanitize_text_field($form_data['profile_title'])); 
				update_user_meta($current_user->ID,'description', sanitize_textarea_field($form_data['about'])); 
				update_user_meta($current_user->ID,'twitterp', sanitize_text_field($form_data['twitter'])); 
				update_user_meta($current_user->ID,'facebookp', sanitize_text_field($form_data['facebook'])); 
				update_user_meta($current_user->ID,'gplusp', sanitize_text_field($form_data['gplus']));
				update_user_meta($current_user->ID,'pinterestp', sanitize_text_field($form_data['pinterest'])); 
				update_user_meta($current_user->ID,'instagramp', sanitize_text_field($form_data['instagram'])); 
				update_user_meta($current_user->ID,'vimeop', sanitize_text_field($form_data['vimeo'])); 
				update_user_meta($current_user->ID,'youtubep', sanitize_text_field($form_data['youtube'])); 
				update_user_meta($current_user->ID,'linkedinp', sanitize_text_field($form_data['linkedin']));
				update_user_meta($current_user->ID,'weekday', sanitize_text_field($form_data['weekday']));	
				update_user_meta($current_user->ID,'weekend', sanitize_text_field($form_data['weekend']));	
				update_user_meta($current_user->ID,'rate_hourly', sanitize_text_field($form_data['rate_hourly']));	
				update_user_meta($current_user->ID,'daily_rate', sanitize_text_field($form_data['daily_rate']));	
				update_user_meta($current_user->ID,'service_type', sanitize_text_field($form_data['service_type']));	
				update_user_meta($current_user->ID,'address', sanitize_text_field($form_data['address']));					
				update_user_meta($current_user->ID,'latitude', sanitize_text_field($form_data['latitude']));
				update_user_meta($current_user->ID,'longitude', sanitize_text_field($form_data['longitude']));	
				update_user_meta($current_user->ID,'city', sanitize_text_field($form_data['city']));	
				update_user_meta($current_user->ID,'state', sanitize_text_field($form_data['state']));	
				update_user_meta($current_user->ID,'country', sanitize_text_field($form_data['country']));	
				if(isset($form_data['available'])){
					update_user_meta($current_user->ID,'available', sanitize_text_field($form_data['available']));	
					}else{
					update_user_meta($current_user->ID,'available', '');	
				}
				$dir_lat=$form_data['latitude'];
				$dir_lng=$form_data['longitude'];
				$address = $form_data['address'];
				if($address!=''){
					if($dir_lat=='' || $dir_lng==''){
						$latitude='';$longitude='';
						$prepAddr = str_replace(' ','+',$address);
						$geocode=file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&sensor=false');
						$output= json_decode($geocode);
						if(isset( $output->results[0]->geometry->location->lat)){
							$latitude = $output->results[0]->geometry->location->lat;
						}
						if(isset($output->results[0]->geometry->location->lng)){
							$longitude = $output->results[0]->geometry->location->lng;
						}
						if($latitude!=''){
							update_user_meta($current_user->ID,'latitude',$latitude);
						}
						if($longitude!=''){
							update_user_meta($current_user->ID,'longitude',$longitude);
						}
					}
				}	
				$i=0;
				for($i=0;$i<20;$i++){
					delete_user_meta($current_user->ID, 'language'.$i); 							
					delete_user_meta($current_user->ID, 'language_status'.$i);							
				}		
				if(isset($form_data['languages'] )){
					$languages= $form_data['languages'];
					$language_level= $form_data['language_level'];	
					$i=0;															
					for($i=0;$i<20;$i++){							
						if(isset($languages[$i])){
							update_user_meta($current_user->ID, 'language'.$i, sanitize_text_field($languages[$i])); 
						}
						if(isset($language_level[$i])){
							update_user_meta($current_user->ID, 'language_status'.$i, sanitize_text_field($language_level[$i])); 
						}							
					}
				}
				$i=0;
				for($i=0;$i<30;$i++){										
					delete_user_meta($current_user->ID, 'misc'.$i);	
				}		
				if(isset($form_data['misc'] )){								
					$misc= $form_data['misc'];	
					$i=0;															
					for($i=0;$i<30;$i++){
						if(isset($misc[$i])){
							update_user_meta($current_user->ID, 'misc'.$i, sanitize_text_field($misc[$i])); 
						}
					}
				}
				// camera lens misc
				$specialties='';
				foreach ($form_data['specialties'] as $specialty){
					$specialties= $specialties.','. sanitize_text_field($specialty);
				}
				update_user_meta($current_user->ID, 'specialties', $specialties); 
				echo json_encode(array("code" => "success","msg"=>esc_html__( 'Updated Successfully', 'finaluser' )));
				exit(0);
			}
			public function modify_contact_methods($profile_fields) {
				// Add new fields
				$profile_fields['phone'] = 'Phone Number';
				$profile_fields['twitterp'] = 'Twitter Username';
				$profile_fields['facebookp'] = 'Facebook URL';
				$profile_fields['gplusp'] = 'Google+ URL';
				$profile_fields['linkedinp'] = 'Linkedin';
				$profile_fields['pinterestp'] = 'Pinterest';
				$profile_fields['instagramp'] = 'Instagram';
				$profile_fields['vimeop'] = 'vimeo';
				$profile_fields['youtubep'] = 'youtube';
				return $profile_fields;
			}
			public function iv_restrict_media_library( $wp_query ) {
				if(!function_exists('wp_get_current_user')) { include(ABSPATH . "wp-includes/pluggable.php"); }
				global $current_user, $pagenow;
				
				if( is_admin() && !current_user_can('edit_others_posts') ) {
					$wp_query->set( 'author', $current_user->ID );
					add_filter('views_edit-post', 'fix_post_counts');
					add_filter('views_upload', 'fix_media_counts');
				}
			}
			public function check_expiry_date($user) {
				require_once(finaluser_DIR . '/inc/check_expire_date.php');
			}
			public function ep_finaluser_update_profile_pic(){
				global $current_user;
				if(isset($_REQUEST['profile_pic_url_1'])){
					$iv_profile_pic_url=$_REQUEST['profile_pic_url_1'];
					$attachment_thum=$_REQUEST['attachment_thum'];
					}else{
					$iv_profile_pic_url='';
					$attachment_thum='';
				}
				update_user_meta($current_user->ID, 'iv_profile_pic_thum', $attachment_thum);					
				update_user_meta($current_user->ID, 'iv_profile_pic_url', $iv_profile_pic_url);
				echo json_encode('success');
				exit(0);
			}
			public function ep_finaluser_update_background_pic(){
				global $current_user; 
				$attachment_id="";
				if(isset($_REQUEST['profile_pic_url_1'])){
					$iv_profile_pic_url=$_REQUEST['profile_pic_url_1'];
					$attachment_thum=$_REQUEST['attachment_thum']; 
					$attachment_id=$_REQUEST['finaluser_background_id'];
					}else{
					$iv_profile_pic_url='';
					$attachment_thum='';
					$attachment_id='';
				}
				update_user_meta($current_user->ID, 'ivfinaluser_background_id', $attachment_id);	
				update_user_meta($current_user->ID, 'iv_background_pic_thum', $attachment_thum);					
				update_user_meta($current_user->ID, 'iv_background_pic_url', $iv_profile_pic_url);					
				echo json_encode('success');
				exit(0);
			}
			public function ep_finaluser_paypal_form_submit(  ) {
				require_once(finaluser_DIR . '/admin/pages/payment-inc/paypal-submit.php');
			}	
			public function ep_finaluser_stripe_form_submit(  ) {
				require_once(finaluser_DIR . '/admin/pages/payment-inc/stripe-submit.php');
			}
			public function ep_finaluser_woocommerce_form_submit(  ) {
				require_once(finaluser_DIR . '/admin/pages/payment-inc/woo-submit.php');
			}
			public function ep_finaluser_check_coupon(){
				global $wpdb;
				$coupon_code=$_REQUEST['coupon_code'];
				$package_id=$_REQUEST['package_id'];			
				$package_amount=get_post_meta($package_id, 'ep_finaluser_package_cost',true);
				$api_currency =$_REQUEST['api_currency'];
				$post_cont = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_title = '%s' and  post_type='iv_coupon'" ,$coupon_code ));	
				if(sizeof($post_cont)>0 && $package_amount>0){
					$coupon_name = $post_cont->post_title;
					$current_date=$today = date("m/d/Y");
					$start_date=get_post_meta($post_cont->ID, 'iv_coupon_start_date', true);
					$end_date=get_post_meta($post_cont->ID, 'iv_coupon_end_date', true);
					$coupon_used=get_post_meta($post_cont->ID, 'iv_coupon_used', true);
					$coupon_limit=get_post_meta($post_cont->ID, 'iv_coupon_limit', true);
					$dis_amount=get_post_meta($post_cont->ID, 'iv_coupon_amount', true);							 
					$package_ids =get_post_meta($post_cont->ID, 'iv_coupon_pac_id', true);
					$all_pac_arr= explode(",",$package_ids);
					$today_time = strtotime($current_date);
					$start_time = strtotime($start_date);
					$expire_time = strtotime($end_date);
					if(in_array('0', $all_pac_arr)){
						$pac_found=1;
						}else{
						if(in_array($package_id, $all_pac_arr)){
							$pac_found=1;
							}else{
							$pac_found=0;
						}
					}
					$recurring = get_post_meta( $package_id,'ep_finaluser_package_recurring',true); 
					if($today_time >= $start_time && $today_time<=$expire_time && $coupon_used<=$coupon_limit && $pac_found == '1' && $recurring!='on' ){
						$total = $package_amount -$dis_amount;
						$coupon_type= get_post_meta($post_cont->ID, 'iv_coupon_type', true);
						if($coupon_type=='percentage'){
							$dis_amount= $dis_amount * $package_amount/100;
							$total = $package_amount -$dis_amount ;
						}
						echo json_encode(array('code' => 'success',
						'dis_amount' => $dis_amount.' '.$api_currency,
						'gtotal' => $total.' '.$api_currency,
						'p_amount' => $package_amount.' '.$api_currency,
						));
						exit(0);
						}else{
						$dis_amount='';
						$total=$package_amount;
						echo json_encode(array('code' => 'not-success-2',
						'dis_amount' => '',
						'gtotal' => $total.' '.$api_currency,
						'p_amount' => $package_amount.' '.$api_currency,
						));
						exit(0);
					}
					}else{
					if($package_amount=="" or $package_amount=="0"){$package_amount='0';}
					$dis_amount='';
					$total=$package_amount;
					echo json_encode(array('code' => 'not-success-1',
					'dis_amount' => '',
					'gtotal' => $total.' '.$api_currency,
					'p_amount' => $package_amount.' '.$api_currency,
					));
					exit(0);
				}
			}
			public function ep_finaluser_check_package_amount(){
				global $wpdb;
				$coupon_code=isset($_REQUEST['coupon_code']);
				$package_id=$_REQUEST['package_id'];
				if( get_post_meta( $package_id,'ep_finaluser_package_recurring',true) =='on'  ){
					$package_amount=get_post_meta($package_id, 'ep_finaluser_package_recurring_cost_initial', true);			
					}else{					
					$package_amount=get_post_meta($package_id, 'ep_finaluser_package_cost',true);
				}
				$api_currency =$_REQUEST['api_currency'];
				$post_cont = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_title = '%s' and  post_type='iv_coupon'",$coupon_code  ));	
				if(sizeof($post_cont)>0){
					$coupon_name = $post_cont->post_title;
					$current_date=$today = date("m/d/Y");
					$start_date=get_post_meta($post_cont->ID, 'iv_coupon_start_date', true);
					$end_date=get_post_meta($post_cont->ID, 'iv_coupon_end_date', true);
					$coupon_used=get_post_meta($post_cont->ID, 'iv_coupon_used', true);
					$coupon_limit=get_post_meta($post_cont->ID, 'iv_coupon_limit', true);
					$dis_amount=get_post_meta($post_cont->ID, 'iv_coupon_amount', true);							 
					$package_ids =get_post_meta($post_cont->ID, 'iv_coupon_pac_id', true);
					$all_pac_arr= explode(",",$package_ids);
					$today_time = strtotime($current_date);
					$start_time = strtotime($start_date);
					$expire_time = strtotime($end_date);
					$pac_found= in_array($package_id, $all_pac_arr);							
					if($today_time >= $start_time && $today_time<=$expire_time && $coupon_used<=$coupon_limit && $pac_found=="1"){		$total = $package_amount -$dis_amount;
						echo json_encode(array('code' => 'success',
						'dis_amount' => $dis_amount.' '.$api_currency,
						'gtotal' =>$total.' '.$api_currency,
						'p_amount' => $package_amount.' '.$api_currency,
						));
						exit(0);
						}else{
						$dis_amount='--';
						$total=$package_amount;
						echo json_encode(array('code' => 'not-success',
						'dis_amount' => $dis_amount.' '.$api_currency,
						'gtotal' => $total.' '.$api_currency,
						'p_amount' =>$package_amount.' '.$api_currency,
						));
						exit(0);
					}
					}else{
					$dis_amount='--';
					$total=$package_amount;
					echo json_encode(array('code' => 'not-success',
					'dis_amount' => $dis_amount.' '.$api_currency,
					'gtotal' => $total.' '.$api_currency,
					'p_amount' => $package_amount.' '.$api_currency,
					));
					exit(0);
				}
			}
			/**
				* Checks that the WordPress setup meets the plugin requirements
				* @global string $wp_version
				* @return boolean
			*/
			private function check_requirements() {
				global $wp_version;
				if (!version_compare($wp_version, $this->wp_version, '>=')) {
					add_action('admin_notices', 'finaluser::display_req_notice');
					return false;
				}
				return true;
			}
			/**
				* Display the requirement notice
				* @static
			*/
			static function display_req_notice() {
				global $finaluser;
				echo '<div id="message" class="error"><p><strong>';
				echo esc_html__( 'Sorry, BootstrapPress re requires WordPress ' . $finaluser->wp_version . ' or higher.
				Please upgrade your WordPress setup', 'wp-pb');
				echo '</strong></p></div>';
			}
			public function ep_finaluser_user_exist_check(){
				global $wpdb;
				parse_str($_POST['form_data'], $data_a2);
				if(isset($data_a2['contact_captcha'])){
					$captcha_answer="";
					if(isset($data_a2['captcha_answer'])){
						$captcha_answer=$data_a2['captcha_answer'];
					}
					if($data_a2['contact_captcha']!=$captcha_answer){
						echo json_encode('captcha_error');
						exit(0);
					}						
				}
				$userdata = array();
				$user_name='';
				if(isset($data_a2['iv_member_user_name'])){
					$userdata['user_login']=$data_a2['iv_member_user_name'];
				}					
				if(isset($data_a2['iv_member_email'])){
					$userdata['user_email']=$data_a2['iv_member_email'];
				}					
				if(isset($data_a2['iv_member_password'])){
					$userdata['user_pass']=$data_a2['iv_member_password'];
				}
				if($userdata['user_login']!='' and $userdata['user_email']!='' and $userdata['user_pass']!='' ){
					$user_id = username_exists( $userdata['user_login'] );
					if ( !$user_id and email_exists($userdata['user_email']) == false ) {							
						echo json_encode('success');
						exit(0);
						} else {
						echo json_encode('User or Email exists');
						exit(0);
					}
				}
			}
			private function load_dependencies() {
				// Admin Panel
				if (is_admin()) {						
					require_once ('admin/notifications.php');						
					require_once ('admin/admin.php');
				}
				// Front-End Site
				if (!is_admin()) {
				}
				// Global
				require_once ('inc/widget.php');
			}
			/**
				* Called every time the plug-in is activated.
			*/
			public function activate() {
				if (class_exists('finaluserfree')) {  
					deactivate_plugins( '/finalusers-lite/plugin.php', true );
					}else{	
					require_once ('install/install.php');
				}
			}
			/**
				* Called when the plug-in is deactivated.
			*/
			public function deactivate() {
				global $wpdb;			
				$page_name='price-table';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='registration';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='my-account';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='profile';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='thank-you';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='login';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='directory';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);
				$page_name='iv-reminder-email-cron-job';						
				$query = $wpdb->prepare("delete from {$wpdb->prefix}posts where  post_name='%s' LIMIT 1" ,$page_name);
				$wpdb->query($query);			
			}
			/**
				* Called when the plug-in is uninstalled
			*/
			static function uninstall() {
			}
			/**
				* Register the widgets
			*/
			public function register_widget() {
			}
			/**
				* Internationalization
			*/
			public function i18n() {
				load_plugin_textdomain('finaluser', false, basename(dirname(__FILE__)) . '/languages/' );
			}
			/**
				* Starts the plug-in main functionality
			*/
			public function start() {
			}
			public function ep_finaluser_price_table_func($atts = '', $content = '') {							
				ob_start();						
				include( finaluser_template. 'price-table/price-table.php');
				$content = ob_get_clean();	
				return $content;
			}
			public function ep_finaluser_form_wizard_func($atts = '') {
				global $current_user;
				$template_path=finaluser_template.'signup/';
				ob_start();	
				if($current_user->ID==0){
					$signup_access= get_option('users_can_register');	
					if($signup_access=='0'){
						esc_html_e( 'Sorry! You are not allowed for signup.', 'finaluser' );
						}else{
						include( $template_path. 'wizard-style-2.php');
					}
					}else{
					include( finaluser_template. 'private-profile/profile-template-1.php');
				}	
				$content = ob_get_clean();	
				return $content;
			}
			public function ep_finaluser_profile_template_func($atts = '') {
				global $current_user;
				ob_start();
				if($current_user->ID==0){
					require_once(finaluser_template. 'private-profile/profile-login.php');
					}else{
					$tempale=get_option('ep_finaluser_profile-template'); 
					if($tempale=='style-1'){
						include( finaluser_template. 'private-profile/profile-template-1.php');
					}
					if($tempale=='style-2'){
						include( finaluser_template. 'private-profile/profile-template-1.php');
					}
				}
				$content = ob_get_clean();	
				return $content;
			}
			public function ep_finaluser_reminder_email_cron_func ($atts = ''){
				include( finaluser_ABSPATH. 'inc/reminder-email-cron.php');
			}
			public function ep_finaluser_cron_job(){
				include( finaluser_ABSPATH. 'inc/all_cron_job.php');
				exit(0);
			}
			public function directorypro_map_func($atts = ''){
				ob_start();	
				include( finaluser_template. 'directories/directories-map.php');
				$content = ob_get_clean();
				return $content;
			}				
			public function listing_featured_func($atts = ''){
				ob_start();
				include( finaluser_template. 'listing/listing_featured.php');
				$content = ob_get_clean();
				return $content;
			}		
			public function ep_finaluser_paypal_notify_url(){				
				include( finaluser_ABSPATH. 'inc/paypal_deal_notify_mail.php');	
				exit(0);
			}
			public function ep_finaluser_save_facebooksetting(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				parse_str($_POST['form_data'], $form_data);	
				global $current_user;
				$user_id=$current_user->ID;	
				update_user_meta($user_id,'final_fb_data_save_time','');
				update_user_meta($user_id,'final_fb_data_save','');
				update_user_meta($user_id,'final_facebookpage_id',sanitize_text_field($form_data['final_facebookpage_id']));
				update_user_meta($user_id,'final_facebookapp_id',sanitize_text_field($form_data['final_facebookapp_id']));
				update_user_meta($user_id,'final_facebookappsecret',sanitize_text_field($form_data['final_facebookappsecret']));
				update_user_meta($user_id,'final_facebookpost_limit',sanitize_text_field($form_data['final_facebookpost_limit']));
				update_user_meta($user_id,'final_facebookpostlength',sanitize_text_field($form_data['final_facebookpostlength']));
				echo json_encode(array("msg" => 'Saved'));
				exit(0);
			}
			public function ep_finaluser_message_send(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				parse_str($_POST['form_data'], $form_data);					
				include( finaluser_ABSPATH. 'inc/message-mail.php');	
				echo json_encode(array("msg" => 'Message Sent'));
				exit(0);
			}
			public function ep_finaluser_claim_send(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				parse_str($_POST['form_data'], $form_data);					
				include( finaluser_ABSPATH. 'inc/claim-mail.php');	
				echo json_encode(array("msg" => 'Message Sent'));
				exit(0);
			}
			public function ep_remove_notification(){
				if ( ! is_user_logged_in() ) {
					return;
				}
				$current_user = wp_get_current_user();
				$user_id=$current_user->ID;					
				global $bp, $wpdb;
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$bp->core->table_name_notifications} WHERE user_id = %d ", $user_id ) );
				echo json_encode(array("msg" => 'Removed'));
				exit(0);
			}
			public function ep_finaluser_inbox_message_reply(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				if ( ! is_user_logged_in() ) {
					return;
				}
				$allowed_html = wp_kses_allowed_html( 'post' );
				global $bp, $wpdb;
				parse_str($_POST['form_data'], $form_data);	
				$current_user = wp_get_current_user();
				$user_id=$current_user->ID;					
				$this->thread = new BP_Messages_Thread( sanitize_text_field($form_data['thread_id']), 'DESC', $args = array());
				foreach($this->thread->messages as $thread){	
					$subject= $thread->subject;																	
					break;
				}
				$sql=$wpdb->prepare("SELECT * FROM ".$wpdb->prefix."bp_messages_recipients where thread_id='%s' and sender_only=1 LIMIT 1",$form_data['thread_id'] );
				$recipient = $wpdb->get_row($sql);
				$message_owner_id=$recipient->user_id;
				// Messages******************
				$wpdb->insert($wpdb->prefix.'bp_messages_messages', array(
				'thread_id' => sanitize_text_field($form_data['thread_id']),
				'sender_id' => $user_id,
				'subject' => $subject, 
				'message' => wp_kses( $form_data['replycontent'], $allowed_html), 
				'date_sent' => current_time('mysql', 1), 							
				));					
				$lastid = $wpdb->insert_id;
				// For wp_bp_notifications 
				$wpdb->insert($wpdb->prefix.'bp_notifications', array(
				'user_id' => $message_owner_id ,
				'item_id' => $lastid,
				'secondary_item_id' => $user_id, 
				'component_name' => 'messages', 		
				'component_action' => 'new_message', 	
				'date_notified' => current_time('mysql', 1), 	
				'is_new' => '1', 					
				));
				echo json_encode(array("msg" => 'Message Sent'));
				exit(0);
			}
			public function ep_finaluser_inbox_message_sent(){
				if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'settings' ) ) {
					wp_die( 'Are you cheating:wpnonce?' );
				}
				if ( ! is_user_logged_in() ) {
					return;
				}
				global $bp, $wpdb;
				parse_str($_POST['form_data'], $form_data);	
				$current_user = wp_get_current_user();
				$user_id=$current_user->ID;					
				$sql="SELECT * FROM ".$wpdb->prefix."bp_messages_messages group by thread_id";
				$all_thread = $wpdb->get_results($sql);
				$thread_count =count($all_thread);
				$thread_id= $thread_count+1;
				$recipient_ids= $form_data['userids'] ;		
				$i=0;
				// Messages******************
				$allowed_html = wp_kses_allowed_html( 'post' );
				$wpdb->insert($wpdb->prefix.'bp_messages_messages', array(
				'thread_id' => $thread_id,
				'sender_id' => $user_id,
				'subject' => sanitize_text_field($form_data['mail_subject']), 
				'message' => wp_kses( $form_data['replycontent'], $allowed_html), 
				'date_sent' => current_time('mysql', 1), 							
				));
				$lastid = $wpdb->insert_id;	
				// sender_only
				$wpdb->insert($wpdb->prefix.'bp_messages_recipients', array(
				'user_id' => $user_id,
				'thread_id' => $thread_id,
				'unread_count' => '0', 
				'sender_only' => '1', 						
				));
				if($recipient_ids==''){ 
					$recipient_ids=array();
					if(trim($form_data['mail_to'])!=''){ 
						$field_ids=explode (',',$form_data['mail_to']);
						foreach($field_ids as $field_id){							
							$user_input = get_user_by('login',$field_id);
							if($user_input)
							{
								$recipient_ids[] =$user_input->ID;
							}
						}
					}	
				}
				foreach($recipient_ids  as $recipient){										
					// sender_only
					$wpdb->insert($wpdb->prefix.'bp_messages_recipients', array(
					'user_id' => $recipient,
					'thread_id' => $thread_id,
					'unread_count' => '1', 
					'sender_only' => '0', 						
					));							
					// wp_bp_notifications 
					$wpdb->insert($wpdb->prefix.'bp_notifications', array(
					'user_id' => $recipient ,
					'item_id' => $lastid,
					'secondary_item_id' => $user_id, 
					'component_name' => 'messages', 		
					'component_action' => 'new_message', 	
					'date_notified' => current_time('mysql', 1), 	
					'is_new' => '1', 					
					));
					// email template send start******************	
					$admin_mail = get_option('admin_email');	
					if( get_option( 'admin_email_ep_finaluser' )==FALSE ) {
						$admin_mail = get_option('admin_email');						 
						}else{
						$admin_mail = get_option('admin_email_ep_finaluser');								
					}		
					$email_body = get_option( 'ep_finaluser_contact_email');
					$contact_email_subject = sanitize_text_field($form_data['mail_subject']);			
					$user_info = get_userdata( $recipient);	
					$client_email_address =$user_info->user_email;
					$email_body = str_replace("Sender Email:", " ", $email_body);
					$email_body = str_replace("Your Directory :", " ", $email_body);
					$email_body = str_replace("[iv_member_sender_email]", " ", $email_body);
					$email_body = str_replace("[iv_member_directory]", " ", $email_body);
					$email_body = str_replace("[iv_member_message]", $form_data['replycontent'], $email_body);								
					$headers = array("From: " . $wp_title . " <" . $admin_mail . ">", "Reply-To: ".$client_email_address  ,"Content-Type: text/html");
					$h = implode("\r\n", $headers) . "\r\n";
					wp_mail($client_email_address, $contact_email_subject, $email_body, $h);
					//email template send End***********************
				}
				echo json_encode(array("msg" => 'Message Sent'));
				exit(0);
			}
			public function paging() {
				global $wp_query;
			} 
			public function check_write_access($arg=''){
				$current_user = wp_get_current_user();
				$userId=$current_user->ID;
				if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
					return true;
				}		
				$package_id=get_user_meta($userId,'ep_finaluser_package_id',true);
				$access=get_post_meta($package_id, 'ep_finaluser_package_'.$arg, true);
				if($access=='yes'){
					return true;
					}else{
					return false;
				}
			} 
			public function check_reading_access($arg='',$id=0){
				global $post;
				$current_user = wp_get_current_user();
				$userId=$current_user->ID;
				if($id>0){
					$post = get_post($id);
				}			 
				if($post->post_author==$userId){
					return true;
				}
				$package_id=get_user_meta($userId,'ep_finaluser_package_id',true);					 
				$access=get_post_meta($package_id, 'ep_finaluser_package_'.$arg, true);
				$active_module=get_option('_ep_finaluser_active_visibility'); 
				if($active_module=='yes' ){		
					if(isset($current_user->ID) AND $current_user->ID!=''){
						$user_role= $current_user->roles[0];
						if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
							return true;
						}																
						}else{							
						$user_role= 'visitor';
					}	
					$store_array=get_option('_iv_visibility_serialize_role');	
					if(isset($store_array[$user_role]))
					{	
						if(in_array($arg, $store_array[$user_role])){
							return true;
							}else{
							return false;
						}
						}else{ 
						return false;
					}
					}else{
					return true;
				}
			}
			public function get_iv_user_image($cuser_id){
				$profile_buddypress_image=get_option('_profile_buddypress_image');	
				if($profile_buddypress_image==""){$profile_buddypress_image='pluginimage';}
				if($profile_buddypress_image=='pluginimage'){
					$user_image_path=get_user_meta($cuser_id, 'iv_profile_pic_url',true);
					if($user_image_path==''){
						$user_image_path=finaluser_URLPATH.'assets/images/Blank-Profile.jpg';
					}
					}else{
					if(function_exists('bp_is_active')){							
						$user_image_path = bp_core_fetch_avatar(array('html' =>  false, 'item_id' =>  $cuser_id, 'type'=>'full'));	
					}			
				}
				return $user_image_path;
			}
		}
	}
	function ep_finaluserBootstrap() {
		return finaluser::instance();
	}
	ep_finaluserBootstrap();
?>