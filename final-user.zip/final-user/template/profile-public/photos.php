<div class="p-photo-block ">
	<div class="row">
		<?php
			$i=1;
			$package_id=get_user_meta($user_id, 'ep_finaluser_package_id',true);
			$image_limit= get_post_meta($package_id, 'ep_finaluser_image_limit', true);
			if(isset($user->roles[0]) and $user->roles[0]=='administrator'){
				$image_limit=999999;
			}
			if(sizeof($gallery_ids_array)>0){
				foreach($gallery_ids_array as $slide){
					if($slide!=''){
						if($i<=$image_limit){
						?>
						<div class="col-md-4 col-sm-6">
							<a data-fancybox="gallery" href="<?php echo wp_get_attachment_url( $slide ); ?>">
								<img class="img-responsive" src="<?php echo wp_get_attachment_url( $slide ); ?> " >
							</a>
						</div>
						<?php
						}
						$i++;
					}
				}
			}
		?>				
	</div>
</div>