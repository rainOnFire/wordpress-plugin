<div class="p-photo-block ">
	<div class="row">
		<?php
			$package_id=get_user_meta($user_id, 'ep_finaluser_package_id',true);
			$doc_limit= get_post_meta($package_id, 'ep_finaluser_doc_limit', true);
			if(isset($user->roles[0]) and $user->roles[0]=='administrator'){
				$doc_limit=999999;
			}
			$doc_ids=get_user_meta($user_id ,'profile_doc_ids',true);
			$doc_ids_array = array_filter(explode(",", $doc_ids));
			$i=1;
			if(sizeof($doc_ids_array)>0){
				foreach($doc_ids_array as $doc){
					if(trim($doc)!=""){
						if($i<=$doc_limit){
						?>
						<div  class="col-md-3 col-xs-12">
							<div class="panel panel-default">
								<div class="panel-heading"><?php
									$filename_only = basename( get_attached_file( $doc ) );
									echo esc_html($filename_only);
								?></div>
								<div class="panel-body text-center"><a href="<?php echo wp_get_attachment_url( $doc );?>" target="_blank">
									<img src="<?php echo finaluser_URLPATH. "admin/files/images/pdf.png"; ?>">
								</a>
								</div>
							</div>
						</div>
						<?php
						}
					}
					$i++;
				}
			}
		?>
	</div>
</div>