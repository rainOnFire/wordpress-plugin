<?php
get_header();
echo do_shortcode('[ep_finaluser_profile_public]');
get_footer(); 
?>
