<div class="p-photo-block ">
	<div class="row">
		<?php
			$package_id=get_user_meta($user_id, 'ep_finaluser_package_id',true);
			$video_limit= get_post_meta($package_id, 'ep_finaluser_video_limit', true);
			if(isset($user->roles[0]) and $user->roles[0]=='administrator'){
				$video_limit=999999;
			}
			for($i=0;$i<60;$i++){
				if(get_user_meta($user_id,'video'.$i,true)!=''){
					preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', get_user_meta($user_id,'video'.$i,true), $match);
					$youtube_id = $match[1];
					if($i<=$video_limit){
					?>
					<div class="col-md-4 col-sm-6">
						<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo esc_html($youtube_id);?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>	
					</div>
					<?php
					}
				}
			}
		?>
	</div>
</div>