<?php
wp_enqueue_style('ep_finaluser-review', finaluser_URLPATH . 'admin/files/css/reviews.css');
?>
<div class="p-service-content">
	<div class="row">
	    <div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="rating-block">
						<?php
							global $wpdb;
							$total_review_point='';
							$five_review_total='';
							$four_review_total='';
							$three_review_total='';
							$two_review_total='';
							$one_review_total='';
							$post_type='iv_review';
							$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type ='%s'  and post_author='%s' 	and post_status='publish' ORDER BY ID DESC",$post_type,$user_id );
							$reg_page_user='';
							$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
							if($iv_redirect_user!='defult'){
								$reg_page_user= get_permalink( $iv_redirect_user) ;
							}
							$listing_author_link=get_option('listing_author_link');
							if($listing_author_link==""){$listing_author_link='author';}
							$author_reviews = $wpdb->get_results($sql);
							$total_reviews=count($author_reviews);
							if(is_array($total_reviews)){
								$total_review_point=0;
								$one_review_total=0;
								$two_review_total=0;
								$three_review_total=0;
								$four_review_total=0;
								$five_review_total=0;
								foreach ( $author_reviews as $review )
								{
									$review_val=(int)get_post_meta($review->ID,'review_value',true);
									$total_review_point=$total_review_point+ $review_val;
									if($review_val=='1'){
										$one_review_total=$one_review_total+1;
									}
									if($review_val=='2'){
										$two_review_total=$two_review_total+1;
									}
									if($review_val=='3'){
										$three_review_total=$three_review_total+1;
									}
									if($review_val=='4'){
										$four_review_total=$four_review_total+1;
									}
									if($review_val=='5'){
										$five_review_total=$five_review_total+1;
									}
								}
							}
							$avg_review=0;
							if($total_review_point>0){
								$avg_review= $total_review_point/$total_reviews;
							}
						?>
						<h4><?php  esc_html_e('Average rating', 'finaluser'); ?></h4>
						<h2 class="bold padding-bottom-7"><?php echo number_format($avg_review,1,'.',''); ?> / <?php  esc_html_e('5', 'finaluser'); ?></h2>
						<button type="button" class="btn <?php echo ($avg_review>0?'btn-warning': 'btn-default btn-grey');?>  btn-sm" aria-label="Left Align">
							<i class="fa fa-star 3x <?php echo ($avg_review>0?'white-star': 'black-star');?>"></i>
						</button>
						<button type="button" class="btn <?php echo ($avg_review>=2?'btn-warning': 'btn-default btn-grey');?>  btn-sm" aria-label="Left Align">
							<i class="fa fa-star 3x <?php echo ($avg_review>=2?'white-star': 'black-star');?>"></i>
						</button>
						<button type="button" class="btn <?php echo ($avg_review>=3?'btn-warning': 'btn-default btn-grey');?>  btn-sm" aria-label="Left Align">
							<i class="fa fa-star 3x <?php echo ($avg_review>=3?'white-star': 'black-star');?>"></i>
						</button>
						<button type="button" class="btn <?php echo ($avg_review>=4?'btn-warning': 'btn-default btn-grey');?>  btn-sm" aria-label="Left Align">
							<i class="fa fa-star 3x <?php echo ($avg_review>=4?'white-star': 'black-star');?>"></i>
						</button>
						<button type="button" class="btn <?php echo ($avg_review>=5?'btn-warning': 'btn-default btn-grey');?>  btn-sm" aria-label="Left Align">
							<i class="fa fa-star 3x <?php echo ($avg_review>=5?'white-star': 'black-star');?>"></i>
						</button>
					</div>
				</div>
				<div class="col-sm-3">
					<h4><?php  esc_html_e('Rating breakdown', 'finaluser'); ?> </h4>
					<div class="pull-left">
						<div class="pull-left customdiv">
							<div class="divicon"><?php  esc_html_e('5', 'finaluser'); ?> <i class="fa fa-star 3x blue-star"></i></div>
						</div>
						<div class="pull-left width180">
							<div class="progress progressContainer">
								<?php $bar_value=0; if($total_reviews>0){
									$bar_value=($five_review_total/$total_reviews)*100;
								} ?>
								<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width:<?php echo esc_html($bar_value);?>%">
								</div>
							</div>
						</div>
						<div class="pull-right marginleft"><?php echo esc_html($five_review_total);?></div>
					</div>
					<div class="pull-left">
						<div class="pull-left customdiv">
							<div class="divicon"><?php  esc_html_e('4', 'finaluser'); ?> <i class="fa fa-star 3x blue-star"></i></div>
						</div>
						<div class="pull-left width180">
							<div class="progress progressContainer">
								<?php $bar_value=0;
									if($total_reviews>0){
										$bar_value=($four_review_total/$total_reviews)*100;
									}
								?>
								<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo esc_html($bar_value);?>%">
								</div>
							</div>
						</div>
						<div class="pull-right marginleft"><?php echo esc_html($four_review_total);?></div>
					</div>
					<div class="pull-left">
						<div class="pull-left customdiv">
							<div class="divicon"><?php  esc_html_e('3', 'finaluser'); ?> <i class="fa fa-star 3x blue-star"></i></div>
						</div>
						<div class="pull-left width180">
							<div class="progress progressContainer">
								<?php $bar_value=0;
									if($total_reviews>0){
										$bar_value=($three_review_total/$total_reviews)*100;
									}
								?>
								<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo esc_html($bar_value);?>%">
								</div>
							</div>
						</div>
						<div class="pull-right marginleft"><?php echo esc_html($three_review_total);?></div>
					</div>
					<div class="pull-left">
						<div class="pull-left customdiv">
							<div class="divicon"><?php  esc_html_e('2', 'finaluser'); ?> <i class="fa fa-star 3x blue-star"></i></div>
						</div>
						<div class="pull-left width180">
							<div class="progress progressContainer">
								<?php $bar_value=0;
									if($total_reviews>0){
										$bar_value=($two_review_total/$total_reviews)*100;
									}
								?>
								<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo esc_html($bar_value);?>%">
								</div>
							</div>
						</div>
						<div class="pull-right marginleft"><?php echo esc_html($two_review_total);?></div>
					</div>
					<div class="pull-left">
						<div class="pull-left customdiv">
							<div class="divicon"><?php  esc_html_e('1', 'finaluser'); ?> <i class="fa fa-star 3x blue-star"></i></div>
						</div>
						<div class="pull-left width180">
							<div class="progress progressContainer">
								<?php $bar_value=0;
									if($total_reviews>0){
										$bar_value=($one_review_total/$total_reviews)*100;
									}
								?>
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo esc_html($bar_value);?>%">
								</div>
							</div>
						</div>
						<div class="pull-right marginleft"><?php echo esc_html($one_review_total);?></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-7">
					<hr/>
					<div class="review-block">
						<?php
							foreach ( $author_reviews as $review )
							{
								$user_review_val=0;
								$review_submitter=get_post_meta($review->ID, 'review_submitter', true);
								$user_review_val=get_post_meta($review->ID, 'review_value', true);
							?>
							<div class="row">
								<div class="col-sm-3">
									<?php $user_image_path= $this->get_iv_user_image($review_submitter); ?>
									<?php
										$userreview = get_user_by( 'id', $review_submitter );
										$name_display=get_user_meta($review_submitter,'first_name',true).' '.get_user_meta($review_submitter,'last_name',true);
										if($listing_author_link=='author'){
											$reg_page_u= get_author_posts_url($review_submitter);
											}else{
											$reg_page_u=$reg_page_user.'?&id='.$review_submitter;
										}
									?>
									<a href="<?php echo esc_url($reg_page_u);?>"><img src="<?php echo esc_url($user_image_path);?>" class="img-rounded" width="60px;"></a>
									<div class="review-block-name">
										<a href="<?php echo esc_url($reg_page_u);?>">
											<?php
												echo (trim($name_display)!=""? $name_display : $userreview->display_name );
											?>
										</a></div>
										<div class="review-block-date"><?php echo date('M d, Y',strtotime($review->post_date)); ?></div>
								</div>
								<div class="col-sm-9">
									<div class="review-block-rate">
										<button type="button" class="btn <?php echo ($user_review_val>0?'btn-warning': 'btn-default btn-grey');?> btn-xs" aria-label="Left Align">
											<i class="fa fa-star <?php echo ($user_review_val>0?'white-star': 'black-star');?>"></i>
										</button>
										<button type="button" class="btn <?php echo ($user_review_val>1?'btn-warning': 'btn-default btn-grey');?> btn-xs" aria-label="Left Align">
											<i class="fa fa-star <?php echo ($user_review_val>1?'white-star': 'black-star');?>"></i>
										</button>
										<button type="button" class="btn <?php echo ($user_review_val>2?'btn-warning': 'btn-default btn-grey');?> btn-xs" aria-label="Left Align">
											<i class="fa fa-star <?php echo ($user_review_val>2?'white-star': 'black-star');?>"></i>
										</button>
										<button type="button" class="btn <?php echo ($user_review_val>3?'btn-warning': 'btn-default btn-grey');?> btn-xs" aria-label="Left Align">
											<i class="fa fa-star <?php echo ($user_review_val>3?'white-star': 'black-star');?>"></i>
										</button>
										<button type="button" class="btn <?php echo ($user_review_val>4?'btn-warning': 'btn-default btn-grey');?> btn-xs" aria-label="Left Align">
											<i class="fa fa-star <?php echo ($user_review_val>4?'white-star': 'black-star');?>"></i>
										</button>
									</div>
									<div class="review-block-title"><?php echo esc_html($review->post_title); ?></div>
									<div class="review-block-description "><?php echo esc_html($review->post_content); ?></div>
								</div>
							</div>
							<hr>
							<?php
							}
						?>
					</div>
				</div>
			</div>
			<div id="re_form">
				<form id="iv_review_form" name="iv_review_form" class="form-horizontal" role="form" onsubmit="return false;">
					<div class="row">
						<div class="col-sm-7">
							<div class="row"><div class="col-sm-12"><h4><?php  esc_html_e('Submit your review', 'finaluser'); ?></h4></div></div><hr>
							<div class="row">
								<div class="col-sm-3">
									<?php  esc_html_e('Subject', 'finaluser'); ?>
								</div>
								<div class="col-sm-9">
									<input type="text" class="form-control" name="review_subject"   value="" placeholder="<?php  esc_html_e('Enter review title', 'finaluser'); ?>">
								</div>
							</div>
							<div class="row">
								<div class="col-sm-3">
									<?php  esc_html_e('Rating', 'finaluser'); ?>
								</div>
								<div class="col-sm-9">
									<div class="stars">
										<input class="star star-5" id="star-5" type="radio" name="star" value="5"/>
										<label class="star star-5" for="star-5"></label>
										<input class="star star-4" id="star-4" type="radio" name="star" value="4"/>
										<label class="star star-4" for="star-4"></label>
										<input class="star star-3" id="star-3" type="radio" name="star" value="3"/>
										<label class="star star-3" for="star-3"></label>
										<input class="star star-2" id="star-2" type="radio" name="star" value="2" />
										<label class="star star-2" for="star-2"></label>
										<input class="star star-1" id="star-1" type="radio" name="star" value="1" />
										<label class="star star-1" for="star-1"></label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-3">
									<?php  esc_html_e('Comments', 'finaluser'); ?>
								</div>
								<div class="col-sm-9">
									<textarea class="form-control" cols="50"  name="review_comment" id="review_comment" placeholder="<?php  esc_html_e('Enter review comments', 'finaluser'); ?>" rows="5"></textarea>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-12 text-right">
									<button type="button" class="btn btn-default " onclick="return iv_submit_review();">
										<?php  esc_html_e('Submit', 'finaluser'); ?>
									</button>
									<input type="hidden" name="listing_author" value="<?php echo esc_html($user_id); ?>">
									<div id="rmessage"></div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div> 
	</div>
</div>