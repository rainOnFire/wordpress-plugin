   <div class="p-service-content">
            <h1 class="profile_services__header">
               <?php
				$name_display=get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
				echo (trim($name_display)!=""? $name_display : $display_name );?>
            </h1>
            <p class="profile_services__bio">
              <?php echo wpautop(get_user_meta($user_id,'description',true)); ?>
				 <p><?php  esc_html_e('Gender', 'finaluser'); ?>  : <?php  esc_html_e(get_user_meta($user_id,'gender',true), 'finaluser') ;?></p>
				  </p>
			<?php
	        if(trim(get_user_meta($user_id,'service_type',true))!=''){
	        ?>
            <section class="profile_services__types">
              <div class="profile_services__icon">
                <i class="flaticon-wrench"></i>
              </div>
              <h2 class="profile_services__title"><?php  esc_html_e('Service Type', 'finaluser'); ?></h2>
              <ul>
                <li><?php echo get_user_meta($user_id,'service_type',true);?></li>
              </ul>
            </section>
            <?php
			}
            ?>
            	<?php
	        if(trim(get_user_meta($user_id,'weekday',true))!=''){
	        ?>
            <section class=profile_services__availabilities">
              <div class="profile_services__icon">
                <i class="flaticon-time"></i>
              </div>
              <h2 class="profile_services__title"><?php echo esc_html_e('Availabilities', 'finaluser'); ?></h2>
              <ul>
                <li> <?php echo get_user_meta($user_id,'weekday',true);?></li>
                <li><?php echo get_user_meta($user_id,'weekend',true);?> </li>
              </ul>
            </section>
            <?php
						}
            ?>
            	<?php
	        if(trim(get_user_meta($user_id,'rate_hourly',true))!='' OR trim(get_user_meta($user_id,'daily_rate',true))!='' OR trim(get_user_meta($user_id,'available',true))!='no'){
	        ?>
            <section class="profile_services__rates">
              <div class="profile_services__icon">
                <i class="flaticon-money"></i>
              </div>
              <h2 class="profile_services__title"><?php echo esc_html_e('Service Rates', 'finaluser'); ?> </h2>
              <ul>
				  <?php
				  $rate_hourly=get_user_meta($user_id,'rate_hourly',true);
				  $daily_rate= get_user_meta($user_id,'daily_rate',true);
				  if($rate_hourly !='' or $daily_rate!=''){
						if($rate_hourly !='' ){?>
						  <li> <?php echo esc_html_e('Hourly Rate', 'finaluser'); ?> : <?php echo esc_html($rate_hourly);?></li>
						 <?php
						 }
						 if($daily_rate !='' ){?>
						  <li> <?php echo esc_html_e('Daily Rate', 'finaluser'); ?> : <?php echo esc_html($daily_rate);?></li>
						 <?php
						 }
				  }else{ ?>
					<li><a href="#" data-toggle="modal" data-target="#myModalContact"><?php echo esc_html_e('Contact now for a quote', 'finaluser'); ?></a></li>
				<?php
				}
				  ?>
              </ul>
            </section>
			<?php
			}
			?>
		<?php
	        if(trim(get_user_meta($user_id,'language0',true))!='' ){
	        ?>
            <section class="profile_services__languages">
              <div class="profile_services__icon">
                <i class="flaticon-internet"></i>
              </div>
              <h2 class="profile_services__title"><?php echo esc_html_e('Languages', 'finaluser'); ?> </h2>
                <ul>
              <?php
               for($i=0;$i<20;$i++){
				   if(get_user_meta($user_id,'language'.$i,true)!=''){?>
							   <?php echo '<li>'.get_user_meta($user_id,'language_status'.$i,true).' '.get_user_meta($user_id,'language'.$i,true).'</li>';?>
				<?php
					}
				}
              ?>
              </ul>
            </section>
			<?php
				}
			?>
            <section class="profile_services__links">
              <div class="profile_services__icon">
                <i class="flaticon-unlink"></i>
              </div>
              <h2 class="profile_services__title"><?php esc_html_e('Personal Links', 'finaluser'); ?></h2>
              <ul>
				  <?php
				  $contact_web=get_user_meta($user_id,'web_site',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('website', 'finaluser'); ?></a></li>
				<?php
				}
				 $contact_web=get_user_meta($user_id,'facebookp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('facebook page', 'finaluser'); ?></a></li>
				<?php
				}
				 $contact_web=get_user_meta($user_id,'linkedinp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web); 
				 if($contact_web!=''){ ?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('linkedin page', 'finaluser'); ?></a></li>
				<?php
				}
				$contact_web=get_user_meta($user_id,'twitterp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('twitter page', 'finaluser'); ?></a></li>
				<?php
				}
				$contact_web=get_user_meta($user_id,'gplusp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('gplus page', 'finaluser'); ?></a></li>
				<?php
				}
					$contact_web=get_user_meta($user_id,'pinterestp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('pinterest page', 'finaluser'); ?></a></li>
				<?php
				}
				$contact_web=get_user_meta($user_id,'instagramp',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('instagram page', 'finaluser'); ?></a></li>
				<?php
				}
				$contact_web=get_post_meta($user_id,'vimeop',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('vimeo page', 'finaluser'); ?></a></li>
				<?php
				}
				$contact_web=get_user_meta($user_id,'youtubep',true);
				 $contact_web=str_replace('https://','',$contact_web);
				 $contact_web=str_replace('http://','',$contact_web);
				 if($contact_web!=''){?>
						<li><a href="http://<?php echo esc_url($contact_web); ?>" target="_blank""><?php esc_html_e('youtube page', 'finaluser'); ?></a></li>
				<?php
				}
						$default_fields = array();
						$field_set=get_option('ep_finaluser_profile_fields' );
						if($field_set!=""){
							$default_fields=get_option('ep_finaluser_profile_fields' );
						}else{
							$default_fields['first_name']='First Name';
								$default_fields['last_name']='Last Name';
								$default_fields['phone']='Phone Number';
								$default_fields['mobile']='Mobile Number';
								$default_fields['web_site']='Website Url';
						}
						$i=1;
						foreach ( $default_fields as $field_key => $field_value ) {
							if($field_key!='first_name' AND $field_key!='last_name' AND $field_key!='web_site'){
								if($field_value !=''){
								?>
							<li><?php echo get_user_meta($user_id,$field_key,true); ?></li>
						<?php
								}
							}
						}
					?>
              </ul>
            </section>
			<?php
				$Specialities =esc_html__( 'Aerial, Architecture,Automotive, Event, Fashion,Food,Interior, Lifestye, Maternity, Newborns, Nature, Land','finaluser');
					$field_set=get_option('_dir_specialties' );
					if($field_set!=""){
							$Specialities=get_option('_dir_specialties' );
					}
					$i=1;
					$specialties_user_data= get_user_meta($user_id,'specialties',true);
					$specialties_user_data=explode(',', $specialties_user_data);
				if(trim(get_user_meta($user_id,'specialties',true))!=''){
			?>
			 <section class="profile_services__rates">
              <div class="profile_services__icon">
                <i class="flaticon-education"></i>
              </div>
              <h2 class="profile_services__title"><?php echo esc_html_e('Specialties', 'finaluser'); ?> </h2>
				  <ul>
					<?php
					foreach ( $specialties_user_data as $field_value ) { ?>
							<li ><?php echo esc_html($field_value); ?></li>
					<?php
					}
				?>
				  </ul>
            </section>
            <?php
				}
            ?>
	        <?php
	        if(trim(get_user_meta($user_id,'misc0',true))!=''){
	        ?>
            <section class="profile_services__cameras">
              <div class="profile_services__icon">
                <i class="flaticon-electricity"></i>
              </div>
              <h2 class="profile_services__title"><?php esc_html_e('Expertise', 'finaluser'); ?></h2>
              <ul>
				     <?php
               for($i=0;$i<30;$i++){
				   if(get_user_meta($user_id,'misc'.$i,true)!=''){?>
					 <?php echo '<li>'.get_user_meta($user_id,'misc'.$i,true).'</li>';?>
				<?php
					}
				}
              ?>
              </ul>
            </section>
            <?php
				}
            ?>
            <div class="row"></div>
          </div> <!-- end p-service-content -->
        </div>
      </div>
    </div>