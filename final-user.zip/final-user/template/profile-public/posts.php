<div class="p-service-content">
	<div class="row">
		<div class="review-block">
			<?php
				global $wpdb;
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				if($paged==1){
					$offset=0;
					}else {
					$offset= ($paged-1)*$no;
				}
				$no=10;$postID='';
				$args = array();
				$args['post_type']= 'post';
				$args['post_status']= 'publish';
				$args['number']=$no;
				$args['offset']=$offset;
				$args['count_total']=true;
				$args['posts_per_page']=$no;
				$args['author']=$user_id;
				$args['paged']=$paged;
				$loadbutton=esc_html__(  'Load More', 'finaluser' );
				$custom_query = new WP_Query( $args );
				
				if ( $custom_query->have_posts() ){
					while ( $custom_query->have_posts() ) : 						
					$custom_query->the_post();					
					$postID= $custom_query->post->ID;
						
				?>
				<div class="row">
					<div class="col-sm-12">
						<div class="review-block-title "><h4><strong><a href="<?php echo esc_url( get_the_permalink($postID) );?>'"><?php echo get_the_title( $postID); ?></a></strong></h4></div>
						<div class="review-block-description "><?php
							echo wp_trim_words( $custom_query->post->post_content, 30,'...' ).' <a href="'.esc_url( get_the_permalink($postID) ).'">'.esc_html__(  'More', 'finaluser' ).'</a>';
						?>
						</div>
					</div>
				</div>
				<hr>
				<?php endwhile;
					}else{
					$loadbutton="";
				}
			?>
			<div id="loadmore_fupost"></div>
			<div id="loadmore_message"></div>
		</div>
	</div>
	<?php
		if($loadbutton!=''){
		?>
		<div class="text-center" id="loadbuttondiv">
			<a onclick="finaluser_loadmore();" class="btn btn-primary"><span id="loadbutton"><?php echo esc_html($loadbutton); ?></span></a>
		</div>
		<?php
		}
	?>
</div>