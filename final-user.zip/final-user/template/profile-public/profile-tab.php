<?php
	$profile_tab_active=get_option('_pprofile_tab_active');
	if($profile_tab_active==""){$profile_tab_active='pprofile';}
?>
<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
	<?php
		$profile_showtab=get_option('_ep_finaluser_public_pvideos');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Videos','finaluser');
		if( get_option( '_ep_finaluser_pvideos_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_pvideos_text');
		}
		if($profile_showtab=='show'){
		?>
		<li role="presentation" class="<?php echo($profile_tab_active=='pvideos'?"active":"");?>"><a href="#videos" aria-controls="videos" id="tabvideos" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?> </a></li>
		<?php
		}
		$profile_showtab=get_option('_ep_finaluser_public_photos');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Photos','finaluser');
		if( get_option( '_ep_finaluser_pphotos_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_pphotos_text');
		}
		if($profile_showtab=='show'){
		?>
		<li role="presentation" class="<?php echo($profile_tab_active=='pphotos'?"active":"");?>"><a href="#photos" aria-controls="photos" id="tabphotos" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?>  </a></li>
        <?php
		}
		$profile_showtab=get_option('_ep_finaluser_public_pprofile');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Profile','finaluser');
		if( get_option( '_ep_finaluser_pprofile_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_pprofile_text');
		}
		if($profile_showtab=='show'){
		?>
        <li role="presentation"  class=" service-tab <?php echo($profile_tab_active=='pprofile'?"active":"");?>"><a href="#profile" aria-controls="services" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?> </a></li>
        <?php
		}
		$profile_showtab=get_option('_ep_finaluser_public_previews');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Reviews','finaluser');
		if( get_option( '_ep_finaluser_previews_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_previews_text');
		}
		if($profile_showtab=='show'){
		?>
        <li role="presentation"  class=" service-tab <?php echo($profile_tab_active=='previews'?"active":"");?>"><a href="#reviews" aria-controls="photos" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?></a></li>
        <?php
		}
		$profile_showtab=get_option('_ep_finaluser_public_ppost');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Posts','finaluser');
		if( get_option( '_ep_finaluser_ppost_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_ppost_text');
		}
		if($profile_showtab=='show'){
		?>
        <li role="presentation"  class=" service-tab <?php echo($profile_tab_active=='ppost'?"active":"");?>"><a href="#posts" aria-controls="photos" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?></a></li>
        <?php
		}
		$profile_showtab=get_option('_ep_finaluser_public_pdocs');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Docs','finaluser');
		if( get_option( '_ep_finaluser_pdocs_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_pdocs_text');
		}
		if($profile_showtab=='show'){
		?>
        <li role="presentation"  class=" service-tab <?php echo($profile_tab_active=='pdocs'?"active":"");?>"><a href="#docs" aria-controls="docs" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?></a></li>
        <?php
		}
	?>
	<?php
		$profile_showtab=get_option('_ep_finaluser_public_pfacebook');
		if($profile_showtab==""){$profile_showtab='show';}
		$profile_tab_text=esc_html__( 'Facebook Feed','finaluser');
		if( get_option( '_ep_finaluser_public_pfacebook_text' ) ) {
			$profile_tab_text= get_option('_ep_finaluser_public_pfacebook_text');
		}
		if($profile_showtab=='show'){
		?>
        <li role="presentation"  class="service-tab <?php echo($profile_tab_active=='pfacebook'?"active":"");?>"><a href="#facebook" aria-controls="facebook" role="tab" data-toggle="tab"><?php  echo esc_html($profile_tab_text); ?></a></li>
        <?php
		}
	?>
	<?php     $custom_tab = array();
		if(get_option('ep_finaluser_profile_pptab')){
			$custom_tab=get_option('ep_finaluser_profile_pptab' );
		}
        $ii=1;
		if($custom_tab!=''){
			foreach ( $custom_tab as $field_key => $field_value ) { ?>
			<li role="presentation"  class=" service-tab">
				<a href="#<?php  echo esc_html($field_key); ?>" aria-controls="social" role="tab" data-toggle="tab">
					<?php  echo esc_html($field_key); ?>
				</a>
			</li>
			<?php
			}
		}
	?>
</ul>