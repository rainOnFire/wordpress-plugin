<?php
	wp_enqueue_script("jquery");
	wp_enqueue_style('ep_finaluser-piblic-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_script('ep_finaluser-piblic-12', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_style('ep_finaluser-style-67', finaluser_URLPATH . 'assets/font/flaticon.css');
	wp_enqueue_style('user-public-profile-style', finaluser_URLPATH .'admin/files/css/user-public-profile.css', array(), $ver = false, $media = 'all');
	wp_enqueue_style('ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');
	wp_enqueue_script('masonry.pkgd', finaluser_URLPATH . 'admin/files/js/masonry.pkgd.min.js');
	wp_enqueue_style('jquery.fancybox', finaluser_URLPATH . 'admin/files/css/jquery.fancybox.css');
	wp_enqueue_script('jquery.fancybox', finaluser_URLPATH . 'admin/files/js/jquery.fancybox.js');
	wp_enqueue_style('font-awesome', finaluser_URLPATH . 'admin/files/css/font-awesome/css/font-awesome.min.css');
	require(finaluser_DIR .'/admin/files/css/color_style.php');
	$display_name='';
	$email='';
	$user_id=1;
	$author=get_query_var( 'author' );
	global $current_user;
	if($author!=''){
		$user = get_user_by( 'id', $author );
		if(isset($user->ID)){
			$user_id=$user->ID;
			$display_name=$user->display_name;
			$email=$user->user_email;
		}
		}else{
		if(isset($_REQUEST['id'])){
			$author_name= $_REQUEST['id'];
			$user = get_user_by( 'id', $author_name );
			if(isset($user->ID)){
				$user_id=$user->ID;
				$display_name=$user->display_name;
				$email=$user->user_email;
			}
			}else{
			$user_id=$current_user->ID;
			$display_name=$current_user->display_name;
			$email=$current_user->user_email;
			if($user_id==0){
				$user_id=1;
			}
			$user = get_user_by( 'id', $user_id );
		}
	}
	$listing_author_link=get_option('listing_author_link');
	if($listing_author_link==""){$listing_author_link='author';}
	$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
	$reg_page_user='';
	if($iv_redirect_user!='defult'){
		$reg_page_user= get_permalink( $iv_redirect_user) ;
	}
	$profile_buddypress_image=get_option('_profile_buddypress_image');
	if($profile_buddypress_image==""){$profile_buddypress_image='pluginimage';}
	if($profile_buddypress_image=='pluginimage'){
		// Image from plugin***
		$iv_profile_pic_url=get_user_meta($user->ID, 'iv_profile_pic_url',true);
		if($iv_profile_pic_url==''){
			$iv_profile_pic_url=finaluser_URLPATH.'assets/images/Blank-Profile.jpg';
		}
		$banner_image=get_user_meta($user->ID, 'iv_background_pic_url',true);
		if($banner_image==""){
			$banner_image=finaluser_URLPATH.'assets/images/version-4bg.jpg';
		}
		}else{
		if(function_exists('bp_is_active')){
			$iv_profile_pic_url = bp_core_fetch_avatar(array('html' =>  false, 'item_id' =>  $user->ID, 'type'=>'full'));
			$banner_image = bp_attachments_get_attachment( 'url', array( 'item_id' =>$user->ID) );
			if($banner_image==""){
				$banner_image=finaluser_URLPATH.'assets/images/version-4bg.jpg';
			}
		}
	}
	$color_setting=get_option('_dir_color');
	if($color_setting==""){$color_setting='#0099e5';}
	$color_setting=str_replace('#','',$color_setting);
?>
<div class="bootstrap-wrapper">
	<div class="p-profile-public-wrapper ">
		<div class="p-cover-photo" style="background: url('<?php echo esc_url($banner_image);?>') center center no-repeat;background-size: cover;">
		</div>
		<div class="p-user-avatar">
			<div class="p-avatar">
				<?php
					if($iv_profile_pic_url!=''){ ?>
					<div class="user-img" style="background: url('<?php echo esc_url($iv_profile_pic_url);?>') center center no-repeat;background-size: cover;">
						<?php
						}else{?>
						<div class="user-img" style="background: url('<?php echo finaluser_URLPATH; ?>assets/images/Blank-Profile.jpg') center center no-repeat;background-size: cover;">
							<?php
							}
						?>
					</div>
				</div>
			</div>
		</div>
		<div class="p-right-buttons">
			<div class="p-button-wrapper">
				<?php
					$profile_report=get_option('_profile_report');
					if($profile_report==""){$profile_report='show';}
					if($profile_report=="show"){
					?>
					<div class="p-report-button">
						<button class="p-button tertiary more"><i class="fa fa-ellipsis-h"></i></button>
						<div class="specialties-popover">
							<div class="qtip-tip">
								<canvas class="wdht" width="40" height="20">
								</canvas>
							</div>
							<div class="directory_specialty_selector__specialty--all">
								<a href="#"  onclick="call_popup_report()"  ><?php  esc_html_e('Report user', 'finaluser'); ?></a>
							</div>
						</div>
					</div>
					<?php
					}
				?>
				<div class="p-share-button">
					<button class="p-button tertiary more"><i class="fa fa-share"></i></button>
					<div class="specialties-popover">
						<div class="qtip-tip">
							<canvas class="wdht" width="40" height="20">
							</canvas>
						</div>
						<div class="directory_specialty_selector__specialty--all">
							<ul class="list-unstyled">
								<li><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink();?>?&id=<?php echo esc_html($user_id);?>" class="btn-facebook"><i class="fa fa-facebook"></i><?php echo esc_html_e('Facebook', 'finaluser'); ?></a></li>
								<li><a target="_blank" href="https://twitter.com/home?status=<?php the_permalink();  ?>?&id=<?php echo esc_html($user_id);?>" class="btn-twitter"><i class="fa fa-twitter"></i><?php echo esc_html_e('Twitter', 'finaluser'); ?></a></li>
								<li><a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink();  ?>?&id=<?php echo esc_html($user_id);?>" class="btn-google"><i class="fa fa-google-plus"></i><?php echo esc_html_e('Google', 'finaluser'); ?></a></li>
								<li><a target="_blank" href="http://pinterest.com/pin/create/button/?url=<?php the_permalink();?>&id=<?php echo esc_html($user_id);?>&media=<?php echo esc_url($banner_image);?>" class="btn-pinterest"><i class="fa fa-pinterest"></i><?php echo esc_html_e('Pinterest', 'finaluser'); ?></a></li>
							</ul>
						</div>
					</div>
				</div>
				<?php
					$profile_contact=get_option('_profile_contact');
					if($profile_contact==""){$profile_contact='show';}
					if($profile_contact=="show"){
					?>
					<div class="p-contact-button">
						<button class="p-button tertiary contact"  onclick="call_popup_profile()" ><i class="fa fa-envelope"></i><?php echo esc_html_e('Contact', 'finaluser'); ?></button>
					</div>
					<?php
					}
				?>
				<div class="p-contact-button" id="epfollow">
					<?php
						$profile_follow=get_option('_profile_follow');
						if($profile_follow==""){$profile_follow='show';}
						if($profile_follow=="show"){
							$current_user_ID = $current_user->ID;
							if($current_user_ID>0){
								$my_connect = get_user_meta($current_user_ID,'_following',true);
								$all_users = explode(",", $my_connect);
								if (in_array($user_id, $all_users)) { ?>
								<button class="p-button contact" onclick="save_unfollow('<?php echo esc_html($user_id); ?>')"><?php  esc_html_e('Following', 'finaluser'); ?></button>
								<?php
								}else{ ?>
								<button class="p-button contact" onclick="save_follow('<?php echo esc_html($user_id); ?>')"><?php  esc_html_e('Follow', 'finaluser'); ?></button>
								<?php
								}
							}else{ ?>
							<button class="p-button contact" onclick="save_follow('<?php echo esc_html($user_id); ?>')"><?php echo esc_html_e('Follow', 'finaluser'); ?></button>
							<?php
							}
						}
					?>
				</div>
			</div>
		</div>
		<div class="p-user-details">
			<h1>
				<?php
					$name_display=get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
				echo (trim($name_display)!=""? $name_display : $user->display_name );?>
			</h1>
			<div class="short_bio">
				<p> <?php
					$profile_title=get_user_meta($user_id,'profile_title',true);
					if(trim($profile_title)!=''){
						echo esc_html($profile_title);
						}else{
						echo wp_trim_words( get_user_meta($user_id,'description',true), 5, '' );
					}
				?></p>
			</div>
			<ul class="short-details">
				<?php
					$profile_follow=get_option('_profile_follow');
					if($profile_follow==""){$profile_follow='show';}
					if($profile_follow=="show"){
					?>
					<li class="followers">
						<?php
							$socialnetwork_value='';
							$socialnetwork_value = get_user_meta($user_id,'_follower',true);
							$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
							$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
						?>
						<span><?php echo sizeof($socialnetwork_value_arr);?></span> <a href="#"  data-toggle="modal" data-target="#myModalFollow"><?php echo esc_html_e('Followers', 'finaluser'); ?></a>
					</li>
					<li class="following">
						<?php
							$socialnetwork_value='';
							$socialnetwork_value = get_user_meta($user_id,'_following',true);
							$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
							$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
						?>
						<span><?php echo sizeof($socialnetwork_value_arr);?></span> <a href="#"  data-toggle="modal" data-target="#myModalFollowing"><?php echo esc_html_e('Followings', 'finaluser'); ?></a>
					</li>
					<?php
					}
				?>
				<li class="location"><i class="fa fa-map-marker"></i> <?php echo get_user_meta($user_id,'city',true);?></li>
				<li class="available_for_hire">
					<?php
						if(get_user_meta($user_id,'available',true)==''){?>
						<i class="fa fa-usd"></i>	<?php  esc_html_e('Available for Hire', 'finaluser'); ?>
						<?php
						}
					?>
				</li>
			</ul>
			<div class="p-social-links">
				<?php
					$contact_web=get_user_meta($user_id,'web_site',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-globe"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'facebookp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url($contact_web); ?>" class="contact_link"><i class="fa fa-facebook-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'linkedinp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-linkedin-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'twitterp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-twitter-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'gplusp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-google-plus-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'pinterestp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-pinterest-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'instagramp',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-instagram"></i></a>
					<?php
					}
					$contact_web=get_post_meta($user_id,'vimeop',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-vimeo-square"></i></a>
					<?php
					}
					$contact_web=get_user_meta($user_id,'youtubep',true);
					$contact_web=str_replace('https://','',$contact_web);
					$contact_web=str_replace('http://','',$contact_web);
					if($contact_web!=''){?>
					<a href="<?php echo esc_url( $contact_web); ?>" class="contact_link"><i class="fa fa-youtube-square"></i></a>
					<?php
					}
				?>
			</div>
		</div>
		<?php
			$profile_tab_active=get_option('_pprofile_tab_active');
			if($profile_tab_active==""){$profile_tab_active='service';}
		?>
		<div class="p-nav-tabs-section bootstrap-wrapper">
			<?php
				$gallery_ids=get_user_meta($user_id ,'image_gallery_ids',true);
				$gallery_ids_array = array_filter(explode(",", $gallery_ids));
			?>
			<?php include('profile-tab.php');?>
			<div class="tab-content clearfix">
				<?php
					$profile_photo=get_option('_ep_finaluser_public_pfacebook');
					if($profile_photo==""){$profile_photo='show';}
					if($profile_photo=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='pfacebook'?"active":"");?>" id="facebook">
						<?php include('facebook-feed.php');?>
					</div>
					<?php
					}
					$profile_photo=get_option('_ep_finaluser_public_pvideos');
					if($profile_photo==""){$profile_photo='show';}			;
					if($profile_photo=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='pvideos'?"active":"");?>" id="videos">
						<?php include('videos.php');?>
					</div>
					<?php
					}
					$profile_service=get_option('_ep_finaluser_public_previews');
					if($profile_service==""){$profile_service='show';}
					if($profile_service=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='previews'?"active":"");?>" id="reviews">
						<?php include('reviews.php');?>
					</div>
					<?php
					}
				?>
				<?php
					$profile_photo=get_option('_ep_finaluser_public_pfacebook');
					if($profile_photo==""){$profile_photo='show';}
					if($profile_photo=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='facebook'?"active":"");?>" id="facebook">
						<?php include('facebook-feed.php');?>
					</div>
					<!-- end tab pane photos -->
					<?php
					}
					$profile_service=get_option('_ep_finaluser_public_ppost');
					if($profile_service==""){$profile_service='show';}
					if($profile_service=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='ppost'?"active":"");?>" id="posts">
						<?php include('posts.php');?>
					</div>
					<?php
					}
					$profile_service=get_option('_ep_finaluser_public_pdocs');
					if($profile_service==""){$profile_service='show';}
					if($profile_service=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='pdocs'?"active":"");?>" id="docs">
						<?php include('docs.php');?>
					</div>
					<?php
					}
					$profile_service=get_option('_ep_finaluser_public_psocial');
					if($profile_service==""){$profile_service='show';}
					if($profile_service=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='social'?"active":"");?>" id="social">
						<?php include('social.php');?>
					</div>
					<?php
					}
					$profile_photo=get_option('_ep_finaluser_public_photos');
					if($profile_photo==""){$profile_photo='show';}
					if($profile_photo=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='pphotos'?"active":"");?>" id="photos">
						<?php include('photos.php');?>
					</div>
					<?php
					}
					$custom_tab = array();
					if(get_option('ep_finaluser_profile_pptab')){
						$custom_tab=get_option('ep_finaluser_profile_pptab' );
					}
					$ii=1;
					if($custom_tab!=''){
						foreach ( $custom_tab as $field_key => $field_value ) { ?>
						<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active==$field_key?"active":"");?>" id="<?php echo esc_html($field_key);?>">
							<div class="p-photo-block container">
								<?php
									$post = get_post($field_value);
									$content = apply_filters('the_content', $post->post_content);
									echo esc_html($content);
								?>
							</div>
						</div>
						<?php
						}
					}
					$profile_service=get_option('_ep_finaluser_public_pprofile');
					if($profile_service==""){$profile_service='show';}
					if($profile_service=='show'){
					?>
					<div role="tabpanel" class="tab-pane <?php echo($profile_tab_active=='pprofile'?"active":"");?>" id="profile">
						<?php include('profile.php');?>
					</div>
					<?php
					}
				?>
			</div>
		</div> 
		<?php
			$profile_map=get_option('_profile_map');
			if($profile_map==""){$profile_map='show';}
			if($profile_map=="show"){
				$address=get_user_meta($user_id,'address',true).','.get_user_meta($user_id,'city',true).','.get_user_meta($user_id,'country',true);
			?>
			<iframe  class="scroll-no" width="100%" height="400" frameborder="0" scrolling="off" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=<?php echo esc_attr($address); ?>&amp;ie=UTF8&amp;&amp;output=embed"></iframe>
			<?php
			}
		?>
		<div class="bootstrap-wrapper user-profile-modal">
			<div class="modal fade" id="myModalFollow" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog follow-following-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel"><?php  esc_html_e('Followers', 'finaluser'); ?></h4>
						</div>
						<div class="modal-body">
							<ul class="actors">
								<?php
									$socialnetwork_value='';
									$socialnetwork_value = get_user_meta($user_id,'_follower',true);
									$socialnetwork_value = array_filter(explode(",", $socialnetwork_value));
									$args = array();
									$no=10;
									$paged = 1;
									$offset=0;
									$args['number']=$no;
									$args['offset']=$offset;
									$args['include']=$socialnetwork_value;
									if(sizeof($socialnetwork_value)>0){
										$user_query = new WP_User_Query( $args );
										if ( ! empty( $user_query->results ) ) {
											foreach ( $user_query->results as $user ) {
												$iv_profile_pic_url='';
												$iv_profile_pic_url= $this->get_iv_user_image($user->ID);
												if($listing_author_link=='author'){
													$reg_page_u= get_author_posts_url($user->ID);
													}else{
													$reg_page_u=$reg_page_user.'?&id='.$user->ID;
												}
											?>
											<li class="actor">
												<div class="left">
													<a href="<?php echo esc_url($reg_page_u);?>" class="avatar" style="background: url('<?php echo esc_url($iv_profile_pic_url);?>') center center no-repeat; background-size: cover;"></a>
													<div class="actor-info">
														<a href="<?php echo esc_url($reg_page_u);?>" class="name">
															<?php
																$name_display=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
																echo (trim($name_display)!=""? $name_display : $user->display_name );
															?></a>
															<span class="description">
																<?php
																	$socialnetwork_value='';
																	$socialnetwork_value = get_user_meta($user->ID,'_follower',true);
																	$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
																	$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
																	echo sizeof($socialnetwork_value_arr).' ';
																?> <?php  esc_html_e('Followers', 'finaluser'); ?>
															</span>
													</div>
												</div>
												<div class="right">
													<div class="follow-button" id="follow_popup<?php echo esc_html($user->ID);?>">
														<?php
															$current_user_ID = $current_user->ID;
															if($current_user_ID>0){
																$my_connect = get_user_meta($current_user->ID,'_following',true);
																$all_users = explode(",", $my_connect);
																if (in_array($user->ID, $all_users)) { ?>
																<a href="#" onclick="save_unfollow_popup('<?php echo esc_html($user->ID); ?>','follow_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Following', 'finaluser'); ?></a>
																<?php
																}else{ ?>
																<a href="#" onclick="save_follow_popup('<?php echo esc_html($user->ID); ?>','follow_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Follow', 'finaluser'); ?></a>
																<?php
																}
															}else{ ?>
															<a href="#" onclick="save_follow_popup('<?php echo esc_html($user->ID); ?>','follow_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Follow', 'finaluser'); ?></a>
															<?php
															}
														?>
													</div>
												</div>
											</li>
											<?php
											}
										}
									}
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- end folow modal markup -->
			<div class="modal fade" id="myModalFollowing" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog follow-following-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel"><?php  esc_html_e('Followings', 'finaluser'); ?></h4>
						</div>
						<div class="modal-body">
							<ul class="actors">
								<?php
									$socialnetwork_value='';
									$socialnetwork_value = get_user_meta($user_id,'_following',true);
									$socialnetwork_value = array_filter(explode(",", $socialnetwork_value));
									$args = array();
									$no=10;
									$paged = 1;
									$offset=0;
									$args['number']=$no;
									$args['offset']=$offset;
									$args['include']=$socialnetwork_value;
									if(sizeof($socialnetwork_value)>0){
										$user_query = new WP_User_Query( $args );
										if ( ! empty( $user_query->results ) ) {
											foreach ( $user_query->results as $user ) {
												$iv_profile_pic_url='';
												$iv_profile_pic_url= $this->get_iv_user_image($user->ID);
												if($listing_author_link=='author'){
													$reg_page_u= get_author_posts_url($user->ID);
													}else{
													$reg_page_u=$reg_page_user.'?&id='.$user->ID;
												}
											?>
											<li class="actor">
												<div class="left">
													<a href="<?php echo esc_url($reg_page_u);?>" class="avatar" style="background: url('<?php echo esc_url($iv_profile_pic_url);?>') center center no-repeat; background-size: cover;"></a>
													<div class="actor-info">
														<a href="<?php echo esc_url($reg_page_u);?>" class="name"><?php
															$name_display=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
															echo (trim($name_display)!=""? $name_display : $user->display_name );
														?></a>
														<span class="description">
															<?php
																$socialnetwork_value='';
																$socialnetwork_value = get_user_meta($user->ID,'_follower',true);
																$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
																$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
																echo sizeof($socialnetwork_value_arr).' ';
															?> <?php  esc_html_e('Followers', 'finaluser'); ?>
														</span>
													</div>
												</div>
												<div class="right">
													<div class="follow-button" id="following_popup<?php echo esc_html($user->ID);?>">
														<?php
															$current_user_ID = $current_user->ID;
															if($current_user_ID>0){
																$my_connect = get_user_meta($current_user->ID,'_following',true);
																$all_users = array_diff(explode(",", $my_connect),array(" "));
																if (in_array($user->ID, $all_users)) { ?>
																<a onclick="save_unfollow_popup('<?php echo esc_html($user->ID); ?>','following_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Following', 'finaluser'); ?></a>
																<?php
																}else{ ?>
																<a  onclick="save_follow_popup('<?php echo esc_html($user->ID); ?>','following_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Follow', 'finaluser'); ?></a>
																<?php
																}
															}else{ ?>
															<a  onclick="save_follow_popup('<?php echo esc_html($user->ID); ?>','following_popup<?php echo esc_html($user->ID);?>')" class="button follow mini_follow"><?php  esc_html_e('Follow', 'finaluser'); ?></a>
															<?php
															}
														?>
													</div>
												</div>
											</li>
											<?php
											}
										}
									}
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="modal fade" id="myModalContact" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog follow-following-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></h4>
						</div>
						<div class="modal-body">
							<div class="modal-contact-form">
								<form action="#" id="contact_form_2" name="contact_form_2"  method="POST" >
									<div class="form-group">
										<label  for="Name"><?php esc_html_e( 'Name', 'finaluser' ); ?></label>
										<input id="subject" name ="subject" type="text">
									</div>
									<div class="form-group">
										<label  for="eamil"><?php esc_html_e( 'Email', 'finaluser' ); ?></label>
										<input name="email_address" id="email_address" type="email">
									</div>
									<div class="form-group">
										<label for="message"><?php esc_html_e( 'Message', 'finaluser' ); ?></label>
										<input type="hidden" name="dir_id" id="dir_id" value="<?php echo esc_html($user_id); ?>">
										<textarea name="message-content" id="message-content"  cols="20" rows="5"></textarea>
									</div>
								</form>
							</div>
						</div>
						<div class="modal-footer">
							<a onclick="contact_send_message_iv();" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></a>
							<div id="update_message_popup"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal fade" id="myModalreport" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog follow-following-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel"><?php esc_html_e( 'Report', 'finaluser' ); ?></h4>
						</div>
						<div class="modal-body">
							<div class="modal-contact-form">
								<form action="#" id="message-claim" name="message-claim"  method="POST" >
									<div class="form-group">
										<label  for="Name"><?php esc_html_e( 'Name', 'finaluser' ); ?></label>
										<input id="subject" name ="subject" type="text">
									</div>
									<div class="form-group">
										<label  for="eamil"><?php esc_html_e( 'Email', 'finaluser' ); ?></label>
										<input name="email_address" id="email_address" type="email">
									</div>
									<div class="form-group">
										<label for="message"><?php esc_html_e( 'Message', 'finaluser' ); ?></label>
										<input type="hidden" name="dir_id" id="dir_id" value="<?php echo esc_html($user_id); ?>">
										<textarea name="message-content" id="message-content"  cols="20" rows="5"></textarea>
									</div>
								</form>
							</div>
						</div>
						<div class="modal-footer">
							<a onclick="send_message_claim();" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></a>
							<div id="update_message_claim"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
<?php
	wp_enqueue_script('finaluser-public-profile', finaluser_URLPATH.'admin/files/js/public-profile.js', array('jquery'), $ver = true, true );
	wp_enqueue_script('finaluser-single-profile-js', finaluser_URLPATH.'admin/files/js/single-profile.js', array('jquery'), $ver = true, true );
	wp_localize_script('finaluser-single-profile-js', 'tiger_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'current_user_id'	=>get_current_user_id(),
	'postuser'	=>  $user_id,
	'login_message'		=> esc_html__( 'Please login to remove favorite','finaluser'),
	'Add_to_Follow'		=> esc_html__( 'Add to Follow','finaluser'),
	'Login_claim'		=>esc_html__( 'Please login to Report/Claim The Profile','finaluser'),
	'login_follw'	=>esc_html__( "Please login to add follow",'finaluser'),
	'login_review'	=>esc_html__( "Please login to add review",'finaluser'),
	'following'=> esc_html__( "Following",'finaluser'),
	'follow'=> esc_html__( "Follow",'finaluser'),
	'finalwpnonce'=>  wp_create_nonce("settings"),
	) );
?>