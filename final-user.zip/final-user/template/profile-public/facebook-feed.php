<div class="p-service-content">
	<div class="row">
		<div class="review-block">
			<?php
				$page_id = get_user_meta($user_id,'final_facebookpage_id',true); // can get form Facebook page settings
				if(trim(get_user_meta($user_id,'final_facebookapp_id',true))!=""){
					$app_id = get_user_meta($user_id,'final_facebookapp_id',true);
					}else{
					$app_id = '2171713993093988';
				}
				if(trim(get_user_meta($user_id,'final_facebookappsecret',true))!=""){
					$app_secret = get_user_meta($user_id,'final_facebookappsecret',true);
					}else{
					$app_secret = 'e1e8e396b6410f7bfe33c4e424b91a88';
				}
				if(get_user_meta($user_id,'final_facebookpost_limit',true)!=""){
					$cff_post_limit = get_user_meta($user_id,'final_facebookpost_limit',true);
					}else{
					$cff_post_limit = '10';
				}
				if(get_user_meta($user_id,'final_facebookpostlength',true)!=""){
					$final_facebookpostlength = (int)get_user_meta($user_id,'final_facebookpostlength',true);
					}else{
					$final_facebookpostlength = (int)'200';
				}
				$access_token='';
				$access_token_array = array(
        '1786066011417150|5043eac44ee54731ed404b9db021cdf2',
        '1795317140689602|e25d547c4f12164254f85eead086b0a7',
        '1851314935096786|0de2a9ec77d745d6941850696ce166f9',
        '322095208287051|pbCTS6jPuhjR18sl2UPhKQw7eyY',
        '1042396375891598|gn2HiZgDgjTbCMcXsSb6VK91PqM',
        '348613608818294|d4gRX7tNppCrI-DrOGof_O8gwvg',
        '1591407604237466|cHUFs9XDDJa7LDUW9zBxirwGAHE',
        '697312047120344|p8ST5dkrub6IoBZsClmyRBTScB0',
        '1134584793234186|763Jh88I-PuO8_slARazfgucxFg',
        '1788677371359317|UU7yeB5dsKOT8xLsLA9xSNu4OMQ',
        '1024245627652108|VmyBFUaBhjmvF31kPWdLcwtA0nU',
        '1665626540320930|kDmIPfF8Y0mvV5mPr3927c2nRlM',
        '219254908466738|9AAaE_5GnONhVWUTlEBS8LDiFi8',
        '383334425112756|cxkb0YngoQPVkr7AngA_LOE2TV8',
        '1711513059125773|IuTAeRQAzhUelndJ_n7jPx3yOxs',
        '1425047524403499|shKbcYtt0KmDzOG5n9hkuVmP1bA',
        '1677248395890039|CSZsE5C-HJ8cYOraU6J6gwACZys',
        '162288250832230|HvQ8grGeT3QGVEFgRkooK-V55vs',
        '258557634485082|vBEtyzuLUrCVDeks57FPNbH5YCo',
        '1028332560591295|InX-Kx2LF2tjcfjbz4ddP6wXJ6U',
        '1816228771930249|xW0dj0nD-gWTl9oUEFyz7kCn4Gk',
        '451848331655448|YnHljWJNCMRxlo5JwAQRukxqQj0',
        '1590285041189842|PNrjtuwPpJWAda9GjvDnYCZvQH0',
        '1425919427736604|6NKiBWf5_rR4DuV2z1E_Pk27F2I',
        '198080700214649|natEgdD5R82UoiLXL5UsUK82-O8',
        '452046251639377|sruLhZT7bktRpuPy0txclkvCMWE',
        '282581258595802|QRueniLvr6ppOBW9UcNpJVswGKw',
        '120755681588984|8IamCzI5D56psRs_726PwSgUgos',
        '236542103198412|YZBFLCWsx_ap_c2rmznf_tEbh6E',
        '820682411352870|0W2O9df8U0suAfllTVdPP2Zl8lI',
        '444110102425340|1xyyWHpqzWy5jNrMnNAsMgIIKVI',
        '334097170130531|fpcajp_H4f79HoAP2j5Ryo_0OKE',
        '350665888465252|pi9du5kAZ9JRDAfxzNpq-S7w7Zw',
        '294686830545691|3DhoPPXbNBmzlmXXK9cbLnGJTMI'
				);
				if ($access_token == '' || !$cff_show_access_token) $access_token = $access_token_array[rand(0, 33)];
				
				$cff_ssl = '';
				$graph_query = 'posts';
				$cff_locale = 'en_US';
				$url = 'graph.facebook.com/' . $page_id . '/' . $graph_query . '?fields=icon,id,message,full_picture,story,link,source,name,caption,description,type,status_type,object_id,created_time&access_token=' . $access_token . '&limit=' . $cff_post_limit . '&locale=' . $cff_locale . $cff_ssl;
				$last_save_record_time=get_user_meta($user_id,'final_fb_data_save_time',true);
				$current_time=time();
				$time_val= (int)$current_time- (int)$last_save_record_time;
				if($last_save_record_time==""){$time_val='29000';}
				if($time_val>1){
					if(is_callable('curl_init')){
            $ch = curl_init();
            // Use global proxy settings
            if (defined('WP_PROXY_HOST')) {
              curl_setopt($ch, CURLOPT_PROXY, WP_PROXY_HOST);
						}
            if (defined('WP_PROXY_PORT')) {
              curl_setopt($ch, CURLOPT_PROXYPORT, WP_PROXY_PORT);
						}
            if (defined('WP_PROXY_USERNAME')){
              $auth = WP_PROXY_USERNAME;
              if (defined('WP_PROXY_PASSWORD')){
                $auth .= ':' . WP_PROXY_PASSWORD;
							}
              curl_setopt($ch, CURLOPT_PROXYUSERPWD, $auth);
						}
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_ENCODING, '');
            $feedData = curl_exec($ch);
            curl_close($ch);
						} elseif ( (ini_get('allow_url_fopen') == 1 || ini_get('allow_url_fopen') === TRUE ) && in_array('https', stream_get_wrappers()) ) {
            $feedData = @file_get_contents($url);
						} else {
            $request = new WP_Http;
            $response = $request->request($url, array('timeout' => 60, 'sslverify' => false));
            if( is_wp_error( $response ) ) {
							$FBdata = null;
							} else {
							$feedData = wp_remote_retrieve_body($response);
						}
					}
					if($feedData!=null){
						if(isset($feedData->error->message)){
							$FBdata= get_user_meta($user_id,'final_fb_data_save',true);
							}else{
							$FBdata = json_decode($feedData);
							update_user_meta($user_id,'final_fb_data_save',$FBdata);
							update_user_meta($user_id,'final_fb_data_save_time',time());
						}
						}else{
						$FBdata= get_user_meta($user_id,'final_fb_data_save',true);
					}
					}else{
					$FBdata= get_user_meta($user_id,'final_fb_data_save',true);
				}
				$cff_show_only_others='';
				$i_post=0;
				if( !empty($FBdata->data) ) {
					foreach ($FBdata->data as $news )
					{
						$PostID = '';
            $cff_post_id = '';
            if( isset($news->id) ){
							$cff_post_id = $news->id;
							$PostID = explode("_", $cff_post_id);
						}
            isset($news->link) ? $link = htmlspecialchars($news->link) : $link = '';
						$cff_album = true;
            $num_photos = 0;
					?>
					<div class="row">
						<div class="col-sm-4">
							<div class="row review-block-name">
								<a href="<?php echo esc_url($link); ?>">
									<?php
										if(isset($news->story) && !empty($news->story)){
											echo esc_html($news->story);
											}elseif(isset($news->name) && !empty($news->name)){
											echo esc_html($news->name);
										}
									?>
								</a>
							</div>
							<div class="row review-block-description">
								<?php if(isset($news->created_time)){echo date('M d, Y',strtotime($news->created_time));}  ?>
							</div>
						</div>
						<div class="col-sm-8">
							<div class="row">
								<div>
								</div>
							</div>
							<div class="row">
								<?php
									if(isset($news->full_picture)){ ?>
									<a data-fancybox="gallery" href="<?php echo esc_url($news->full_picture); ?>">
										<img class="img-responsive" src="<?php if(isset($news->full_picture)){echo esc_url($news->full_picture);} ?>">
									</a>
									<?php
									}
								?>
							</div>
							<div class="row review-block-description ">
								<?php if(isset($news->message)){
									echo nl2br( substr($news->message,0,$final_facebookpostlength)).' <a href="'.$link.'"><strong>'.esc_html__(  ' More...', 'finaluser' ).'</strong></a>';
								}
								?>
							</div>
						</div>
					</div>
					<hr>
					<?php
					}
				}
			?>
		</div>
	</div>
</div>