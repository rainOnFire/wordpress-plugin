<?php
	$bp = buddypress();
	global $bp, $wpdb;
	global $messages_template;
	$main_class = new finaluser;
?>
<div class="profile-content bootstrap-wrapper"  >
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Message', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 " id="all_message">
					<div class="row">
						<div class="col-md-12">
							<div id="sent_message"> </div>
							<div id="save_message"> </div>
							<form name="messagereplyform" id="messagereplyform">
								<div id="to_user_ids"></div>
								<div class="form-group">
									<input type="text" id="mail_to" name="mail_to" placeholder="<?php esc_html_e('To:','finaluser'); ?>">
									<?php $pos = $main_class->get_unique_user_values(); ?>
									<script>
										jQuery(function() {
											var availableTags = <?php echo $pos; ?>;
											jQuery( "#mail_to" ).autocomplete({
												source: availableTags,
												select: function(event, ui) {
													event.preventDefault();
													jQuery(this).val(ui.item.label);
													jQuery("#to_user_ids").append('<div class="col-md-3 alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+ui.item.label+'<input type="hidden" id="userids[]" name="userids[]" value="'+ui.item.value+'"></div>');
													jQuery( "#mail_to" ).val('');
												}
											});
										});
									</script>
								</div>
								<div class="form-group">
									<input type="text" id="mail_subject" name="mail_subject" placeholder="<?php esc_html_e('Subject','finaluser'); ?>">
								</div>
								<div class="form-group">
									<textarea rows="5" name="replycontent" id="replycontent" lass="form-control-solid" placeholder="<?php esc_html_e('Message','finaluser'); ?>"></textarea>
								</div>
							</form>
							<button type="button" onclick="ep_send_compose();"  class="btn btn-primary"><?php esc_html_e('Send','finaluser'); ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>