<?php
wp_enqueue_script('ep_finaluser-script-upgrade-15', finaluser_URLPATH . 'admin/files/js/jquery.form-validator.js');

$newpost_id='';
$currencyCode= get_option('_iv_membership_api_currency');
$iv_gateway = get_option('iv_membership_payment_gateway');
$post_name='ep_finaluser_stripe_setting';
$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name ));
			if(isset($row->ID)){
			  $newpost_id= $row->ID;
			}
$stripe_mode=get_post_meta( $newpost_id,'ep_finaluser_stripe_mode',true);
if($stripe_mode=='test'){
	$stripe_publishable =get_post_meta($newpost_id, 'ep_finaluser_stripe_publishable_test',true);
}else{
	$stripe_publishable =get_post_meta($newpost_id, 'ep_finaluser_stripe_live_publishable_key',true);
}
wp_enqueue_script('stripe', 'https://js.stripe.com/v2/');		
?>

			<div id="payment-errors"></div>
	<div id="stripe_form">
			<div class="row form-group">
			<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"><?php esc_html_e( 'Package Name', 'finaluser' );?></label>
				<div class="col-md-8 col-xs-8 col-sm-8 ">
					<?php
						$sql="SELECT * FROM $wpdb->posts WHERE post_type = 'ep_finaluser_pack'  and post_status='draft' ";
						$membership_pack = $wpdb->get_results($sql);
						$total_package=count($membership_pack);
						
						if(sizeof($membership_pack)>0){
							$i=0; $current_package_id=get_user_meta($current_user->ID,'ep_finaluser_package_id',true);
							echo'<select name="package_sel" id ="package_sel" class=" form-control-solid">';
							foreach ( $membership_pack as $row )
							{
								if($current_package_id==$row->ID){
									echo '<option value="'. $row->ID.'" >'. $row->post_title.' [Your Current Package]</option>';
								}else{
									echo '<option value="'. $row->ID.'" >'. $row->post_title.'</option>';
								}
									if($i==0){
										$package_id=$row->ID;
										if(get_post_meta($row->ID, 'ep_finaluser_package_recurring',true)=='on'){
											$package_amount=get_post_meta($row->ID, 'ep_finaluser_package_recurring_cost_initial', true);
										}else{
											$package_amount=get_post_meta($row->ID, 'ep_finaluser_package_cost',true);

										}
									}
							 $i++;
							}

							echo '</select>';
						}
					 ?>
					</div>

				</div>

			<div class="row form-group">
								<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"><?php esc_html_e('Amount','finaluser'); ?></label>

								<div class="col-md-8 col-xs-8 col-sm-8 " id="p_amount"> <label class="control-label"> <?php  echo esc_html($amount).' '.esc_html($recurring_text); ?> </label>
								</div>
			</div>
			<div class="row form-group">
								<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"><?php esc_html_e('Card Number','finaluser'); ?></label>
								<div class="col-md-8 col-xs-8 col-sm-8 " >
									<input type="text" name="card_number" id="card_number"  data-validation="creditcard required"  class="form-control-solid ctrl-textbox" placeholder="<?php esc_html_e('Enter card number','finaluser'); ?>" data-validation-error-msg="<?php esc_html_e( 'Card number is not correct', 'finaluser' );?>" >
			</div>
			</div>
		<div class="row form-group">
								<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"><?php esc_html_e('Card CVV','finaluser'); ?></label>
								<div class="col-md-8 col-xs-8 col-sm-8 " >
									<input type="text" name="card_cvc" id="card_cvc" class="form-control-solid ctrl-textbox"   data-validation="number"
data-validation-length="2-6" data-validation-error-msg="<?php esc_html_e( 'CVV number is not correct', 'finaluser' );?>" placeholder="<?php esc_html_e('Enter card CVC','finaluser'); ?>" >
			</div>
		</div>
					<div class="row form-group">
							<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"><?php esc_html_e('Expiration (MM/YYYY)','finaluser'); ?></label>
							<div class="col-md-4 col-xs-4 col-sm4" >

								<select name="card_month" id="card_month"  class="card-expiry-month stripe-sensitive required form-control-solid">
									<option value="01" selected="selected">
										<?php esc_html_e('01','finaluser'); ?>
									</option>
									<option value="02">
										<?php esc_html_e('02','finaluser'); ?>
									</option>
									<option value="03">
										<?php esc_html_e('03','finaluser'); ?>
									</option>
									<option value="04">
										<?php esc_html_e('04','finaluser'); ?>
									</option>
									<option value="05">
										<?php esc_html_e('05','finaluser'); ?>
									</option>
									<option value="06">
										<?php esc_html_e('06','finaluser'); ?>
									</option>
									<option value="07">
										<?php esc_html_e('07','finaluser'); ?>
									</option>
									<option value="08">
										<?php esc_html_e('08','finaluser'); ?>
									</option>
									<option value="09">
										<?php esc_html_e('09','finaluser'); ?>
									</option>
									<option value="10">
										<?php esc_html_e('10','finaluser'); ?>
									</option>
									<option value="11">
										<?php esc_html_e('11','finaluser'); ?>
									</option>
									<option value="12" selected >
										<?php esc_html_e('12','finaluser'); ?>
									</option>
								  </select>
							</div>
						<div class="col-md-4 col-xs-4 col-sm-4 " >
								 <select name="card_year"  id="card_year"  class="card-expiry-year stripe-sensitive  form-control-solid">
								  </select>
								  
						</div>
					</div>
				<?php
					$ep_finaluser_payment_terms=get_option('ep_finaluser_payment_terms');
									$term_text='I have read & accept the Terms & Conditions';
									if( get_option( 'ep_finaluser_payment_terms_text' ) ) {
										$term_text= get_option('ep_finaluser_payment_terms_text');
									}
									if($ep_finaluser_payment_terms=='yes'){
									?>

								<div class="row">
									<div class="col-md-4 col-xs-4 col-sm-4 ">
									</div>
											<div class="col-md-8 col-xs-8 col-sm-8 ">
											<label>
											  <input type="checkbox" data-validation="required"
			 data-validation-error-msg="<?php esc_html_e( 'You have to agree to our terms', 'finaluser' );?> "  name="check_terms" id="check_terms"> <?php echo esc_html($term_text); ?>
											</label>
										<div class="text-danger" id="error_message" > </div>
									  </div>
								</div>

								<?php
								}

								?>
						<input type="hidden" name="package_id" id="package_id" value="<?php echo esc_html($package_id); ?>">
						<input type="hidden" name="coupon_code" id="coupon_code" value="">
						<input type="hidden" name="redirect" value="<?php echo get_permalink(); ?>"/>
						<input type="hidden" name="stripe_nonce" value="<?php echo wp_create_nonce('stripe-nonce'); ?>"/>



				<div class="row form-group">
					<label for="text" class="col-md-4 col-xs-4 col-sm-4 control-label"></label>
					<div class="col-md-8 col-xs-8 col-sm-8 " > <div id="loading"> </div>
						<button  id="submit_ep_finaluser_payment"  type="submit" class="btn btn-sm tirtiary"  ><?php  esc_html_e('Submit','finaluser');?>   </button>
					</div>
				</div>
	</div>
<?php
	wp_enqueue_script('ep_finaluser-stripe', finaluser_URLPATH.'admin/files/js/stripe-upgrade.js');
	wp_localize_script('ep_finaluser-stripe', 'ep_data_stripe', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',	
	'profilenonce'=> wp_create_nonce("settings"),
	'signup'=> wp_create_nonce("signup"),	
	'currencyCode'=> $currencyCode,
	'iv_gateway'=> $iv_gateway,
	'stripe_publishable'=> $stripe_publishable,
	) );
	
?>	
