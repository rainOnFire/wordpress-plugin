<?php
	wp_enqueue_style('message_inline_css_here', finaluser_URLPATH . 'admin/files/css/message.css');
	$bp = buddypress();
	global $bp, $wpdb;
	$order='DESC';
	$sql=$wpdb->prepare("SELECT * FROM ".$wpdb->prefix."bp_messages_recipients where user_id='%s' and is_deleted='0' group by thread_id ORDER BY id ", $user_id);
	$all_message = $wpdb->get_results($sql);
?>
<div class="profile-content bootstrap-wrapper"  >
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Inbox', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 " id="all_message">
					<div class="mail-box">
						<aside class="lg-side">
							<div class="inbox-body">
								<div class="mail-option">
									<div class="chk-all">
										<input type="checkbox" onclick="return select_message_all('selectmail');" name="selectmail_all" id="selectmail_all"  class="mail-checkbox mail-group-checkbox selectmail">
										<div class="btn-group">
											<?php esc_html_e('All','finaluser'); ?>
										</div>
									</div>
									<div class="btn-group hidden-phone">
										<a  onclick="return make_as_read();"  class="btn mini blue" aria-expanded="false">
											<?php esc_html_e('Mark as Read','finaluser'); ?>
										</a>
									</div>
									<div class="btn-group hidden-phone">
										<a onclick="return make_as_unread();"  class="btn mini blue" aria-expanded="false">
											<?php esc_html_e('Mark as Unread','finaluser'); ?>
										</a>
									</div>
								</div>
								<table class="table table-inbox table-hover">
									<tbody>
										<form action="#" id="message_form" name="message_form">
											<?php
												$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
												$reg_page_user='';
												if($iv_redirect_user!='defult'){
													$reg_page_user= get_permalink( $iv_redirect_user) ;
												}
												$listing_author_link=get_option('listing_author_link');
												if($listing_author_link==""){$listing_author_link='author';}
												if(sizeof($all_message)>0){
													$i=0;
													foreach ( $all_message as $row )
													{
														$this->thread        = new BP_Messages_Thread( $row->thread_id, $order, $args = array());
														$this->message_count = count( $this->thread->messages );
														foreach($this->thread->messages as $thread){
															if($thread->sender_id!=$user_id){
																if($listing_author_link=='author'){
																	$reg_page_u= get_author_posts_url( $thread->sender_id );
																	}else{
																	$reg_page_u=$reg_page_user.'?&id='. $thread->sender_id ;
																}
															?>
															<tr <?php echo($row->unread_count=="1"? ' class="unread"':'') ?> id="tr<?php echo esc_html($row->thread_id);?>" >
																<td class="inbox-small-cells">
																	<input type="checkbox" name="selectmail[]" id="selectmail[]"  value="<?php echo esc_html($row->thread_id);?>" class="mail-checkbox selectmail">
																</td>
																<td class="inbox-small-cells"> </td>
																<td class="view-message dont-show">
																	<a href="<?php echo esc_url($reg_page_u);?>"> <?php
																		$user_mail = get_user_by( 'id', $thread->sender_id );
																		$name_display=get_user_meta($thread->sender_id,'first_name',true).' '.get_user_meta($thread->sender_id,'last_name',true);
																		echo (trim($name_display)!=""? $name_display : $user_mail->display_name ); echo($this->message_count>1 ? ' ('.$this->message_count.')': '');
																	?>
																	</a>
																</td>
																<td class="view-message">
																	<a href="<?php echo get_permalink().'?&profile=detail-message&thread_id='.esc_html($row->thread_id); ?>"><?php echo esc_html($thread->subject);?> </a>
																</td>
																<td class="view-message inbox-small-cells"></td>
																<td class="view-message text-right"><?php echo date("M-d-y| H-i a",strtotime($thread->date_sent));?></td>
															</tr>
															<?php
																break;
															}
														}
													}
												}
											?>
										</form>
									</tbody>
								</table>
							</div>
						</aside>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<?php	
	wp_enqueue_script('finaluser-private-message-js', finaluser_URLPATH.'admin/files/js/message.js', array('jquery'), $ver = true, true );
	wp_localize_script('finaluser-private-message-js', 'ep_data_message', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',	
	'current_user_id'	=>get_current_user_id(),	
	'finalwpnonce'		=>  wp_create_nonce("settings"),
	) );
	?>	