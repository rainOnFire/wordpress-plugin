<form role="form" name="profile_image_gallery" id="profile_image_gallery" action="#">
	<div class="profile-content">
		<div class="row">
			<div class="col-md-12">
				<h3><?php echo esc_html_e('My Docs', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class="margiv-top-10 ">
						<?php
							$package_id=get_user_meta($current_user->ID, 'ep_finaluser_package_id',true);
							$image_limit= get_post_meta($package_id, 'ep_finaluser_doc_limit', true);
							$user_role= $current_user->roles[0];
							if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
								$image_limit=999999;
							}
							$gallery_ids=get_user_meta($current_user->ID ,'profile_doc_ids',true);
							$gallery_ids_array = array_filter(explode(",", $gallery_ids));
						?>
						<input type="hidden" name="gallery_doc_ids" id="gallery_doc_ids" value="<?php echo esc_html($gallery_ids); ?>">
						<div class="" id="gallery_doc_div">
							<?php
								if(sizeof($gallery_ids_array)>0){
									foreach($gallery_ids_array as $slide){
										if(trim($slide)!=""){
										?>
										<div id="gallery_doc_div<?php echo esc_html($slide);?>" class="col-md-3">
											<div class="row">
												<a href="<?php echo wp_get_attachment_url( $slide );?>" target="_blank">
													<img src="<?php echo finaluser_URLPATH. "admin/files/images/pdf.png"; ?>">
												</a>
												<div  class="col-md-2">
													<button type="button" onclick="remove_gallery_doc('gallery_doc_div<?php echo esc_html($slide);?>', <?php echo esc_html($slide);?>);"  class="btn btn-xs btn-danger">X</button>
												</div>
												<div  class="col-md-10">
													<?php
														$filename_only = basename( get_attached_file( $slide ) );
														echo esc_html($filename_only);
													?>
												</div>
											</div>
										</div>
										<?php
										}
									}
								}
							?>
						</div>
						<div class="clearfix"><p></p></div>
						<?php
							if(sizeof($gallery_ids_array)<$image_limit){
							?>
							<div class="docmargin" >
								<button type="button" onclick="edit_gallery_doc('gallery_doc_div');"  class="btn btn-sm tirtiary"><?php esc_html_e('Add PDF Doc','finaluser'); ?></button>
							</div>
						</div>
						<div class="docmargin2">
							<?php esc_html_e('PDF Upload Limit: ','finaluser'); ?> <?php echo esc_html($image_limit);?> [ <?php echo esc_html($image_limit);?> <?php esc_html_e('PDF(s) will publish ','finaluser'); ?> ]
						</div>
						<div class="margiv-top-10"  >
							<div class="margiv-top-10 save-change-button-content text-right" >
								<div class="" id="update_message_doc"></div>
								<button type="button" onclick="update_profile_doc();"  class="btn-new btn-custom"><?php  esc_html_e('Save Doc','finaluser');?></button>
							</div>
						</div>
						<?php
						}else{ ?>
						<div class="docmargin2" >
							<?php esc_html_e('PDF Upload Limit: ','finaluser'); ?> <?php echo esc_html($image_limit);?> [  <?php echo esc_html($image_limit);?> <?php esc_html_e('PDF(s) will publish ','finaluser'); ?> ]
						</div>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</div>
</form>