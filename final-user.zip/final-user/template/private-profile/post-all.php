<?php	
	$profile_url=get_permalink();
	global $current_user;
	$user = $current_user->ID;
	$message='';
	if(isset($_GET['delete_id']))  {
		$post_id=sanitize_text_field($_GET['delete_id']);
		$post_edit = get_post($post_id);
		if($post_edit->post_author==$current_user->ID){
			wp_delete_post($post_id);
				delete_post_meta($post_id,true);
				$message=esc_html__( 'Deleted Successfully', 'finaluser' ) ;
			}else{
			if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
				wp_delete_post($post_id);
				delete_post_meta($post_id,true);
				$message=esc_html__( 'Deleted Successfully', 'finaluser' ) ;
			}
		}
	}
wp_enqueue_style('dataTables', finaluser_URLPATH . 'admin/files/css/jquery.dataTables.css');
wp_enqueue_script('dataTables', finaluser_URLPATH . 'admin/files/js/jquery.dataTables.js');

?>
<div class="profile-content">
  <div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('All Posts', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						if($message!=''){
							echo  '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'.$message.'.</div>';
						}
					?>
					<?php
						global $wpdb;
						$per_page=10;$row_strat=0;$row_end=$per_page;
						$current_page=0 ;
						$args = array(
						'public'   => true,
						'_builtin' => false
						);
						$output = 'names'; 
						$operator = 'and';
						$post_types = get_post_types( $args, $output, $operator );
						$postkey[] ='post';
						foreach($post_types as $key => $value)
						{
							if($key!='product' AND $key!='iv_review'){
								$postkey[] = $key;
							}
						}
						$post_type = join("','",$postkey);
						if(isset($_REQUEST['cpage']) and $_REQUEST['cpage']!=1 ){
							$current_page=$_REQUEST['cpage']; $row_strat =($current_page-1)*$per_page;
							$row_end=$per_page;
						}
						$post_type='post';
						if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
								$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type IN ('%s')  and post_status IN ('publish','pending','draft' )  ORDER BY `ID` DESC",$post_type );
							}else{
								$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type IN ('%s')  and post_author='".$current_user->ID."' and post_status IN ('publish','pending','draft' )  ORDER BY `ID` DESC", $post_type );
						}
						$authpr_post = $wpdb->get_results($sql);						
						$total_post=count($authpr_post);
						if($total_post>0){
						?>
						<table id="user-data" class="display table" cellspacing="0" width="100%">
							<thead>							
								<tr class="">
									<th><?php  esc_html_e('Title','finaluser');?></th>
									<th><?php  esc_html_e('Type','finaluser');?></th>
									<th><?php  esc_html_e('Status','finaluser');?></th>
									<th><?php  esc_html_e('Actions','finaluser');?></th>
								</tr>
							</thead>
							<?php
								$i=0;
								foreach ( $authpr_post as $row ){
								?>
								<tr>
									<td style="">
										<a class="profile-desc-link" href="<?php echo get_permalink($row->ID); ?>" >
											
										<?php echo esc_html($row->post_title); ?></a>
									</td>
									<td  class="tdfont">
										<?php echo esc_html($row->post_type); ?>
									</td>
									<td  class="tdfont"><?php echo get_post_status( $row->ID ) ?></td>
									<td >
										<?php
											$edit_post= $profile_url.'?&profile=edit-post&post-id='.$row->ID;
										?>
										<a href="<?php echo esc_url($edit_post); ?>" class="btn btn-xs green-haze" ><?php esc_html_e('Edit','finaluser'); ?></a>
										<a href="<?php echo esc_url($profile_url).'?&profile=all-posts&delete_id='.esc_html($row->ID) ;?>"  onclick="return confirm('Are you sure to delete this post?');"  class="btn btn-xs btn-danger"><?php esc_html_e('Delete','finaluser'); ?>
										</a></td>
								</tr>
								<?php
								}
							?>
						</table>
						<?php
							}else{
						?>
						<table>
							<tr>
								<td colspan="100%">
									<?php esc_html_e('Currently you have no listings added. Please manage your account from the sidebar on the left.','finaluser'); ?>
								</td>
							</tr>
						</table>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</div>
</div>