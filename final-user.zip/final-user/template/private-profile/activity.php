<div class="profile-content">            
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Activity', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<div class="row">
						<div class="col-md-12">
							<?php include('buddypress-status-form.php'); ?>
						</div>
					</div>
					<?php
						// Hide if BuddyPress is not active.
						if ( ! function_exists( 'buddypress' ) ) {
							return '';
						}
						// allow to use all those args awesome!
						$atts = shortcode_atts( array(
						'title'            => 'Latest Activity',// title of the section.
						'pagination'       => 1,// show or not.
						'load_more'        => 0,
						'display_comments' => 'threaded',
						'include'          => false,   
						'exclude'          => false,     
						'in'               => false,     
						'sort'             => 'DESC',    
						'page'             => 1,         
						'per_page'         => 5,         
						'max'              => false,     
						'count_total'      => true,
						
						'scope'            => false,
						// Filtering
						'user_id'          => false,    
						'object'           => false,   
						'action'           => false,   
						'primary_id'       => false,   
						'secondary_id'     => false,   
						// Searching
						'search_terms'     => false,        
						'use_compat'       => bp_use_theme_compat_with_current_theme(),
						'allow_posting'    => false,    
						'container_class'  => 'activity',
						'hide_on_activity' => 1,
						'for'              => '', 
						'role'             => '', 
						), $atts );
						
						if ( $atts['hide_on_activity'] && ( function_exists( 'bp_is_activity_component' ) && bp_is_activity_component() ||
						function_exists( 'bp_is_group_home' ) && bp_is_group_home() ) ) {
							return '';
						}
						$activity_for = $atts['for'];
						if ( ! empty( $activity_for ) ) {
							unset( $atts['for'] );
							$atts['user_id'] = $this->get_user_id_for_context( $activity_for );
							if ( empty( $atts['user_id'] ) ) {
								return '';
							}
						}
						// Fetch users for role and use their activity.
						if ( ! empty( $atts['role'] ) ) {
							$user_ids        = $this->get_user_ids_by_roles( $atts['role'] );
							$atts['user_id'] = $user_ids;
						}
						$this->doing_shortcode = true;
						// start buffering.
						ob_start();
						do_action( 'bp_activity_stream_shortcode_before_generate_content', $atts );
					?>
					<?php if ( $atts['use_compat'] ) : ?>
					<div id="buddypress">
						<?php endif; ?>
						<?php if ( $atts['title'] ) : ?>
						<h3 class="activity-shortcode-title"><?php echo esc_html($atts['title']); ?></h3>
						<?php endif; ?>
						<?php do_action( 'bp_before_activity_loop' ); ?>
						<?php if ( $atts['allow_posting'] && is_user_logged_in() ) : ?>
						<?php bp_locate_template( array( 'activity/post-form.php' ), true ); ?>
						<?php endif; ?>
						<?php if ( bp_has_activities( $atts ) ) : ?>
						<div class="<?php echo esc_attr( $atts['container_class'] ); ?> <?php if ( ! $atts['display_comments'] ) : ?> hide-activity-comments<?php endif; ?> shortcode-activity-stream">
							<?php if ( empty( $_POST['page'] ) ) : ?>
							<ul id="activity-stream" class="activity-list item-list">
								<?php endif; ?>
								<?php while ( bp_activities() ) : bp_the_activity(); ?>
								<?php bp_get_template_part( 'activity/entry' ); ?>
								<?php endwhile; ?>
								<?php if ( $atts['load_more'] && bp_activity_has_more_items() ) : ?>
								<li class="load-more">
									<a href="<?php bp_activity_load_more_link() ?>"><?php esc_html_e( 'Load More', 'buddypress' ); ?></a>
								</li>
								<?php endif; ?>
								<?php if ( empty( $_POST['page'] ) ) : ?>
							</ul>
							<?php endif; ?>
							<?php if ( $atts['pagination'] && ! $atts['load_more'] ) : ?>
							<div class="pagination">
								<div class="pag-count"><?php bp_activity_pagination_count(); ?></div>
								<div class="pagination-links"><?php bp_activity_pagination_links(); ?></div>
							</div>
							<?php endif; ?>
						</div>
						<?php else : ?>
						<div id="message" class="info">
							<p><?php esc_html_e( 'Sorry, there was no activity found. Please try a different filter.', 'buddypress' ); ?></p>
						</div>
						<?php endif; ?>
						<?php do_action( 'bp_after_activity_loop' ); ?>
						<form action="" name="activity-loop-form" id="activity-loop-form" method="post">
							<?php wp_nonce_field( 'activity_filter', '_wpnonce_activity_filter' ); ?>
						</form>
						<?php if ( $atts['use_compat'] ) : ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>