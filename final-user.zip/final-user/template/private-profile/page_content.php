<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php $header='';
				if($_GET['header']){ $header=$_GET['header'];}
			echo esc_html($header); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						$post = get_post($menu_page_id);
						$content = apply_filters('the_content', $post->post_content);
						echo do_shortcode($content); 
					?>
				</div>
			</div>
		</div>
	</div>
</div>