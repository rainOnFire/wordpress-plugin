<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Downloads', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						$downloads     = WC()->customer->get_downloadable_products();
						$has_downloads = (bool) $downloads;
					do_action( 'woocommerce_before_account_downloads', $has_downloads ); ?>
					<?php if ( $has_downloads ) : ?>
					<?php do_action( 'woocommerce_before_available_downloads' ); ?>
					<?php do_action( 'woocommerce_available_downloads', $downloads ); ?>
					<?php do_action( 'woocommerce_after_available_downloads' ); ?>
					<?php else : ?>
					<div class="woocommerce-Message woocommerce-Message--info woocommerce-info">
						<a class="woocommerce-Button button" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
							<?php esc_html_e( 'Go shop', 'finaluser' ) ?>
						</a>
						<?php esc_html_e( 'No downloads available yet.', 'finaluser' ); ?>
					</div>
					<?php endif; ?>      
				</div>
			</div>
		</div>
	</div>
</div>