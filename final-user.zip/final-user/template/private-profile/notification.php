<?php
	// let us get the notifications for the user.
	$notifications='';
	if ( function_exists( 'bp_notifications_get_notifications_for_user' ) ) {
		$notifications = bp_notifications_get_notifications_for_user( get_current_user_id(), 'string' );
		} else {
		if ( function_exists( 'bp_core_get_notifications_for_user' ) ) {
			$notifications = bp_core_get_notifications_for_user( get_current_user_id(), 'string' );
		}
	}
	if ( empty( $notifications ) ) {
		$count = 0;
		} else {
		$count = count( $notifications );
	}
?>
<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Notification', 'finaluser'); ?> (<?php echo esc_html($count);?>)</h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 " id="all_notifications">
					<?php		
						echo '<ul class="bp-notification-list">';
						if ( $notifications ) { 
							$counter = 0;
							for ( $i = 0; $i < $count; $i ++ ) {
								$notification_item = '';
								if ( is_array( $notifications[ $i ] ) ) {
									$notification_item = sprintf( '<a href="%s">%s</a>', $notifications[ $i ]['link'], $notifications[ $i ]['text'] );
									} else {
									$notification_item = $notifications[ $i ];
								}
							$alt = ( 0 == $counter % 2 ) ? ' class="alt"' : ''; ?>
							<li <?php echo esc_html($alt); ?>><?php echo esc_html($notification_item); ?></li>
							<?php $counter ++;
							}
						} else { ?>
						<li><?php esc_html_e( "You don't have any new notification.", 'finaluser' ); ?></li>
						<?php
						}
						echo '</ul>';
					?>
					<div id="notification_message"></div>
					<?php
						if($count>0){
						?>
						<button type="button" onclick="ep_remove_notification();"  class="btn btn-sm tirtiary"><?php esc_html_e('Clear','finaluser'); ?></button>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>