<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('New Post', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<form action="" id="new_post" name="new_post"  method="POST" role="form">
						<div class=" form-group">
							<label for="text" class=" control-label"><?php esc_html_e('Post Type','finaluser'); ?></label>
							<div class="">
								<?php
									$args = array(
									'public'   => true,
									'_builtin' => false
									);
									$output = 'names'; 
									$operator = 'and'; 
									$iv_post='';
									$post_types = get_post_types( $args, $output, $operator );
									echo "<select id='cpt_page' name='cpt_page' class='form-control'>";
									echo "<option value='post' ".($iv_post=='post'? 'selected':'').">". esc_html__( 'Blog Post','finaluser')."</option>";
									echo "</select>";
								?>
							</div>
						</div>
						<div class=" form-group">
							<label for="text" class=" control-label"><?php  esc_html_e('Title','finaluser');?></label>
							<div class="  ">
								<input type="text" class="form-control" name="title" id="title" value="" placeholder="<?php  esc_html_e('Enter Title Here','finaluser');?>">
							</div>
						</div>
						<div class="form-group">
							<div class=" ">
								<?php
									$settings_a = array(
									'textarea_rows' =>10,
									'editor_class' => 'form-control'
									);
									$editor_id = 'new_post_content';
									wp_editor( '', $editor_id,$settings_a );
								?>
							</div>
						</div>
						<div class=" row form-group ">
							<label for="text" class=" col-md-5 control-label"><?php  esc_html_e('Feature Image','finaluser');?>  </label>
							<div class="col-md-4" id="post_image_div">
								<a  href="javascript:void(0);" onclick="edit_post_image('post_image_div');"  >
									<?php  echo '<img src="'. finaluser_URLPATH.'assets/images/image-add-icon.png">'; ?>
								</a>
							</div>
							<input type="hidden" name="feature_image_id" id="feature_image_id" value="">
							<div class="col-md-3" id="post_image_edit">
								<button type="button" onclick="edit_post_image('post_image_div');"  class="btn btn-xs green-haze"><?php  esc_html_e('Add','finaluser');?></button>
							</div>
						</div>
						<div class="clearfix"></div>
						<label for="text" class="row col-md-12 control-label"><?php  esc_html_e('Custom Fields','finaluser');?> </label>
						<div id="custom_field_div">
							<div class=" row form-group " >
								<div class=" col-md-6"> <input type="text" class="form-control" name="custom_name[]" id="custom_name[]" value="" placeholder="<?php  esc_html_e('Custom Field Name','finaluser');?>" > </div>
								<div  class=" col-md-6">
									<textarea name="custom_value[]" id="custom_value[]"  class=" col-md-12 form-control"  rows="1"placeholder="<?php  esc_html_e('Value','finaluser');?>" ></textarea>
								</div>
							</div>
						</div>
						<div class=" row  form-group ">
							<div class="col-md-12" >
								<button type="button" onclick="add_custom_field();"  class="btn btn-xs green-haze"><?php  esc_html_e('More Field','finaluser');?></button>
							</div>
						</div>
						<div class="clearfix"></div>
						<div class=" row form-group ">
							<label for="text" class=" col-md-12 control-label"><?php  esc_html_e('Post Status','finaluser');?>  </label>
							<div class="col-md-12" id="">
								<select name="post_status" id="post_status"  class="form-control">
									<option value="pending"><?php  esc_html_e('Pending Review','finaluser');?></option>
									<option value="draft"><?php  esc_html_e('Draft','finaluser');?></option>
								</select>
							</div>
						</div>
						<div class="clearfix"></div>
						<div class=" row form-group">
							<label for="text" class=" col-md-12 control-label"><?php  esc_html_e('Category','finaluser');?></label>
							<div class=" col-md-12 " id="select_cpt">
								<?php
									$cat_type= 'category';
									$custom_post_type='post';
									$args2 = array(
									'type'                     => $custom_post_type,
									'orderby'                  => 'name',
									'order'                    => 'ASC',
									'hide_empty'        	   => false,
									'hierarchical'             => 0,
									'taxonomy'                 => $cat_type,
									'pad_counts'               => false
									);
									$categories = get_categories( $args2 );
									if ( $categories && !is_wp_error( $categories ) ) {
										$val_cat2='<select name="postcats" id="postcats" class="form-control">';
										$val_cat2=$val_cat2.'<option  value="">'.esc_html__( 'Any Category','finaluser').'</option>';
										foreach ( $categories as $term ) {
											$val_cat2=$val_cat2. '<option  value="'.$term->slug.'" >'.$term->name.'</option>';
										}
										$val_cat2=$val_cat2.'</select>';
									}
									echo $val_cat2;
								?>
							</div>
						</div>
						<div class="margiv-top-10">
							<div class="" id="update_message"></div>
							<input type="hidden" name="user_post_id" id="user_post_id" value="<?php echo esc_html($curr_post_id); ?>">
							<button type="button" onclick="iv_save_post();"  class="btn green-haze"><?php  esc_html_e('Save Post','finaluser');?></button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	wp_enqueue_script('ep_finaluser-add-edit', finaluser_URLPATH.'admin/files/js/add-edit.js', array('jquery'), $ver = true, true );
	wp_localize_script('ep_finaluser-add-edit', 'ep_data2', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'pdf_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/pdf.png">',	
	'current_user_id'	=>get_current_user_id(),
	'postuser'	=>  $user_id,
	'set_Image'		=> esc_html__( 'Set Image','finaluser'),
	'Backgroung_Image'		=> esc_html__( 'Backgroung Image','finaluser'),
	'all_post_url'			=> '?&profile=all-posts', 
	'finalwpnonce'=>  wp_create_nonce("settings"),
	) );
?>
