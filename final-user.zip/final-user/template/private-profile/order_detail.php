<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('My Order', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						$order_id=$_REQUEST['order_id'];
					?>
					<?php do_action( 'woocommerce_view_order', $order_id ); ?>      
				</div>
			</div>
		</div>
	</div>
</div>