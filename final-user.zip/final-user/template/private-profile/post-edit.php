<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Edit Post', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						$curr_post_id=$_REQUEST['post-id'];
						$current_post = $curr_post_id;
						$post_edit = get_post($curr_post_id);
						$title = $post_edit->post_title;
						$content = $post_edit->post_content;
						// Author Check
						if ( $post_edit->post_author != $current_user->ID) {
							$iv_redirect = get_option( '_ep_finaluser_login_page');
							$reg_page= get_permalink( $iv_redirect);
						?>
						<?php  esc_html_e('Please','finaluser');?> <a href="<?php echo esc_url($reg_page); ?>" title="Login"><?php  esc_html_e('Login','finaluser');?></a> <?php  esc_html_e('To Edit The Post.','finaluser');?>
						<?php
							}else{
						?>
						<form action="" id="edit_post" name="edit_post"  method="POST" role="form">
							<div class=" form-group">
								<label for="text" class=" control-label"><?php  esc_html_e('Title','finaluser');?></label>
								<div class="  ">
									<input type="text" class="form-control" name="title" id="title" value="<?php echo esc_html($title);?>" placeholder="<?php esc_html_e('Enter Title Here','finaluser'); ?>">
								</div>
							</div>
							<div class="form-group">
								<div class=" ">
									<?php
										$settings_a = array(
										'textarea_rows' =>10,
										'editor_class' => 'form-control'
										);
										$content_client =$content;
										$editor_id = 'edit_post_content';
										wp_editor( $content_client, $editor_id,$settings_a );
									?>
								</div>
							</div>
							<div class=" row form-group ">
								<label for="text" class=" col-md-5 control-label"><?php  esc_html_e('Feature Image','finaluser');?> </label>
								<div class="col-md-4" id="post_image_div">
									<?php $feature_image = wp_get_attachment_image_src( get_post_thumbnail_id( $curr_post_id ), 'thumbnail' );
										if(isset($feature_image[0])){ ?>
										<img title="profile image" class=" img-responsive" src="<?php  echo esc_url($feature_image[0]); ?>">
										<?php
										}else{ ?>
										<a href="javascript:void(0);" onclick="edit_post_image('post_image_div');"  >
											<?php  echo '<img src="'. finaluser_URLPATH.'assets/images/image-add-icon.png">'; ?>
										</a>
										<?php
										}
										$feature_image_id=get_post_thumbnail_id( $curr_post_id );
									?>
								</div>
								<input type="hidden" name="feature_image_id" id="feature_image_id" value="<?php echo esc_html($feature_image_id);  ?>">
								<div class="col-md-3" id="post_image_edit">
									<?php
										if(isset($feature_image[0])){
										?>
										<button type="button" onclick="edit_post_image('post_image_div');"  class="btn btn-xs green-haze"><?php  esc_html_e('Edit','finaluser');?></button>
										<button type="button" onclick="remove_post_image('post_image_div');"  class="btn btn-xs green-haze"><?php  esc_html_e('Remove','finaluser');?></button>
										<?php
										}else{ ?>
										<button type="button" onclick="edit_post_image('post_image_div');"  class="btn btn-xs green-haze"><?php  esc_html_e('Add','finaluser');?></button>
										<?php
										}
									?>
								</div>
							</div>
							<div class="clearfix"></div>
							<?php
								$custom_fields = get_post_custom($curr_post_id);
							?>
							<label for="text" class="row col-md-12 control-label"><?php  esc_html_e('Custom Fields','finaluser');?> </label>
							<div id="custom_field_div">
								<?php
									foreach ( $custom_fields as $field_key => $field_values ) {
										if(!isset($field_values[0])){ continue;}
										$underscore_str=substr($field_key,0,1);
										if($underscore_str!='_'){
											echo '<div class="row form-group "><div class=" col-md-6"> <input type="text" class="form-control" name="custom_name[]" id="custom_name[]" value="'.$field_key . '" placeholder="Custom Field Name"> </div>
											<div  class=" col-md-6">
											<textarea name="custom_value[]" id="custom_value[]"  class="form-control col-md-12"  rows="1" placeholder="Value">'.$field_values[0].'</textarea>
											</div></div>';
										}
									}
								?>
							</div>
							<div class=" row  form-group ">
								<div class="col-md-12" >
									<button type="button" onclick="add_custom_field();"  class="btn btn-xs green-haze"><?php  esc_html_e('More Field','finaluser');?></button>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class=" row form-group ">
								<label for="text" class=" col-md-12 control-label"><?php  esc_html_e('Post Status','finaluser');?>  </label>
								<div class="col-md-12" id="">
									<select name="post_status" id="post_status"  class="form-control">
										<option value="pending"<?php echo (get_post_status( $post_edit->ID )=='pending'?'selected="selected"':'' ) ; ?> ><?php  esc_html_e('Pending Review','finaluser');?></option>
										<option value="draft" <?php echo (get_post_status( $post_edit->ID )=='draft'?'selected="selected"':'' ) ; ?> ><?php  esc_html_e('Draft','finaluser');?></option>
									</select>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class=" row form-group">
								<label for="text" class=" col-md-10 control-label"><?php  esc_html_e('Category','finaluser');?></label>
								<div class=" col-md-12 ">
									<?php
										if(wp_get_post_categories($post_edit->ID )){
											$currentCategory = wp_get_post_categories($post_edit->ID );  
										}
										$custom_post_type=$post_edit->post_type;
										if($custom_post_type=='post'){
											$cat_type= 'category';
											$args2 = array(
											'type'                     => $custom_post_type,
											'orderby'                  => 'name',
											'order'                    => 'ASC',
											'hide_empty'        	   => false,
											'hierarchical'             => 0,
											'taxonomy'                 => $cat_type,
											'pad_counts'               => false
											);
											$categories = get_categories( $args2 );
											if ( $categories && !is_wp_error( $categories ) ) {
												$val_cat2='<select name="postcats[]" id="postcats[]" class="form-control" multiple>';
												foreach ( $categories as $term ) {
													$selected="";
													if( in_array($term->term_id, $currentCategory)){ $selected="selected='selected'";}
													$val_cat2=$val_cat2. '<option  value="'.$term->term_id.'" '.$selected.'>'.$term->name.'</option>';
												}
												echo $val_cat2.'</select>';
											}
											}else{
											$cat_type= $custom_post_type.'-category';
											$taxonomy = $custom_post_type;
											$terms = get_terms($taxonomy);
											if ( $terms && !is_wp_error( $terms ) ) :
											$val_cat2='<select name="postcats" id="postcats" class="form-control" multiple>';
											foreach ( $terms as $term ) {
												$val_cat2=$val_cat2. '<option  value="'.$term->slug.'" >'.$term->name.'</option>';
											}
											echo $val_cat2.'</select>';
											endif;
										}
									?>
								</div>
							</div>
							<div class="margiv-top-10">
								<div class="" id="update_message"></div>
								<input type="hidden" name="user_post_id" id="user_post_id" value="<?php echo esc_html($curr_post_id); ?>">
								<button type="button" onclick="iv_update_post();"  class="btn green-haze"><?php  esc_html_e('Update Post','finaluser');?></button>
							</div>
						</form>
						<?php
						} // for Role
					?>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- END PROFILE CONTENT -->
<?php
	wp_enqueue_script('ep_finaluser-add-edit', finaluser_URLPATH.'admin/files/js/add-edit.js', array('jquery'), $ver = true, true );
	wp_localize_script('ep_finaluser-add-edit', 'ep_data2', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'pdf_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/pdf.png">',	
	'current_user_id'	=>get_current_user_id(),
	'postuser'	=>  $user_id,
	'set_Image'		=> esc_html__( 'Set Image','finaluser'),
	'Backgroung_Image'		=> esc_html__( 'Backgroung Image','finaluser'),
	'all_post_url'			=> '?&profile=all-posts', 
	'finalwpnonce'=>  wp_create_nonce("settings"),
	) );
?>