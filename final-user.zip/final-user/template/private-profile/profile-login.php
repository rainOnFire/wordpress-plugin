<?php
	wp_enqueue_script("jquery");
	wp_enqueue_style('wp-ep_finaluser-style-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_style('wp-ep_finaluser-style-12', finaluser_URLPATH . 'admin/files/css/profile-login-sign-up.css');
	wp_enqueue_style('wp-ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');
	wp_enqueue_style('font-awesome', finaluser_URLPATH . 'admin/files/css/font-awesome/css/font-awesome.min.css');
	require(finaluser_DIR .'/admin/files/css/color_style.php');
?>
<div id="login-2" class="bootstrap-wrapper">
	<div class="menu-toggler sidebar-toggler">
	</div>
	<div class="login-area registration-area  user-information-area">
		<form id="login_form" class="login-form" action="" method="post">
			<h2 class="form-title"><?php  esc_html_e('Sign In','finaluser');?></h2>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="form-content">
					<div class="display-hide" id="error_message">
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-12 lc-user">
								<label class="control-label visible-ie8 visible-ie9"><?php  esc_html_e('User Name','finaluser');?><i class="fa fa-user"></i></label>
							</div>
							<div class="col-md-12">
								<input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" placeholder="<?php esc_html_e( 'User Name', 'finaluser' ); ?>" name="username" id="username"/>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-12 lc-pass">
								<label class="control-label visible-ie8 visible-ie9"><?php  esc_html_e('Password','finaluser');?><i class="fa fa-key"></i></label>
							</div>
							<div class="col-md-12">
								<input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="<?php esc_html_e( 'Password', 'finaluser' ); ?>" name="password" id="password"/>
							</div>
						</div>
					</div>
					<div class="form-actions row">
						<div class="col-md-3 col-sm-4 col-xs-4">
							<button type="button" class="btn-new btn-custom" onclick="return chack_login();" ><?php  esc_html_e('Login','finaluser');?></button>
						</div>
						<p class="margin-20 para col-md-3 col-sm-4 col-xs-4 text-right">
							<input type="checkbox" id="test2" checked="checked" />
							<label for="test2"><?php  esc_html_e('Remember','finaluser');?> </label>
						</p>
						<p class="margin-20 para col-md-3 col-sm-4 col-xs-4 text-right">
							<a href="javascript:;" class="forgot-link"><?php  esc_html_e('Forgot Password?','finaluser');?> </a>
						</p>
					</div>
				</div>
				<?php
					if(has_action('oa_social_login')) {
					?>
					<div class="form-actions row">
						<div class="col-md-4"> </div>
						<div class="col-md-3">  <?php echo do_action('oa_social_login'); ?></div>
						<div class="col-md-3"> </div>
					</div>
					<?php
					}
				?>
				<div class="lc-create-account">
					<p class="margin0"><?php
						$iv_redirect = get_option( '_ep_finaluser_price_table');
						$reg_page= get_permalink( $iv_redirect);
					?><?php  esc_html_e('Are you a new user?','finaluser');?>
					<a  href="<?php echo esc_url($reg_page);?>" id="register-btn" class="uppercase"><?php  esc_html_e('Create an account','finaluser');?>  </a>
					</p>
				</div>
			</div>
		</form>
		<form id="forget-password" name="forget-password" class="forget-form" action="" method="post" >
			<h2 class="form-title"><?php  esc_html_e('Forget Password ?','finaluser');?>  </h2>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="form-content">
					<div class="row">
						<div class="col-md-12">
							<div id="forget_message">
								<label>
									<?php  esc_html_e('Enter your e-mail address','finaluser');?>
								</label>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input class="form-control form-control-solid placeholder-no-fix" type="text"  placeholder=" <?php esc_html_e('Email','finaluser'); ?>" name="forget_email" id="forget_email"/>
							</div>
							<div class="">
								<button type="button" id="back-btn" class="btn-new btn-warning margin-b-30"><?php  esc_html_e('Back','finaluser');?> </button>
								<button type="button" onclick="return forget_pass();"  class="btn-new btn-custom pull-right margin-b-30"><?php  esc_html_e('Submit','finaluser');?> </button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<?php
	wp_enqueue_script('iv_real-ar-script-27', finaluser_URLPATH . 'admin/files/js/login.js');
	wp_localize_script('iv_real-ar-script-27', 'finaldata', array(
	'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'current_user_id'	=>get_current_user_id(),
	'forget_sent'=> esc_html__( 'Password Sent. Please check your email.','finaluser'),
	'login_error'=> esc_html__( 'Invalid Username & Password.','finaluser'),
	'login_validator'=> esc_html__( 'Enter Username & Password.','finaluser'),
	'forget_validator'=> esc_html__( 'Enter Email Address','finaluser'),
	) );
?>