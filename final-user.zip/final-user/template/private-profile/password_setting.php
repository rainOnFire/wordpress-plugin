<form action="" name="pass_word" id="pass_word">
	<div class="profile-content">
		<div class="row">
			<div class="col-md-12">
				<h3><?php echo esc_html_e('Password Setting', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class="margiv-top-10 ">
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Current Password','finaluser');?> </label>
							<input type="password" id="c_pass" name="c_pass" class="form-control-solid"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('New Password','finaluser');?> </label>
							<input type="password" id="n_pass" name="n_pass" class="form-control-solid"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Re-type New Password','finaluser');?> </label>
							<input type="password" id="r_pass" name="r_pass" class="form-control-solid"/>
						</div>
					</div>
					<div class="margiv-top-10">
						<div class="margiv-top-10 save-change-button-content text-right">
							<div class="" id="update_message_pass"></div>
							<button type="button" onclick="iv_update_password();"  class="btn-new btn-custom"><?php  esc_html_e('Change Password','finaluser');?> </button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>	