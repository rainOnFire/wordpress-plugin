<?php
	$bp = buddypress();
	global $bp, $wpdb;
	$order='DESC';
	$sql=$wpdb->prepare("SELECT * FROM ".$wpdb->prefix."bp_messages_recipients where user_id='%s' group by thread_id ORDER BY id ", $user_id);
	$all_message = $wpdb->get_results($sql);
?>
<div class="profile-content bootstrap-wrapper"  >
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Message Sent', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 " id="all_message">
					<div class="bs-example" data-example-id="striped-table">
						<table class="table table-striped">
							<thead>
								<tr> <th width="20%"><?php  esc_html_e('To','finaluser');?></th> <th width="60%"><?php  esc_html_e('Subject','finaluser');?></th> <th width="20%"> <?php  esc_html_e('Date','finaluser');?></th>
								</tr>
							</thead>
							<tbody>
								<?php
									if(sizeof($all_message)>0){
										$i=0;
										foreach ( $all_message as $row )
										{
											$this->thread        = new BP_Messages_Thread( $row->thread_id, $order, $args = array());
											$this->message_count = count( $this->thread->messages );
											foreach($this->thread->messages as $thread){
												$recipient_id=0;
												foreach($this->thread->recipients as $recipient ){
													if($recipient->sender_only=='0'){
														$recipient_id =  $recipient->user_id;
													}
												}
												if($thread->sender_id==$user_id){
												?>
												<tr <?php echo($row->unread_count=="1"? ' class="mailstrong"':'') ?> >
													<td><?php
														$user_mail = get_user_by('id', $recipient_id );
														if($user_mail){
															$name_display=get_user_meta($recipient_id,'first_name',true).' '.get_user_meta($recipient_id,'last_name',true);
															echo (trim($name_display)!=""? $name_display : $user_mail->display_name );
														}
													?></td>
													<td><?php
													echo esc_html($thread->subject);?></td> <td><?php echo esc_html($thread->date_sent);?></td>
												</tr>
												<?php
												}
											}
										}
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>