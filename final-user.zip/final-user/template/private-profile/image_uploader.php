<div class="col-md-12">
	<label class="control-label"><?php echo esc_html_e('Avatar', 'finaluser'); ?></label>
	<div class="profile-userpic" id="profile_image_main">
		<?php
			$iv_profile_pic_url=get_user_meta($current_user->ID, 'iv_profile_pic_url',true);
			if($iv_profile_pic_url!=''){ ?>
			<?php
				}else{
				$avatar_img = get_avatar( $current_user->ID, 300 );
				echo esc_html($avatar_img);
				preg_match("/src=['\"](.*?)['\"]/i", $avatar_img, $matches);
				if($matches[1]!=''){
					update_user_meta($current_user->ID, 'iv_profile_pic_url',$matches[1]);
				}
			}
		?>
		<img src="<?php echo esc_url($iv_profile_pic_url); ?>">
	</div>
</div>
<div class="col-md-12">
	<div class="profile-userbuttons">
		<button type="button" onclick="edit_profile_image('profile_image_main');"  class="btn btn-sm tirtiary"><?php esc_html_e('Change','finaluser'); ?> </button>
	</div>
</div>
<div class="col-md-12">
	<label class="control-label"><?php echo esc_html_e('Banner Image', 'finaluser'); ?></label>
	<div class="profile-userpic " id="background_image_main">
		<?php
			$iv_profile_pic_url=get_user_meta($current_user->ID, 'iv_background_pic_url',true);
			if($iv_profile_pic_url!=''){ ?>
			<img src="<?php echo esc_url($iv_profile_pic_url); ?>">
			<?php
				}else{
				echo'	 <img src="'. finaluser_URLPATH.'assets/images/version-4bg.jpg'.'">';
			}
		?>
	</div>
</div>
<div class="col-md-12">
	<div class="profile-userbuttons">
		<button type="button" onclick="edit_background_image('background_image_main');"  class="btn btn-sm tirtiary"><?php esc_html_e('Change','finaluser'); ?> </button>
	</div>
</div>