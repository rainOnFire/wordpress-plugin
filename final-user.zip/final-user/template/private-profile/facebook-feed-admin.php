<div class="profile-content bootstrap-wrapper"  >
		<div class="row">
			<div class="col-md-12">
				<h3><?php echo esc_html_e('Facebook Feed Settings', 'finaluser'); ?></h3>
					<div class="photo-setting-single">
						<div class="arrow"></div>
						<div class="margiv-top-10 " id="all_message">
							<div class="row">
								<?php  $title='';?>
								<div class="col-md-12">
									<div id="messagefacebook"> </div>
									<form name="facebooksetting" id="facebooksetting">
										<div class=" form-group">
											<label for="text" class="control-label"><?php  esc_html_e('Facebook Page ID [e.g 6002238585 or Discovery]','finaluser');?></label>
											<div class="  ">
												<input type="text" class="form-control" name="final_facebookpage_id" id="final_facebookpage_id" value="<?php echo get_user_meta($current_user->ID,'final_facebookpage_id',true);?>" placeholder="<?php esc_html_e('Enter Page ID','finaluser'); ?>">
											</div>
										</div>

										<div class=" form-group">
											<label for="text" class=" control-label"><?php  esc_html_e('Facebook App ID( Optional )','finaluser');?></label>
											<div class="  ">
												<input type="text" class="form-control" name="final_facebookapp_id" id="final_facebookapp_id" value="<?php echo get_user_meta($current_user->ID,'final_facebookapp_id',true);?>" placeholder="<?php esc_html_e('Enter Facebook App ID','finaluser'); ?>">
											</div>
											<div >
											 <a href="https://developers.facebook.com/docs/apps/register#step-by-step-guide" target="_blank"><?php esc_html_e('Create facebook app id','finaluser'); ?></a>
											</div>

										</div>
										<div class=" form-group">
											<label for="text" class=" control-label"><?php  esc_html_e('Facebook App Secret ( Optional )','finaluser');?></label>
											<div class="  ">
												<input type="text" class="form-control" name="final_facebookappsecret" id="final_facebookappsecret" value="<?php echo get_user_meta($current_user->ID,'final_facebookappsecret',true);?>" placeholder="<?php esc_html_e('Enter Facebook App Secret','finaluser'); ?>">
											</div>
										</div>
										<div class=" form-group">
											<label for="text" class=" control-label"><?php  esc_html_e('Number of Posts( Optional )','finaluser');?></label>
											<div class="  ">
												<input type="text" class="form-control" name="final_facebookpost_limit" id="final_facebookpost_limit" value="<?php echo get_user_meta($current_user->ID,'final_facebookpost_limit',true);?>" placeholder="<?php esc_html_e('(eg. 10) Default value : 10','finaluser'); ?>">
											</div>
										</div>
										<div class=" form-group">
											<label for="text" class=" control-label"><?php  esc_html_e('Each Post Length ( Optional )','finaluser');?></label>
											<div class="  ">
												<input type="text" class="form-control" name="final_facebookpostlength" id="final_facebookpostlength" value="<?php echo get_user_meta($current_user->ID,'final_facebookpostlength',true);?>" placeholder="<?php esc_html_e('(eg. 50) Default value : 200','finaluser'); ?>">
											</div>
										</div>



									</form>
									<button type="button" onclick="ep_save_facebooksetting();"  class="btn btn-primary"><?php esc_html_e('Save','finaluser'); ?></button>
								</div>
								<div class="form-group">
									<label for="text" class=" control-label col-sm-12">
									<?php esc_html_e('Note : If you do not get any facebook feed on your public profile page then save the form again. Cache is 6 hours.','finaluser'); ?>

									</label>
								</div>

							</div>
				</div>
				</div>
			</div>

		</div>
	</div>
</div>
