<?php
	$bp = buddypress();
	global $bp, $wpdb;
	global $messages_template;	
	$thread_id='1';
	$order='DESC';
	$thread_id=$_REQUEST['thread_id'];
	$sql2=$wpdb->prepare("SELECT * FROM ".$wpdb->prefix."bp_messages_recipients where user_id='%s' AND thread_id='%s' ", $user_id,$thread_id);
	$all_message2 = $wpdb->get_results($sql2);
	$sql=$wpdb->prepare("SELECT * FROM ".$wpdb->prefix."bp_messages_recipients where user_id='%s' group by thread_id ORDER BY id ", $user_id);
	$all_message = $wpdb->get_results($sql);
?>
<div class="profile-content bootstrap-wrapper"  >
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Message', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 " id="all_message">
					<?php
						if($all_message2[0]->user_id==$user_id){
							$this->thread = new BP_Messages_Thread( $thread_id, 'ASC', $args = array());
							foreach($this->thread->messages as $thread){
							?>
							<div class="row">
								<div class="col-md-12"> <strong>
									<?php 	echo esc_html($thread->subject);?>
								</strong>
								</div>
							</div>
							<?php
								break;
							}
							$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
							$reg_page_user='';
							if($iv_redirect_user!='defult'){
								$reg_page_user= get_permalink( $iv_redirect_user) ;
							}
							$listing_author_link=get_option('listing_author_link');
							if($listing_author_link==""){$listing_author_link='author';}
							$this->thread = new BP_Messages_Thread( $thread_id, $order, $args = array());
							foreach($this->thread->messages as $thread){
								if($listing_author_link=='author'){
									$reg_page_u= get_author_posts_url( $thread->sender_id );
									}else{
									$reg_page_u=$reg_page_user.'?&id='. $thread->sender_id ;
								}
							?>
							<hr/>
							<div class="row">
								<div class="col-md-1">
									<a href="<?php echo esc_url($reg_page_u);?>">
										<?php
											$iv_profile_pic_url=get_user_meta($thread->sender_id , 'iv_profile_pic_url',true);
											if($iv_profile_pic_url!=''){ ?>
											<img src="<?php echo esc_url($iv_profile_pic_url);?>">
											<?php
											}else{?>
											<img src="<?php echo finaluser_URLPATH; ?>assets/images/Blank-Profile.jpg">
											<?php
											}
										?>
									</a>
								</div>
								<div class="col-md-8">
									<a href="<?php echo esc_url($reg_page_u);?>">
										<strong>
											<?php
												$user_mail = get_user_by( 'id', $thread->sender_id );
												$name_display=get_user_meta($thread->sender_id,'first_name',true).' '.get_user_meta($thread->sender_id,'last_name',true);
												echo (trim($name_display)!=""? esc_html($name_display) : esc_html($user_mail->display_name) );
											?></strong></a>
								</div>
								<div class="col-md-3">
									<?php echo date("M-d-y| H-i a",strtotime($thread->date_sent));?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
								</div>
								<div class="col-md-10">
									<?php
										global $wpdb;
										$query = $wpdb->prepare("UPDATE {$wpdb->prefix}bp_messages_recipients SET unread_count='0'   WHERE thread_id='%s' AND sender_only=0 AND user_id='%s' LIMIT 1", $thread_id,$user_id);
										$wpdb->query($query);
										$content = apply_filters( 'the_content', $thread->message);
										$content = str_replace( ']]>', ']]&gt;', $content );
										echo esc_html($content);
									?>
								</div>
								<div class="col-md-1">
								</div>
							</div>
							<?php
							}
						?>
						<hr/>
						<div class="row">
							<div class="col-md-1">
							</div>
							<div class="col-md-10">
								<div id="sent_message"> </div>
								<div id="save_message"> </div>
								<form name="messagereplyform" id="messagereplyform">
									<div class="form-group">
										<label class="control-label"><h4><?php echo esc_html_e('Reply', 'finaluser'); ?></h4></label>
										<textarea rows="5" name="replycontent" id="replycontent" lass="form-control-solid"> </textarea>
									</div>
									<div style="form-group">
										<input type="hidden" name="thread_id" value="<?php echo esc_html($thread_id);?>">
									</div>
								</form>
								<button type="button" onclick="ep_send_message();"  class="btn btn-primary"><?php esc_html_e('Send','finaluser'); ?></button>
							</div>
							<div class="col-md-1">
							</div>
						</div>
					</div>
					<?php
						}else{
						esc_html_e('Access not allowed','finaluser');
					}
				?>
			</div>
		</div>
	</div>
</div>
</div>