<form role="form" name="profile_videos" id="profile_videos" action="#">
<div class="profile-content">
	<div class="row">

		<div class="col-md-12">
			<h3><?php echo esc_html_e('My Videos', 'finaluser'); ?></h3>

				<div class="photo-setting-single">
						<div class="arrow"></div>
						<div class="margiv-top-10 ">
							<?php
						   for($i=0;$i<60;$i++){
							   if(get_user_meta($user_id,'video'.$i,true)!=''){
											preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', get_user_meta($user_id,'video'.$i,true), $match);
											$youtube_id = $match[1];
										?>
								   <div id="video<?php echo esc_html($i);?>" class="col-md-4">

										<img src="https://i1.ytimg.com/vi/<?php echo esc_html($youtube_id);?>/hqdefault.jpg">
										<button type="button" onclick="remove_video('video<?php echo esc_html($i);?>');"  class="btn btn-xs btn-danger">X</button>

											<input type="hidden" name="video[]" value="<?php echo get_user_meta($user_id,'video'.$i,true);?>">
									</div>
								<?php
									}
								}
							?>

							<div id="videosD">
							</div>
							<?php
								$package_id=get_user_meta($current_user->ID, 'ep_finaluser_package_id',true);
							 $image_limit= get_post_meta($package_id, 'ep_finaluser_video_limit', true);
								$user_role= $current_user->roles[0];
								if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
									$image_limit=999999;
								}
							?>

								<div class="col-md-12 margin20">
									<button type="button" onclick="addVideo('video');"  class="btn btn-sm tirtiary"><?php  esc_html_e('Add More YouTube Link','finaluser');?></button>
								</div>

								<div class="col-md-12"  >
								<?php esc_html_e('Video Upload Limit: ','finaluser'); ?> <?php echo esc_html($image_limit);?> [ <?php echo esc_html($image_limit);?> <?php esc_html_e('video(s) will publish ','finaluser'); ?> ]
								</div>
							<div class="mt30">
								<div class="row">
								</div>
							</div>

							  <div class="margiv-top-10 save-change-button-content text-right">
									<div class="" id="update_message_gallery"></div>
								  <button type="button" onclick="update_videos();"  class="btn-new btn-custom"><?php  esc_html_e('Save Videos','finaluser');?></button>
							</div>

				</div>





	</div>


	</div>
	</div>
</form>