<div class="profile-content">
	<div class="row">
		<div class="col-md-12">
			<h3><?php echo esc_html_e('Subscriptions', 'finaluser'); ?></h3>
			<div class="photo-setting-single">
				<div class="arrow"></div>
				<div class="margiv-top-10 ">
					<?php
						if(class_exists('WC_Subscriptions')){
							WC_Subscriptions::get_my_subscriptions_template();
						}
					?>      
				</div>
			</div>
		</div>
	</div>
</div>