<?php
	global $wpdb;
	wp_enqueue_script("jquery");
	wp_enqueue_script("jquery-ui-core");
	wp_enqueue_style('jquery-ui', finaluser_URLPATH . 'admin/files/css/jquery-ui.css');	
	
	wp_enqueue_style('wp-ep_finaluser-myaccount-style-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_script('ep_finaluser-myaccount-style-12', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_script('ep_finaluser-myaccount-style-1n2', finaluser_URLPATH . 'admin/files/js/cssmenu.js');
	wp_enqueue_style('add-listing-stylemyaccountns', finaluser_URLPATH . 'assets/css/cssmenu.css');
	wp_enqueue_style('add-listing-stylemyaccount', finaluser_URLPATH . 'admin/files/css/my-account.css');
	wp_enqueue_style('ep_finaluser-myaccountsettings', finaluser_URLPATH . 'admin/files/css/my-account-settings.css');
	wp_enqueue_style('ep_finaluser-style-67', finaluser_URLPATH . 'assets/font/flaticon.css');
	wp_enqueue_style('font-awesome', finaluser_URLPATH . 'admin/files/css/font-awesome/css/font-awesome.min.css');
	require(finaluser_DIR .'/admin/files/css/color_style.php');
	wp_enqueue_style('ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');
	$color_setting=get_option('_dir_color');
	if($color_setting==""){$color_setting='#0099e5';}
	$color_setting=str_replace('#','',$color_setting);
	wp_enqueue_media();
	global $current_user;
	$user_id=$current_user->ID;
	require(finaluser_DIR .'/admin/files/css/color_style.php');
?>
<?php
	$profile_public=get_option('_ep_finaluser_profile_public_page');
	$listing_author_link=get_option('listing_author_link');
	if($listing_author_link==""){$listing_author_link='author';}
	if($listing_author_link=='author'){
		$profile_link= get_author_posts_url($user_id);
		}else{
		$profile_link=get_permalink($profile_public);
		$profile_link=$profile_link.'?&id='.$user_id;
	}
	$currencies = array();
	$currencies['AUD'] ='$';$currencies['CAD'] ='$';
	$currencies['EUR'] ='€';$currencies['GBP'] ='£';
	$currencies['JPY'] ='¥';$currencies['USD'] ='$';
	$currencies['NZD'] ='$';$currencies['CHF'] ='Fr';
	$currencies['HKD'] ='$';$currencies['SGD'] ='$';
	$currencies['SEK'] ='kr';$currencies['DKK'] ='kr';
	$currencies['PLN'] ='zł';$currencies['NOK'] ='kr';
	$currencies['HUF'] ='Ft';$currencies['CZK'] ='Kč';
	$currencies['ILS'] ='₪';$currencies['MXN'] ='$';
	$currencies['BRL'] ='R$';$currencies['PHP'] ='₱';
	$currencies['MYR'] ='RM';$currencies['AUD'] ='$';
	$currencies['TWD'] ='NT$';$currencies['THB'] ='฿';
	$currencies['TRY'] ='TRY';  $currencies['CNY'] ='¥';
	$currency= get_option('_ep_finaluser_api_currency');
	$currency_symbol=(isset($currencies[$currency]) ? $currencies[$currency] :$currency );
?>
<div id="profile-account2" class="bootstrap-wrapper around-separetor" >
	<div class="row margin-top-10">
        <div class="col-md-12">
			<div id="stripes4" class="pattern">
				<div class="image-container" style="background: url('<?php echo esc_html($this->get_iv_user_image($user_id)); ?>')"></div>
				<div class="details">
					<h3><?php
						$name_display=get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
						echo (trim($name_display)!=""? $name_display :  $current_user->display_name );
						$post_type='iv_review';
						$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type ='%s'  and post_author='%s' ORDER BY ID DESC",$post_type ,$user_id);
						$total_review_point=0;	$avg_review=0;
						$listing_author_link=get_option('listing_author_link');
						if($listing_author_link==""){$listing_author_link='author';}
						$author_reviews = $wpdb->get_results($sql);
						$total_reviews=count($author_reviews);
						if(is_array($total_reviews)){
							$total_review_point=0;
							$one_review_total=0;
							$two_review_total=0;
							$three_review_total=0;
							$four_review_total=0;
							$five_review_total=0;
							foreach ( $author_reviews as $review )
							{
								$review_val=(int)get_post_meta($review->ID,'review_value',true);
								$total_review_point=$total_review_point+ $review_val;
								if($review_val=='1'){
									$one_review_total=$one_review_total+1;
								}
								if($review_val=='2'){
									$two_review_total=$two_review_total+1;
								}
								if($review_val=='3'){
									$three_review_total=$three_review_total+1;
								}
								if($review_val=='4'){
									$four_review_total=$four_review_total+1;
								}
								if($review_val=='5'){
									$five_review_total=$five_review_total+1;
								}
							}
							$avg_review=0;
							if($total_review_point>0){
								$avg_review= $total_review_point/$total_reviews;
							}
						}
					?>
					</h3>
					<p>
						<i class="fa fa-star <?php echo ($avg_review>0?'white-star': 'black-star');?>"></i>
						<i class="fa fa-star <?php echo ($avg_review>=2?'white-star': 'black-star');?>"></i>
						<i class="fa fa-star <?php echo ($avg_review>=3?'white-star': 'black-star');?>"></i>
						<i class="fa fa-star <?php echo ($avg_review>=4?'white-star': 'black-star');?>"></i>
						<i class="fa fa-star <?php echo ($avg_review>=5?'white-star': 'black-star');?>"></i>
					</p>
					<a href="<?php echo esc_url($profile_link);?>" class="btn-new btn-custom"><?php  esc_html_e('View profile', 'finaluser'); ?></a>
				</div>
			</div>
		</div>
		<div class="menu-click-button col-md-12">
			<a href="#"><i class="fa fa-bars"></i></a>
		</div>
		<div class="col-md-3  sidebar-area" >
			<div class="profile-sidebar">
				<div class="acc-category row">
					<?php
						$active_tab=get_option('_myaccount_active_tab');
						$active='setting';
						if(isset($_GET['profile'])){
							$profile=$_GET['profile'];
							$active=$_GET['profile'];
							}else{
							$profile=$active_tab;
							$active=$active_tab;
						}
						include(  finaluser_template. 'private-profile/menu.php');
						
					?>
				</div>
			</div>
		</div>
		<?php ?>
		<div class="col-md-9 bgclr">
			<div class="">
				<div class="acc-right">
					<?php
						$file_include='profile-setting-1.php';
						switch ($profile) {
							case "level":
							$file_include='profile-level-1.php';
							break;
							case "setting":
							$file_include='profile-setting-1.php';
							break;
							case "password":
							$file_include='password_setting.php';
							break;
							case "images":
							$file_include='images.php';
							break;
							case "activity":
							$file_include='activity.php';
							break;
							case "notification":
							$file_include='notification.php';
							break;
							case "message":
							$file_include='message.php';
							break;
							case "compose":
							$file_include='compose.php';
							break;
							case "inbox":
							$file_include='message.php';
							break;
							case "detail-message":
							$file_include='message_detail.php';
							break;
							case "sent":
							$file_include='sent.php';
							break;
							case "billing":
							$file_include='woo-billing-address.php';
							break;
							case "shipping":
							$file_include='woo-shiping-address.php';
							break;
							case "order":
							$file_include='woo-order.php';
							break;
							case "order-detail":
							$file_include='order_detail.php';
							break;
							case "subscriptions":
							$file_include='woo-subscriptions.php';
							break;
							case "downloads":
							$file_include='woo-downloads.php';
							break;
							case "video":
							$file_include='video.php';
							break;							
							case "posts":
							$file_include='post-all.php';
							break;
							case "all-posts":
							$file_include='post-all.php';
							break;
							case "edit-post":
							$file_include='post-edit.php';
							break;
							case "new-post":
							$file_include='post-new.php';
							break;
							case "doc":
							$file_include='docs.php';
							break;
							case "facebook":
							$file_include='facebook-feed-admin.php';
							break;
							default:
							$file_include='profile-setting-1.php';
						
							if($profile=='mpage'){
								$default_fields=get_option('ep_finaluser_profile_menu' );
								$menu_page_id=(isset($_GET['pid'])?$_GET['pid']:'');
								$file_include='page_content.php';
							}
						}
						include(  finaluser_template. 'private-profile/'.$file_include);
					?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	$currencyCode= get_option('_ep_finaluser_api_currency');
	wp_enqueue_script('finaluser-private-profile-js', finaluser_URLPATH.'admin/files/js/private-profile.js', array('jquery'), $ver = true, true );
	wp_localize_script('finaluser-private-profile-js', 'ep_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'pdf_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/pdf.png">',	
	'right_image'	=> '<img src="'.finaluser_URLPATH.'admin/files/images/right_icon.png">',	
	'wrong_image'	=> '<img src="'.finaluser_URLPATH.'admin/files/images/wrong_16x16.png">',	
	'current_user_id'	=>get_current_user_id(),
	'postuser'	=>  $user_id,
	'currencyCode'=> $currencyCode,
	'cancel_message' => esc_html__( 'Are you sure to cancel this Membership?','finaluser'),
	'Profile_Image'		=> esc_html__( 'Set Image','finaluser'),
	'Backgroung_Image'		=> esc_html__( 'Backgroung Image','finaluser'),
	'finalwpnonce'=>  wp_create_nonce("settings"),
	'signup'=>  wp_create_nonce("signup"),
	) );
?>
