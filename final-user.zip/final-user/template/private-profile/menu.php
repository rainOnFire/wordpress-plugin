<div id='cssmenu'>
	<div>
		<?php
			$account_menu_text=esc_html__( 'YOUR DETAILS','finaluser');
			if( get_option( '_ep_finaluser_menutop_title' ) ) {
				$account_menu_text= get_option('_ep_finaluser_menutop_title');
			}
		?>
	 	<h3 class="title"><?php echo esc_html($account_menu_text);?> </h3>
	</div>
	<ul>
		<?php
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_menuhome' ) ) {
				$account_menu_check= get_option('_ep_finaluser_menuhome');
			}
			$account_menu_text=esc_html__( 'Home','finaluser');
			if( get_option( '_ep_finaluser_menuhome_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_menuhome_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='level'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>">
				<i class="fa fa-fw fa-home"></i><span> <?php echo esc_html($account_menu_text);  ?> </span></a>
			</li>
            <?php
			}
		?>
		<?php
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_mylevel' ) ) {
				$account_menu_check= get_option('_ep_finaluser_mylevel');
			}
			$account_menu_text=esc_html__( 'Upgrade My Account','finaluser');
			if( get_option( '_ep_finaluser_mylevel_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_mylevel_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='level'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=level">
				<i class="fa fa-user member"></i><span> <?php echo esc_html($account_menu_text);  ?> </span></a>
			</li>
            <?php
			}
		?>
		<?php
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_menusetting' ) ) {
				$account_menu_check= get_option('_ep_finaluser_menusetting');
			}
			$account_menu_text=esc_html__( 'My Profile','finaluser');
			if( get_option( '_ep_finaluser_menusetting_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_menusetting_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='setting'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=setting">
				<i class="fa fa-cog setting"></i><span> <?php echo esc_html($account_menu_text);  ?> </span></a>
			</li>
            <?php
			}
		?>
		<?php
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_menumyposts' ) ) {
				$account_menu_check= get_option('_ep_finaluser_menumyposts');
			}
			$account_menu_text=esc_html__( 'My Posts','finaluser');
			if( get_option( '_ep_finaluser_menumyposts_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_menumyposts_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php if ($active=='posts'  OR $active=='edit-post' OR $active=='new-post'){ echo'active';} ?> has-sub">
				<a href="<?php echo get_permalink(); ?>?&profile=posts">
					<i class="fa fa-files-o"></i><span>
					<?php  echo esc_html($account_menu_text); ?>  </span></a>
					<ul>
						<?php
							$account_menu_check2= '';
							if( get_option( '_ep_finaluser_menunewpost' ) ) {
								$account_menu_check2= get_option('_ep_finaluser_menumyposts');
							}
							$account_menu_text=esc_html__( 'Add New Post','finaluser');
							if( get_option( '_ep_finaluser_menunewpost_text' ) ) {
								$account_menu_text= get_option('_ep_finaluser_menunewpost_text');
							}
							if($account_menu_check2!='yes'){
							?>
							<li class="<?php if($active=='new-post'){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=new-post">
							<?php echo esc_html($account_menu_text);  ?> </a>
							</li>
							<?php
							}
						?>
						<?php
							$account_menu_check2= '';
							if( get_option( '_ep_finaluser_menuallposts' ) ) {
								$account_menu_check2= get_option('_ep_finaluser_menuallposts');
							}
							$account_menu_text=esc_html__( 'All Posts','finaluser');
							if( get_option( '_ep_finaluser_menuallposts_text' ) ) {
								$account_menu_text= get_option('_ep_finaluser_menuallposts_text');
							}
							if($account_menu_check2!='yes'){
							?>
							<li class="<?php if($active=='all-posts' OR $active=='edit-post'){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=all-posts">
							<?php echo esc_html($account_menu_text);  ?> </a>
							</li>
							<?php
							}
						?>
					</ul>
			</li>
            <?php
			}
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_images' ) ) {
				$account_menu_check= get_option('_ep_finaluser_images');
			}
			$account_menu_text=esc_html__( 'My Photos','finaluser');
			if( get_option( '_ep_finaluser_images_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_images_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='images'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=images">
				<i class="fa fa-image image"></i><span> <?php echo esc_html($account_menu_text);?> </span></a>
			</li>
            <?php
			}
            $account_menu_check= '';
			if( get_option( '_ep_finaluser_videos' ) ) {
				$account_menu_check= get_option('_ep_finaluser_videos');
			}
			$account_menu_text=esc_html__( 'My Videos','finaluser');
			if( get_option( '_ep_finaluser_videos_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_videos_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='video'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=video">
				<i class="fa fa-play"></i><span> <?php echo esc_html($account_menu_text);?>  </span></a>
			</li>
            <?php
			}
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_doc' ) ) {
				$account_menu_check= get_option('_ep_finaluser_doc');
			}
			$account_menu_text=esc_html__( 'My Docs','finaluser');
			if( get_option( '_ep_finaluser_doc_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_doc_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='doc'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=doc">
				<i class="fa fa-file"></i><span> <?php echo esc_html($account_menu_text);?>  </span></a>
			</li>
            <?php
			}
			if(function_exists('bp_is_active')){
				if( bp_is_active('activity') ){
					$account_menu_check= '';
					if( get_option( '_ep_finaluser_activity' ) ) {
						$account_menu_check= get_option('_ep_finaluser_activity');
					}
					$account_menu_text=esc_html__( 'Activity','finaluser');
					if( get_option( '_ep_finaluser_activity_text' ) ) {
						$account_menu_text= get_option('_ep_finaluser_activity_text');
					}
					if($account_menu_check!='yes'){
					?>
					<li class="<?php echo ($active=='activity'? 'active':''); ?> ">
						<a href="<?php echo get_permalink(); ?>?&profile=activity">
						<i class="fa fa-list file"></i><span> <?php echo esc_html($account_menu_text);?></span></a>
					</li>
					<?php
					}
				}
				$account_menu_check= '';
				if( get_option( '_ep_finaluser_notification' ) ) {
					$account_menu_check= get_option('_ep_finaluser_notification');
				}
				$account_menu_text=esc_html__( 'Notification','finaluser');
				if( get_option( '_ep_finaluser_notification_text' ) ) {
					$account_menu_text= get_option('_ep_finaluser_notification_text');
				}
				if($account_menu_check!='yes'){
				?>
				<li class="<?php echo ($active=='notification'? 'active':''); ?> ">
					<a href="<?php echo get_permalink(); ?>?&profile=notification">
					<i class="fa fa-bell bell"></i><span> <?php echo esc_html($account_menu_text);?> </span></a>
				</li>
				<?php
				}
				//****Check Active boddyPress message*****************
				if( bp_is_active( 'messages' )){
					$account_menu_check= '';
					if( get_option( '_ep_finaluser_inbox' ) ) {
						$account_menu_check= get_option('_ep_finaluser_inbox');
					}
					$account_menu_text=esc_html__( 'Inbox','finaluser');
					if( get_option( '_ep_finaluser_inbox_text' ) ) {
						$account_menu_text= get_option('_ep_finaluser_inbox_text');
					}
					if($account_menu_check!='yes'){
					?>
					<li class="<?php echo ($active=='message'? 'active':''); ?> has-sub">
						<a href="<?php echo get_permalink(); ?>?&profile=inbox">
							<i class="fa fa-envelope bell"></i><span>
								<?php global $bp;
									$total_message=0;
									if ( function_exists( 'messages_get_unread_count' ) ) {
										$total_message= messages_get_unread_count();
									}
								echo esc_html($account_menu_text); echo($total_message>0?"(".$total_message.")":'' ); ?>  </span></a>
								<ul>
									<?php
										$account_menu_check2= '';
										if( get_option( '_ep_finaluser_inbox2' ) ) {
											$account_menu_check2= get_option('_ep_finaluser_inbox2');
										}
										$account_menu_text2=esc_html__( 'Inbox','finaluser');
										if( get_option( '_ep_finaluser_inbox2_text' ) ) {
											$account_menu_text2= get_option('_ep_finaluser_inbox2_text');
										}
										if($account_menu_check2!='yes'){ ?>
										<li class="<?php if($active=='inbox' OR $active=='detail-message'){echo'active';} ?> ">  <a href="<?php echo get_permalink(); ?>?&profile=inbox"><?php echo esc_html($account_menu_text2);?> </a>
										</li>
										<?php
										}
									?>
									<?php
										$account_menu_check2= '';
										if( get_option( '_ep_finaluser_compose' ) ) {
											$account_menu_check2= get_option('_ep_finaluser_compose');
										}
										$account_menu_text2=esc_html__( 'Compose','finaluser');
										if( get_option( '_ep_finaluser_compose_text' ) ) {
											$account_menu_text2= get_option('_ep_finaluser_compose_text');
										}
										if($account_menu_check2!='yes'){ ?>
										<li class="<?php echo ($active=='compose'? 'active':''); ?> "> <a href="<?php echo get_permalink(); ?>?&profile=compose"><?php echo esc_html($account_menu_text2);?> </a>
										</li>
										<?php
										}
									?>
									<?php
										$account_menu_check2= '';
										if( get_option( '_ep_finaluser_sent' ) ) {
											$account_menu_check2= get_option('_ep_finaluser_sent');
										}
										$account_menu_text2=esc_html__( 'Sent','finaluser');
										if( get_option( '_ep_finaluser_sent_text' ) ) {
											$account_menu_text2= get_option('_ep_finaluser_sent_text');
										}
										if($account_menu_check2!='yes'){ ?>
										<li class="<?php echo ($active=='sent'? 'active':''); ?>  last">  <a href="<?php echo get_permalink(); ?>?&profile=sent"><?php echo esc_html($account_menu_text2);?> </a>
										</li>
										<?php
										}
									?>
								</ul>
					</li>
					<?php
					}
				?>
				<?php
				}
			}// check buddy press
			if ( class_exists( 'WooCommerce' ) ) {
				$account_menu_check= '';
				if( get_option( '_ep_finaluser_woocommerce' ) ) {
					$account_menu_check= get_option('_ep_finaluser_woocommerce');
				}
				$account_menu_text=esc_html__( 'Woocommerce','finaluser');
				if( get_option( '_ep_finaluser_woocommerce_text' ) ) {
					$account_menu_text= get_option('_ep_finaluser_woocommerce_text');
				}
				if($account_menu_check!='yes'){
				?>
				<li class="<?php echo ($active=='order'? 'active':''); ?> has-sub">
					<a href="<?php echo get_permalink(); ?>?&profile=inbox">
						<i class="fa fa-shopping-cart"></i><span>
						<?php echo esc_html($account_menu_text);?> </span></a>
						<ul>
							<?php
								$account_menu_check2= '';
								if( get_option( '_ep_finaluser_woocommerce' ) ) {
									$account_menu_check2= get_option('_ep_finaluser_woocommerce');
								}
								$account_menu_text2=esc_html__( 'My Orders','finaluser');
								if( get_option( '_ep_finaluser_order_text' ) ) {
									$account_menu_text2= get_option('_ep_finaluser_order_text');
								}
								if($account_menu_check2!='yes'){
								?>
								<li class="<?php if($active=='order' OR $active=='order'){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=order">
								<?php echo esc_html($account_menu_text2);?>  </a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check2= '';
								if( get_option( '_ep_finaluser_subscriptions' ) ) {
									$account_menu_check2= get_option('_ep_finaluser_subscriptions');
								}
								$account_menu_text2=esc_html__( 'Subscriptions','finaluser');
								if( get_option( '_ep_finaluser_subscriptions_text' ) ) {
									$account_menu_text2= get_option('_ep_finaluser_subscriptions_text');
								}
								if($account_menu_check2!='yes'){
									if(class_exists('WC_Subscriptions')){
									?>
									<li class="<?php if($active=='subscriptions' ){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=subscriptions">
									<?php echo esc_html($account_menu_text2);?>  </a>
									</li>
									<?php
									}
								}
							?>
							<?php
								$account_menu_check2= '';
								if( get_option( '_ep_finaluser_downloads' ) ) {
									$account_menu_check2= get_option('_ep_finaluser_downloads');
								}
								$account_menu_text2=esc_html__( 'Downloads','finaluser');
								if( get_option( '_ep_finaluser_downloads_text' ) ) {
									$account_menu_text2= get_option('_ep_finaluser_downloads_text');
								}
								if($account_menu_check2!='yes'){
								?>
								<li class="<?php if($active=='downloads' ){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=downloads">
								<?php echo esc_html($account_menu_text2);?>  </a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check2= '';
								if( get_option( '_ep_finaluser_billing' ) ) {
									$account_menu_check2= get_option('_ep_finaluser_billing');
								}
								$account_menu_text2=esc_html__( 'Billing Address','finaluser');
								if( get_option( '_ep_finaluser_billing_text' ) ) {
									$account_menu_text2= get_option('_ep_finaluser_billing_text');
								}
								if($account_menu_check2!='yes'){
								?>
								<li class="<?php if($active=='billing' ){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=billing">
								<?php echo esc_html($account_menu_text2);?>  </a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check2= '';
								if( get_option( '_ep_finaluser_shipping' ) ) {
									$account_menu_check2= get_option('_ep_finaluser_shipping');
								}
								$account_menu_text2=esc_html__( 'Shipping Address','finaluser');
								if( get_option( '_ep_finaluser_shipping_text' ) ) {
									$account_menu_text2= get_option('_ep_finaluser_shipping_text');
								}
								if($account_menu_check2!='yes'){
								?>
								<li class="<?php if($active=='shipping' ){echo'active';} ?> "> <a href="<?php echo get_permalink(); ?>?&profile=shipping">
								<?php echo esc_html($account_menu_text2);?>  </a>
								</li>
								<?php
								}
							?>
						</ul>
				</li>
				<?php
				}
			}
			$account_menu_text=esc_html__( 'Facebook','finaluser');
			if( get_option( '_ep_finaluser_facebook_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_facebook_text');
			}
		?>
		<li class="<?php echo ($active=='facebook'? 'active':''); ?> ">
            <a href="<?php echo get_permalink(); ?>?&profile=facebook">
				<i class="fa fa-user"></i><span> <?php echo esc_html($account_menu_text);?>  </span>
			</a>
		</li>
		<?php
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_password' ) ) {
				$account_menu_check= get_option('_ep_finaluser_password');
			}
			$account_menu_text=esc_html__( 'Password','finaluser');
			if( get_option( '_ep_finaluser_password_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_password_text');
			}
			if($account_menu_check!='yes'){
			?>
			<li class="<?php echo ($active=='password'? 'active':''); ?> ">
				<a href="<?php echo get_permalink(); ?>?&profile=password">
					<i class="fa fa-key"></i><span> <?php echo esc_html($account_menu_text);?>   </span>
				</a>
			</li>
            <?php
			}
			$account_menu_check= '';
			if( get_option( '_ep_finaluser_profile' ) ) {
				$account_menu_check= get_option('_ep_finaluser_profile');
			}
			$account_menu_text=esc_html__( 'Public Profile','finaluser');
			if( get_option( '_ep_finaluser_profile_text' ) ) {
				$account_menu_text= get_option('_ep_finaluser_profile_text');
			}
			if($account_menu_check!='yes'){
				$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
      	 		$reg_page_user='';
      	 		if($iv_redirect_user!='defult'){
      	 			$reg_page_user= get_permalink( $iv_redirect_user) ;
				}
      	 		$reg_page_u=$reg_page_user.'?&id='.$user_id; 
			?>
			<li class="<?php echo ($active=='pub_profile'? 'active':''); ?> ">
				<a href="<?php echo esc_url($profile_link); ?>">
					<i class="fa fa-user"></i><span> <?php echo esc_html($account_menu_text);?>  </span>
				</a>
			</li>
            <?php
			}
		?>
		<?php     $old_custom_menu = array();
			if(get_option('ep_finaluser_profile_menu')){
				$old_custom_menu=get_option('ep_finaluser_profile_menu' );
			} 
			$ii=1;
			if($old_custom_menu!=''){
				foreach ( $old_custom_menu as $field_key => $field_value ) { ?>
				<li class="<?php echo ($active==$field_key? 'active':''); ?> ">
					<a href="<?php echo get_permalink(); ?>?&profile=mpage&pid=<?php echo esc_html($field_value).'&header='.esc_html($field_key) ; ?>">
						<i class="fa fa-cog"></i>
					<?php echo esc_html($field_key);?> </a>
				</li>
				<?php
				}
			}      ?>
			<?php
				$account_menu_check= '';
				if( get_option( '_ep_finaluser_signout' ) ) {
					$account_menu_check= get_option('_ep_finaluser_signout');
				}
				$account_menu_text=esc_html__( 'Sign Out','finaluser');
				if( get_option( '_ep_finaluser_signout_text' ) ) {
					$account_menu_text= get_option('_ep_finaluser_signout_text');
				}
				if($account_menu_check!='yes'){
				?>
				<li class="<?php echo ($active=='signout'? 'active':''); ?> last">
					<a href="<?php echo wp_logout_url( home_url() ); ?>" >
						<i class="fa fa-sign-out"></i><span> <?php echo esc_html($account_menu_text);?>   </span>
					</a>
				</li>
				<?php
				}
			?>
	</ul>
</div>