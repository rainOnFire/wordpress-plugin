<form role="form" name="profile_image_gallery" id="profile_image_gallery" action="#">
	<div class="profile-content">
		<div class="row">
			<div class="col-md-12">
				<h3><?php echo esc_html_e('My Photos', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class="margiv-top-10 ">
						<?php
							$package_id=get_user_meta($current_user->ID, 'ep_finaluser_package_id',true);
							$image_limit= get_post_meta($package_id, 'ep_finaluser_image_limit', true);
							$user_role= $current_user->roles[0];
							if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
								$image_limit=999999;
							}
							$gallery_ids=get_user_meta($current_user->ID ,'image_gallery_ids',true);
							$gallery_ids_array = array_filter(explode(",", $gallery_ids));
						?>
						<input type="hidden" name="gallery_image_ids" id="gallery_image_ids" value="<?php echo esc_html($gallery_ids); ?>">
						<div class="" id="gallery_image_div">
							<?php
								if(sizeof($gallery_ids_array)>0){
									foreach($gallery_ids_array as $slide){
									?>
									<div id="gallery_image_div<?php echo esc_html($slide);?>" class="col-md-3"><img  class="img-responsive"  src="<?php echo wp_get_attachment_url( $slide ); ?>"><button type="button" onclick="remove_gallery_image('gallery_image_div<?php echo esc_html($slide);?>', <?php echo esc_html($slide);?>);"  class="btn btn-xs btn-danger"><?php esc_html_e('X','finaluser'); ?></button> </div>
									<?php
									}
								}
							?>
						</div>
						<div class="clearfix"><p></p></div>
						<?php
							if(sizeof($gallery_ids_array)<$image_limit){
							?>
							<div class="docmargin">
								<button type="button" onclick="edit_gallery_image('gallery_image_div');"  class="btn btn-sm tirtiary"><?php esc_html_e('Add Images','finaluser'); ?></button>
							</div>
						</div>
						<div class="docmargin2" >
							<?php esc_html_e('Image Upload Limit: ','finaluser'); ?> <?php echo esc_html($image_limit);?> [ <?php esc_html_e('First ','finaluser'); ?> <?php echo esc_html($image_limit);?> <?php esc_html_e('photo(s) will publish ','finaluser'); ?> ]
						</div>
						<div class="margiv-top-10"  >
							<div class="margiv-top-10 save-change-button-content text-right" >
								<div class="" id="update_message_gallery"></div>
								<button type="button" onclick="update_gallery_images();"  class="btn-new btn-custom"><?php  esc_html_e('Save images','finaluser');?></button>
							</div>
						</div>
						<?php
						}else{ ?>
						<div class="docmargin2" >
							<?php esc_html_e('Image Upload Limit: ','finaluser'); ?> <?php echo esc_html($image_limit);?> [ <?php esc_html_e('First ','finaluser'); ?> <?php echo esc_html($image_limit);?> <?php esc_html_e('photo(s) will publish ','finaluser'); ?> ]
						</div>
						<?php
						}
					?>
				</div>
			</div>
		</div>
	</div>
</form>