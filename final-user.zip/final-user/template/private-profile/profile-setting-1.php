<form role="form" name="profile_setting_form" id="profile_setting_form" action="#" class="">
	<div class="profile-content">
		<div class="row">
			<div class="col-md-6">
				<h3><?php echo esc_html_e('INFORMATION', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class="margiv-top-10 ">
						<?php
							$default_fields = array();
							$field_set=get_option('ep_finaluser_profile_fields' );
							if($field_set!=""){
								$default_fields=get_option('ep_finaluser_profile_fields' );
								}else{
								$default_fields['first_name']='First Name';
								$default_fields['last_name']='Last Name';
								$default_fields['phone']='Phone Number';
								$default_fields['mobile']='Mobile Number';
								$default_fields['web_site']='Website Url';
							}
							$i=1;
							foreach ( $default_fields as $field_key => $field_value ) { ?>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e($field_value, 'finaluser'); ?></label>
								<input type="text" placeholder="<?php  esc_html_e('Enter ', 'finaluser'); ?><?php echo esc_html($field_value);?>" name="<?php echo esc_html($field_key);?>" id="<?php echo esc_html($field_key);?>"  class="form-control-solid" value="<?php echo get_user_meta($current_user->ID,$field_key,true); ?>"/>
							</div>
							<?php
							}
						?>
						<div class="form-group">
							<label class="control-label"><?php echo esc_html_e('Availabilities', 'finaluser'); ?></label>
							<input type="text" name="weekday" id="weekday" value="<?php echo get_user_meta($current_user->ID,'weekday',true); ?>" placeholder="<?php  esc_html_e('Open : 9Am - 10PM', 'finaluser'); ?>" class="form-control-solid"/>
							<input type="text" name="weekend" id="weekend" value="<?php echo get_user_meta($current_user->ID,'weekend',true); ?>" placeholder="<?php  esc_html_e('Close: Sunday', 'finaluser'); ?>" class="form-control-solid"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php echo esc_html_e('Service Rates', 'finaluser'); ?></label>
							<label class="form-check-label">
								<input name="available" id="available" class="form-check-input" type="checkbox" value="no" <?php echo (get_user_meta($current_user->ID,'available',true)=='no'?'checked':'' ); ?>>
								<?php  esc_html_e("I'm not Available for Hire", 'finaluser'); ?>
							</label>
							<input type="text" name="rate_hourly" id="rate_hourly" value="<?php echo get_user_meta($current_user->ID,'rate_hourly',true); ?>" placeholder="<?php echo esc_html_e('Hourly Rate', 'finaluser'); ?>" class="form-control-solid"/>
							<input type="text" name="daily_rate" id="daily_rate" value="<?php echo get_user_meta($current_user->ID,'daily_rate',true); ?>" placeholder="<?php echo esc_html_e('Daily Rate', 'finaluser'); ?>" class="form-control-solid"/>
						</div>
					</div>
				</div>
				<h3><?php echo esc_html_e('SOCIAL MEDIA', 'finaluser'); ?></h3>
				<div class="photo-setting-single " >
					<div class="arrow"></div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('FaceBook', 'finaluser'); ?></label>
								<input type="text" name="facebook" id="facebook" value="<?php echo get_user_meta($current_user->ID,'facebookp',true); ?>" class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Linkedin', 'finaluser'); ?></label>
								<input type="text" name="linkedin" id="linkedin" value="<?php echo get_user_meta($current_user->ID,'linkedinp',true); ?>" class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Twitter', 'finaluser'); ?></label>
								<input type="text" name="twitter" id="twitter" value="<?php echo get_user_meta($current_user->ID,'twitterp',true); ?>" class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Google+', 'finaluser'); ?> </label>
								<input type="text" name="gplus" id="gplus" value="<?php echo get_user_meta($current_user->ID,'gplusp',true); ?>"  class="form-control-solid"/>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Pinterest', 'finaluser'); ?> </label>
								<input type="text" name="pinterest" id="pinterest" value="<?php echo get_user_meta($current_user->ID,'pinterestp',true); ?>"  class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Instagram', 'finaluser'); ?> </label>
								<input type="text" name="instagram" id="instagram" value="<?php echo get_user_meta($current_user->ID,'instagramp',true); ?>"  class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('Vimeo', 'finaluser'); ?> </label>
								<input type="text" name="vimeo" id="vimeo" value="<?php echo get_user_meta($current_user->ID,'vimeop',true); ?>"  class="form-control-solid"/>
							</div>
							<div class="form-group">
								<label class="control-label"><?php echo esc_html_e('YouTube', 'finaluser'); ?> </label>
								<input type="text" name="youtube" id="youtube" value="<?php echo get_user_meta($current_user->ID,'youtubep',true); ?>"  class="form-control-solid"/>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<h3><?php echo esc_html_e('ABOUT YOU', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class="row">
						<?php  include('image_uploader.php');?>
					</div>
					<div class="form-group mt30">
						<label class="control-label"><?php echo esc_html_e('Title', 'finaluser'); ?></label>
						<input type="text" name="profile_title" id="profile_title" value="<?php echo get_user_meta($current_user->ID,'profile_title',true); ?>" placeholder="<?php echo esc_html_e('Title', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="form-group mt30">
						<label class="control-label"><?php echo esc_html_e('About you', 'finaluser'); ?></label>
						<textarea name="about" id="about" class="form-control-solid" ><?php echo get_user_meta($current_user->ID,'description',true); ?></textarea>
					</div>
					<div class="form-group">
						<label class="control-label"><?php echo esc_html_e('Specialties', 'finaluser'); ?></label>
						<select name="specialties[]" id="specialties" multiple class="form-group">
							<?php
								$Specialities =esc_html__( 'Aerial, Architecture,Automotive, Event, Fashion,Food,Interior, Lifestye, Maternity, Newborns, Nature, Land','finaluser');
								$field_set=get_option('_dir_specialties' );
								if($field_set!=""){
									$Specialities=get_option('_dir_specialties' );
								}
								$i=1;
								$specialties_user_data= get_user_meta($current_user->ID,'specialties',true);
								$specialties_user_data=explode(',', $specialties_user_data);
								$Specialities_fields= explode(",",$Specialities);
								foreach ( $Specialities_fields as $field_value ) { ?>
								<option value="<?php echo esc_html($field_value); ?>" <?php echo(in_array($field_value,$specialties_user_data)? ' selected':'');?> ><?php echo esc_html($field_value); ?></option>
								<?php
								}
							?>
						</select>
					</div>
					<div class="form-group">
						<label class="control-label"><?php echo esc_html_e('Gender', 'finaluser'); ?></label>
						<div class="radio-group-gender">
							<label class="radio">
								<input type="radio" name="gender" id="gender" value="Male" <?php echo (get_user_meta($user_id,'gender',true)=='Male'? 'checked="checked"':'' ); ?>> <?php echo esc_html_e('Male', 'finaluser'); ?>
							</label>
							<label class="radio">
								<input type="radio" name="gender" id="gender" value="Female" <?php echo (get_user_meta($user_id,'gender',true)=='Female'? 'checked="checked"':'' ); ?>> <?php echo esc_html_e('Female', 'finaluser'); ?>
							</label>
							<label class="radio">
								<input type="radio" name="gender" id="gender" value="Not specified" <?php echo (get_user_meta($user_id,'gender',true)=='Not specified'? 'checked="checked"':'' ); ?>> <?php echo esc_html_e('Not specified', 'finaluser'); ?>
							</label>
						</div>
					</div>
					<div class="form-group small-margin">
						<label class="control-label"><?php echo esc_html_e('Service Type', 'finaluser'); ?></label>
						<input type="text" name="service_type" id="service_type" value="<?php echo get_user_meta($current_user->ID,'service_type',true); ?>" placeholder="<?php echo esc_html_e('Photography', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="form-group small-margin">
						<label class="control-label"><?php echo esc_html_e('Location', 'finaluser'); ?></label>
						<input type="text" name="address" id="address" value="<?php echo get_user_meta($current_user->ID,'address',true); ?>" placeholder="<?php echo esc_html_e('Address', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="form-group small-margin">
						<input type="text" name="city" id="city" value="<?php echo get_user_meta($current_user->ID,'city',true); ?>" placeholder="<?php echo esc_html_e('City', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="form-group small-margin">
						<input type="text" name="state" id="state" value="<?php echo get_user_meta($current_user->ID,'state',true); ?>" placeholder="<?php echo esc_html_e('State', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="form-group small-margin">
						<input type="text" name="country" id="country" value="<?php echo get_user_meta($current_user->ID,'country',true); ?>" placeholder="<?php echo esc_html_e('Country', 'finaluser'); ?>" class="form-control-solid"/>
					</div>
					<div class="mt30">
						<div class="row">
							<div class="col-md-4">
								<button type="button" onclick="addGear('misc');"  class="btn btn-sm tirtiary"><?php  esc_html_e('Add Expertise','finaluser');?></button>
							</div>
						</div>
					</div>
					<?php
						for($i=0;$i<20;$i++){
							if(get_user_meta($user_id,'camera'.$i,true)!=''){?>
							<div id="camera<?php echo esc_html($i);?>" >
								<div class="row"><div class="col-sm-2"><i class="flaticon-technology-1" aria-hidden="true"></i></div><div class="col-sm-8"><?php echo get_user_meta($user_id,'camera'.$i,true);?></div> <div class="col-sm-2"><button type="button" onclick="remove_camera('camera<?php echo esc_html($i);?>');"  class="btn btn-xs btn-danger ">X</button></div></div>
								<input type="hidden" name="camera[]" value="<?php echo get_user_meta($user_id,'camera'.$i,true);?>">
							</div>
							<?php
							}
							if(get_user_meta($user_id,'lens'.$i,true)!=''){?>
							<div id="lens<?php echo esc_html($i);?>" >
								<div class="row"><div class="col-sm-2"><i class="flaticon-technology" aria-hidden="true"></i></div><div class="col-sm-8"><?php echo get_user_meta($user_id,'lens'.$i,true);?></div> <div class="col-sm-2"><button type="button" onclick="remove_camera('lens<?php echo esc_html($i);?>');"  class="btn btn-xs btn-danger ">X</button></div></div>
								<input type="hidden" name="lens[]" value="<?php echo get_user_meta($user_id,'lens'.$i,true);?>">
							</div>
							<?php
							}
							if(get_user_meta($user_id,'misc'.$i,true)!=''){?>
							<div id="misc<?php echo esc_html($i);?>" >
								<div class="row"><div class="col-sm-2"><i class="flaticon-electricity" aria-hidden="true"></i></div><div class="col-sm-8"><?php echo get_user_meta($user_id,'misc'.$i,true);?></div> <div class="col-sm-2"><button type="button" onclick="remove_camera('misc<?php echo esc_html($i);?>');"  class="btn btn-xs btn-danger ">X</button></div></div>
								<input type="hidden" name="misc[]" value="<?php echo get_user_meta($user_id,'misc'.$i,true);?>">
							</div>
							<?php
							}
						}
					?>
					<div id="gears">
					</div>
				</div>
				<h3><?php echo esc_html_e('EXPERIENCE & OTHERS', 'finaluser'); ?></h3>
				<div class="photo-setting-single">
					<div class="arrow"></div>
					<div class=" margin-right15">
						<?php
							for($i=0;$i<20;$i++){
								if(get_user_meta($user_id,'language'.$i,true)!=''){?>
								<div id="language<?php echo esc_html($i);?>">
									<div class="col-sm-6"><?php echo get_user_meta($user_id,'language'.$i,true);?> </div> <div class="col-sm-4"><?php echo get_user_meta($user_id,'language_status'.$i,true);?></div><div class="col-sm-2"><button type="button" onclick="remove_language('language<?php echo esc_html($i);?>');"  class="btn btn-xs btn-danger ">X</button></div>
									<input type="hidden" name="languages[]" value="<?php echo get_user_meta($user_id,'language'.$i,true);?>">
									<input type="hidden" name="language_level[]" value="<?php echo get_user_meta($user_id,'language_status'.$i,true);?>">
								</div>
								<?php
								}
							}
						?>
					</div>
					<div class=" margin-right15" id="language_one">
						<div class="form-group">
							<div class="col-sm-6"><label><?php echo esc_html_e('Language', 'finaluser'); ?></label>
								<select id="languages[]" name="languages[]" data-placeholder="Choose a Language..." class="form-control-solid ">
									<option value=""><?php echo esc_html_e('Choose a Language...', 'finaluser'); ?></option>
									<option value="Afrikanns">
										<?php esc_html_e('Afrikanns','finaluser'); ?>
									</option>
									<option value="Albanian">
										<?php esc_html_e('Albanian','finaluser'); ?>
									</option>
									<option value="Arabic">
										<?php esc_html_e('Arabic','finaluser'); ?>
									</option>
									<option value="Armenian">
										<?php esc_html_e('Armenian','finaluser'); ?>
									</option>
									<option value="Basque">
										<?php esc_html_e('Basque','finaluser'); ?>
									</option>
									<option value="Bengali">
										<?php esc_html_e('Bengali','finaluser'); ?>
									</option>
									<option value="Bulgarian">
										<?php esc_html_e('Bulgarian','finaluser'); ?>
									</option>
									<option value="Catalan">
										<?php esc_html_e('Catalan','finaluser'); ?>
									</option>
									<option value="Cambodian">
										<?php esc_html_e('Cambodian','finaluser'); ?>
									</option>
									<option value="Chinese (Mandarin)">
										<?php esc_html_e('Chinese (Mandarin)','finaluser'); ?>
									</option>
									<option value="Croation">
										<?php esc_html_e('Croation','finaluser'); ?>
									</option>
									<option value="Czech">
										<?php esc_html_e('Czech','finaluser'); ?>
									</option>
									<option value="Danish">
										<?php esc_html_e('Danish','finaluser'); ?>
									</option>
									<option value="Dutch">
										<?php esc_html_e('Dutch','finaluser'); ?>
									</option>
									<option value="English">
										<?php esc_html_e('English','finaluser'); ?>
									</option>
									<option value="Estonian">
										<?php esc_html_e('Estonian','finaluser'); ?>
									</option>
									<option value="Fiji">
										<?php esc_html_e('Fiji','finaluser'); ?>
									</option>
									<option value="Finnish">
										<?php esc_html_e('Finnish','finaluser'); ?>
									</option>
									<option value="French">
										<?php esc_html_e('French','finaluser'); ?>
									</option>
									<option value="Georgian">
										<?php esc_html_e('Georgian','finaluser'); ?>
									</option>
									<option value="German">
										<?php esc_html_e('German','finaluser'); ?>
									</option>
									<option value="Greek">
										<?php esc_html_e('Greek','finaluser'); ?>
									</option>
									<option value="Gujarati">
										<?php esc_html_e('Gujarati','finaluser'); ?>
									</option>
									<option value="Hebrew">
										<?php esc_html_e('Hebrew','finaluser'); ?>
									</option>
									<option value="Hindi">
										<?php esc_html_e('Hindi','finaluser'); ?>
									</option>
									<option value="Hungarian">
										<?php esc_html_e('Hungarian','finaluser'); ?>
									</option>
									<option value="Icelandic">
										<?php esc_html_e('Icelandic','finaluser'); ?>
									</option>
									<option value="Indonesian">
										<?php esc_html_e('Indonesian','finaluser'); ?>
									</option>
									<option value="Irish">
										<?php esc_html_e('Irish','finaluser'); ?>
									</option>
									<option value="Italian">
										<?php esc_html_e('Italian','finaluser'); ?>
									</option>
									<option value="Japanese">
										<?php esc_html_e('Japanese','finaluser'); ?>
									</option>
									<option value="Javanese">
										<?php esc_html_e('Javanese','finaluser'); ?>
									</option>
									<option value="Korean">
										<?php esc_html_e('Korean','finaluser'); ?>
									</option>
									<option value="Latin">
										<?php esc_html_e('Latin','finaluser'); ?>
									</option>
									<option value="Latvian">
										<?php esc_html_e('Latvian','finaluser'); ?>
									</option>
									<option value="Lithuanian">
										<?php esc_html_e('Lithuanian','finaluser'); ?>
									</option>
									<option value="Macedonian">
										<?php esc_html_e('Macedonian','finaluser'); ?>
									</option>
									<option value="Malay">
										<?php esc_html_e('Malay','finaluser'); ?>
									</option>
									<option value="Malayalam">
										<?php esc_html_e('Malayalam','finaluser'); ?>
									</option>
									<option value="Maltese">
										<?php esc_html_e('Maltese','finaluser'); ?>
									</option>
									<option value="Maori">
										<?php esc_html_e('Maori','finaluser'); ?>
									</option>
									<option value="Marathi">
										<?php esc_html_e('Marathi','finaluser'); ?>
									</option>
									<option value="Mongolian">
										<?php esc_html_e('Mongolian','finaluser'); ?>
									</option>
									<option value="Nepali">
										<?php esc_html_e('Nepali','finaluser'); ?>
									</option>
									<option value="Norwegian">
										<?php esc_html_e('Norwegian','finaluser'); ?>
									</option>
									<option value="Persian">
										<?php esc_html_e('Persian','finaluser'); ?>
									</option>
									<option value="Polish">
										<?php esc_html_e('Polish','finaluser'); ?>
									</option>
									<option value="Portuguese">
										<?php esc_html_e('Portuguese','finaluser'); ?>
									</option>
									<option value="Punjabi">
										<?php esc_html_e('Punjabi','finaluser'); ?>
									</option>
									<option value="Quechua">
										<?php esc_html_e('Quechua','finaluser'); ?>
									</option>
									<option value="Romanian">
										<?php esc_html_e('Romanian','finaluser'); ?>
									</option>
									<option value="Russian">
										<?php esc_html_e('Russian','finaluser'); ?>
									</option>
									<option value="Samoan">
										<?php esc_html_e('Samoan','finaluser'); ?>
									</option>
									<option value="Serbian">
										<?php esc_html_e('Serbian','finaluser'); ?>
									</option>
									<option value="Slovak">
										<?php esc_html_e('Slovak','finaluser'); ?>
									</option>
									<option value="Slovenian">
										<?php esc_html_e('Slovenian','finaluser'); ?>
									</option>
									<option value="Spanish">
										<?php esc_html_e('Spanish','finaluser'); ?>
									</option>
									<option value="Swahili">
										<?php esc_html_e('Swahili','finaluser'); ?>
									</option>
									<option value="Swedish ">
										<?php esc_html_e('Swedish','finaluser'); ?>
									</option>
									<option value="Tamil">
										<?php esc_html_e('Tamil','finaluser'); ?>
									</option>
									<option value="Tatar">
										<?php esc_html_e('Tatar','finaluser'); ?>
									</option>
									<option value="Telugu">
										<?php esc_html_e('Telugu','finaluser'); ?>
									</option>
									<option value="Thai">
										<?php esc_html_e('Thai','finaluser'); ?>
									</option>
									<option value="Tibetan">
										<?php esc_html_e('Tibetan','finaluser'); ?>
									</option>
									<option value="Tonga">
										<?php esc_html_e('Tonga','finaluser'); ?>
									</option>
									<option value="Turkish">
										<?php esc_html_e('Turkish','finaluser'); ?>
									</option>
									<option value="Ukranian">
										<?php esc_html_e('Ukranian','finaluser'); ?>
									</option>
									<option value="Urdu">
										<?php esc_html_e('Urdu','finaluser'); ?>
									</option>
									<option value="Uzbek">
										<?php esc_html_e('Uzbek','finaluser'); ?>
									</option>
									<option value="Vietnamese">
										<?php esc_html_e('Vietnamese','finaluser'); ?>
									</option>
									<option value="Welsh">
										<?php esc_html_e('Welsh','finaluser'); ?>
									</option>
									<option value="Xhosa">
										<?php esc_html_e('Xhosa','finaluser'); ?>
									</option>
								</select>
							</div>
							<div class="col-sm-6"><label><?php echo esc_html_e('Expertise levels', 'finaluser'); ?></label>
							<input type="text" id="language_level[]" name="language_level[]" class="form-control" placeholder="<?php echo esc_html_e('Fluent', 'finaluser'); ?>"></div>
						</div>
					</div>
					<div class=" margin-right15" id="languages_all">
					</div>
					<div class="clearfix"><p></p></div>
					<div class="docmargin">
						<button type="button" onclick="add_language();"  class="btn btn-sm tirtiary"><?php esc_html_e('Add Language More','finaluser'); ?></button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="margiv-top-10 save-change-button-content text-right">
		<div class="" id="update_message"></div>
		<button type="button" onclick="update_profile_setting();"  class="btn-new btn-custom"><?php  esc_html_e('Save Changes','finaluser');?></button>
	</div>
</form>