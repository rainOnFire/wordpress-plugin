<h4>
	<?php esc_html_e('Comments & Feedback','finaluser'); ?>
</h4>
<hr>
<?php
	$args = array(
	'post_id' => $post_data->ID,
	'status' => 'all',
	'user_id' => $current_user->ID,
	'count' => false,
	'date_query' => null, 
	);
	$comments = get_comments($args);
	foreach($comments as $comment) :
?>
<div class="row">
	<div class="comment-author vcard col-md-2 ">
		<?php
			$image_profile=get_user_meta($current_user->ID, 'iv_profile_pic_url',true);
		?>
		<img class="img-circle" src="<?php echo esc_url($image_profile); ?>" >
	</div>
	<div class="col-md-10">
		<div class="col-md-12">
			<?php echo esc_html($comment->comment_author); ?>
		</div>
		<div class="col-md-12">
			<small><?php echo esc_html($comment->comment_date); ?></small>
		</div>
		<div class="col-md-12">
			<?php echo esc_html($comment->comment_content); ?>
		</div>
	</div>
</div>
<hr/>
<?php
	$args2 = array(
	'status' => 'all',
	'parent' => $comment->comment_ID,
	);
	$comments2 = get_comments($args2);
	foreach($comments2 as $child_comment) {
		$childuser = get_user_by( 'email', $child_comment->comment_author_email);
		$cuserId = $childuser->ID;
	?>
	<div class="row">
		<div class="comment-author vcard col-md-2 ">
			<?php
				$image_profile=get_user_meta($cuserId, 'iv_profile_pic_url',true);
			?>
			<img class="img-circle" src="<?php echo esc_url($image_profile); ?>" >
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<?php echo esc_html($child_comment->comment_author); ?>
			</div>
			<div class="col-md-12">
				<small><?php echo esc_html($child_comment->comment_date); ?></small>
			</div>
			<div class="col-md-12">
				<?php echo esc_html($child_comment->comment_content); ?>
			</div>
		</div>
	</div>
	<hr/>
	<?php
	}
	endforeach;
?>
<?php
	$comments_args = array(		
	'label_submit' => esc_html__(  'Send', 'finaluser' ),		
	'title_reply'=>'',
	'logged_in_as'=>'',
	'comment_field' => '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Any comments or feedback (Only you & expert will view)?', 'finaluser' ) . '</label><br /><textarea id="comment" name="comment" aria-required="true"></textarea></p>',
	);
	comment_form( $comments_args, $post_data->ID );
	
	wp_enqueue_script('finaluser-private-comments', finaluser_URLPATH.'admin/files/js/private-comments.js', array('jquery'), $ver = true, true );
	wp_localize_script('finaluser-private-comments', 'tiger_data', array( 
	'ajaxurl' 		=> admin_url( 'admin-ajax.php' ),	
	'Processing'	=> esc_html__( "Processing",'finaluser'),
	'thanks'		=> esc_html__( "Thanks for your comment. We appreciate your response",'finaluser'),
	'pleasewait'	=> esc_html__( "Please wait a while before posting your next comment",'finaluser'),
	'quickly'		=> esc_html__( "Posting too quickly",'finaluser'),
	
	'finalwpnonce'	=>  wp_create_nonce("settings"),
	) );
?>