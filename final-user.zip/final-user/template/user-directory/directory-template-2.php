<?php
	wp_enqueue_script("jquery");	
	wp_enqueue_style('font-awesome', finaluser_URLPATH . 'admin/files/css/font-awesome/css/font-awesome.min.css');
	wp_enqueue_style('wp-ep_finaluser-style-15', finaluser_URLPATH . 'admin/files/css/ionicons.css');
	wp_enqueue_style('wp-ep_finaluser-style-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_script('ep_finaluser-script-12', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_style('wp-ep_finaluser-user-dir-style', finaluser_URLPATH .'admin/files/css/user-directory.css');
	require(finaluser_DIR .'/admin/files/css/color_style.php');
	wp_enqueue_style('wp-ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');
	global $wpdb;global $current_user;

	$city ='';
	if(isset($_REQUEST['city'])){
		$city = sanitize_text_field($_REQUEST['city']);
	}
	$search_user='';
	if(isset($_POST['search_user'])){
		$search_user = sanitize_text_field($_POST['search_user']);
	}
	if(isset($atts['per_page'])){
		$no=$atts['per_page'];
		}else{
		$no=24;
	}
 
	$column=4;
	$column_val=3;
	if(isset($atts['column']) and $atts['column']!=''){
		$column=$atts['column'];
		if($column==1){
			$column_val=12;
		}
		if($column==2){
			$column_val=6;
		}
		if($column==3){
			$column_val=4;
		}
		if($column==4){
			$column_val=3;
		}
	}
	$dir_display_status=get_option('_dir_display_status');
	if($dir_display_status==""){$dir_display_status='all';}
	$dir_listing_sort=get_option('_dir_listing_sort');
	if($dir_listing_sort==""){$dir_listing_sort='date';}
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	if($paged==1){
		$offset=0;
		}else {
		$offset= ($paged-1)*$no;
	}

	$args = array();
	$args['number']=$no;
	$args['offset']=$offset;
	$args['count_total']=true;
	if($dir_listing_sort=="DESC"){
		$args['orderby']='display_name';
		$args['order']='DESC';
	}
	if($dir_listing_sort=="ASC"){
		$args['orderby']='display_name';
		$args['order']='ASC';
	}
	if($dir_listing_sort=="date"){
		$args['orderby']='registered';
		$args['order']='DESC';
	}
	if($dir_listing_sort=="rand"){
		$args = array('orderby' => 'rand', );
	}
	// Meta Query***********************
	$city_mq ='';
	if(isset($_REQUEST['city']) AND $_REQUEST['city']!=''){ 
		$city_mq = array(
		'relation' => 'AND',
		array(
		'key'     => 'city',
		'value'   => $_REQUEST['city'],
		'compare' => 'LIKE'
		),
		);
	}
	$specialties='';
	if(isset($_REQUEST['specialties']) AND $_REQUEST['specialties']!=''){ 
		$specialties = array(
		'relation' => 'AND',
		array(
		'key'     => 'specialties',
		'value'   => $_REQUEST['specialties'],
		'compare' => 'LIKE'
		),
		);
	}
	$dir_display='';
	if($dir_display_status=='publish'){
		$dir_display = array(
		'relation' => 'AND',
		array(
		'key'     => 'ep_status',
		'value'   => 'publish',
		'compare' => '='
		),
		);
	}
	$args['meta_query'] = array(
	$city_mq, $specialties,$dir_display,
	);
	if($search_user!=''){
		$args['search']='*'.$search_user.'*';
	}
	$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
	$reg_page_user='';
	if($iv_redirect_user!='defult'){
		$reg_page_user= get_permalink( $iv_redirect_user) ;
	}
	if(isset($atts['role'])){
		$args['role']=$atts['role'];
	}
	
	$user_query = new WP_User_Query( $args );
?>
<div id="directory-temp" class="bootstrap-wrapper user-directory-content user-information-area">
	<form name="search_form" id="search_form">
		<div class="directory_search_bar">
			<i class="ion-android-locate"></i>
			<div class="directory_search_bar__location">
				<input maxlength="100" id="city" name="city" type="text" placeholder="<?php esc_html_e('Enter a city','finaluser'); ?>" value="<?php echo esc_html($city);?>" >
			</div>
			<div class="directory_search_bar__specialty">
				<div class="directory_search_bar__specialty_selector js-selector">
					<p>
						<?php
							$specialties='';
							if(isset($_REQUEST['specialties']) AND $_REQUEST['specialties']!=''){
								$specialties=$_REQUEST['specialties'];
								if($specialties=='0'){
									$specialties=esc_html__('Specialties', 'finaluser');
								}
							}
							if($specialties==''){ ?>
							<span id="selected_specialty"><?php  esc_html_e('Specialties', 'finaluser'); ?></span>
							<?php
							}else{?>
							<span id="selected_specialty"><?php echo esc_html($specialties); ?></span>
							<?php
							}
						?>
					<i class="ion-ios-arrow-down"></i></p>
					<input type="hidden" id="specialties" name="specialties" value="<?php echo esc_html($specialties); ?>">
					<div class="specialties-popover" id="all_specialties">
						<div class="qtip-tip">
							<canvas class="canwidth" width="40" height="20">
							</canvas>
						</div>
						<div class="directory_specialty_selector__specialty--all" >
							<?php  esc_html_e('All specialties', 'finaluser'); ?>
						</div>
						<div class="popover-main-content">
							<ul class="directory_specialty_selector__specialties_list specialties_list" id="specialties_list">
								<?php
									$Specialities =esc_html__( 'Aerial, Architecture, Automotive, Event, Fashion, Food, Interior, Lifestye, Maternity, Newborns, Nature,Land','finaluser');
									$field_set=get_option('_dir_specialties' );
									if($field_set!=""){
										$Specialities=get_option('_dir_specialties' );
									}
									$i=1;
									$Specialities_fields= explode(",",$Specialities);
									foreach ( $Specialities_fields as $field_value ) { ?>
									<li>
										<?php echo esc_html($field_value); ?>
									</li>
									<?php
									}
								?>
								<li>
									<strong><?php  esc_html_e('RESET', 'finaluser'); ?></strong>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
	<section class="main">
		<ul class="ch-grid row">
			<?php
				$listing_author_link=get_option('listing_author_link');
				if($listing_author_link==""){$listing_author_link='author';}
				if ( ! empty( $user_query->results ) ) {
					foreach ( $user_query->results as $user ) {
						$banner_image='';$banner_image_id='';
						if (isset($user->wp_capabilities['administrator'])!=1 ){
							if($listing_author_link=='author'){
								$reg_page_u= get_author_posts_url($user->ID);
								}else{
								$reg_page_u=$reg_page_user.'?&id='.$user->ID;
							}
							$iv_profile_pic_url='';
							$iv_profile_pic_url= $this->get_iv_user_image($user->ID);
							$banner_image_id=get_user_meta($user->ID, 'ivfinaluser_background_id', true);
							if($banner_image_id!=""){
								$banner_image=wp_get_attachment_image_src($banner_image_id,"medium")[0];
								}else{
								$banner_image=get_user_meta($user->ID, 'iv_background_pic_url',true);
							}
							if($banner_image==""){
								$banner_image='';
								$banner_image=finaluser_URLPATH.'assets/images/version-4bg.jpg';
							}
						?>
						<li class="col-md-<?php echo esc_html($column_val);?>  col-sm-<?php echo esc_html($column_val);?>  col-sx-12">
							<div class="dir-single">
								<div class="ch-item">
									<a href="<?php echo esc_url($reg_page_u); ?>">
										<div class="top-image" style=" background: url(<?php echo esc_url($banner_image); ?>) center center no-repeat;"></div>
										<div class="user-profile-pic" style="background: url(<?php echo esc_url($iv_profile_pic_url); ?>) center center no-repeat;">
										</div>
										<div class="ch-info">
										</div>
									</a>
								</div>
								<div class="user-content">
									<a href="<?php echo esc_url($reg_page_u); ?>" class="user-dir-name">
										<?php
											$name_display='';
											$name_display=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
											echo (trim($name_display)!=""? $name_display :  $user->display_name );
										?>
									</a>
									<p class="followers text-center">
										<?php
											$socialnetwork_value='';
											$socialnetwork_value = get_user_meta($user->ID,'_follower',true);
											$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
											$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
											$profile_follow=get_option('_profile_follow');
											if($profile_follow==""){$profile_follow='show';}
											if($profile_follow=="show"){
												echo sizeof($socialnetwork_value_arr);?> <?php echo esc_html_e(' Followers', 'finaluser');
											}
										?>
									</p>
									<p class="followers text-center">
										<?php
											$profile_email=get_option('_arch_emailaddress');
											if($profile_email==""){$profile_email='yes';}
											if($profile_email=="yes"){
											?>
											<a href="mailto:<?php echo esc_html($user->user_email);?>"><i class="fa fa-envelope"></i> <?php echo esc_html($user->user_email);?> </a>
											<?php
											}
										?>
									</p>
									<p class="followers text-center">
										<?php
											$profile_phone=get_option('_arch_user_phone');
											if($profile_phone==""){$profile_phone='yes';}
											if($profile_phone=="yes"){
												if(get_user_meta($user->ID,'phone',true)!=''){
												?>
												<?php echo'<a href="tel:'.get_user_meta($user->ID,'phone',true).'"><i class="fa fa-phone-square"></i> '.get_user_meta($user->ID,'phone',true).'</a>'; ?>
												<?php
												}
											}
										?>
										&nbsp;
									</p>
									<div class="contact-btn">
										<?php
											$profile_contact=get_option('_profile_contact');
											if($profile_contact==""){$profile_contact='show';}
											if($profile_contact=="show"){
											?>
											<a href="#" class="hire-button"  onclick="call_popup('<?php echo esc_html($user->ID); ?>')" ><i class="fa fa-envelope"></i> <?php echo esc_html_e(' Contact', 'finaluser'); ?></a>
											<?php
											}
										?>
										<?php
											$profile_follow=get_option('_profile_follow');
											if($profile_follow==""){$profile_follow='show';}
											if($profile_follow=="show"){ ?>
											<span id="follow<?php echo esc_html($user->ID); ?>">
												<?php
													$current_user_ID = $current_user->ID;
													if($current_user_ID>0){
														$my_connect = get_user_meta($current_user_ID,'_following',true);
														$all_users = explode(",", $my_connect);
														if (in_array($user->ID, $all_users)) { ?>
														<a  class="tirtiary-button" onclick="save_unfollow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Following', 'finaluser'); ?></a>
														<?php
														}else{ ?>
														<a  class="tirtiary-button" onclick="save_follow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Follow', 'finaluser'); ?></a>
														<?php
														}
													}else{ ?>
													<a  class="tirtiary-button" onclick="save_follow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Follow', 'finaluser'); ?></a>
													<?php
													}
												?>
											</span>
											<?php
											}
										?>
									</div>
									<?php
									}
								}
								}else{
								esc_html_e( 'Sorry, no data matched your criteria.','finaluser' );
							}
						?>
					</div>
				</div>
			</li>
		</ul>
	</section>
  <!-- end conatct modal markup -->
	<div class="modal fade" id="myModalContact" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog follow-following-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				  <h4 class="modal-title" id="myModalLabel"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></h4>
				</div>
				<div class="modal-body">
				  <div class="modal-contact-form">
						<form action="#" id="contact_form_2" name="contact_form_2"  method="POST" >
							<div class="form-group">
								<label  for="Name"><?php esc_html_e( 'Name', 'finaluser' ); ?></label>
								<input id="subject" name ="subject" class="form-control" type="text">
							</div>
							<div class="form-group">
								<label  for="eamil"><?php esc_html_e( 'Email', 'finaluser' ); ?></label>
								<input name="email_address" id="email_address" class="form-control" type="email">
							</div>
							<div class="form-group">
								<label for="message"><?php esc_html_e( 'Message', 'finaluser' ); ?></label>
								<textarea name="message-content" id="message-content" class="form-control" cols="20" rows="5"></textarea>
							</div>
							<input type="hidden" name="dir_id" id="dir_id" value="">
						</form>
					</div>
				</div>
				
				<div class="modal-footer">
					<a onclick="contact_send_message_iv();" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></a>
					<div id="update_message_popup"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end conatct modal markup -->
<div class="text-center">
	<?php
		$total_user = $user_query->total_users;
		$total_pages=ceil($total_user/$no);
		echo '<div id="iv-pagination" class="iv-pagination">';
		echo paginate_links( array(
		'base' =>  '%_%'.'?&city='.$city,
		'format' => '?&paged=%#%',
		'prev_text' => esc_html__( '&laquo; Previous','finaluser'), 
		'next_text' => esc_html__( 'Next &raquo;','finaluser'), 
		'total' => $total_pages,
		'current' => $paged,
		'end_size' => 1,
		'mid_size' => 5,
		));
		echo '</div>';
	?>
</div>
<?php
	wp_enqueue_script('finaluser-single-profile-js', finaluser_URLPATH.'admin/files/js/single-profile.js', array('jquery'), $ver = true, true );
	wp_localize_script('finaluser-single-profile-js', 'tiger_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
	'current_user_id'	=>get_current_user_id(),
	'login_message'		=> esc_html__( 'Please login to remove favorite','finaluser'),
	'Add_to_Follow'		=> esc_html__( 'Add to Follow','finaluser'),
	'Login_claim'		=> esc_html__( 'Please login to Report/Claim The Profile','finaluser'),
	'login_follw'	=> esc_html__( "Please login to add follow",'finaluser'),
	'finalwpnonce'=>  wp_create_nonce("settings"),
	'following'=> esc_html__( "Following",'finaluser'),
	'follow'=> esc_html__( "Follow",'finaluser'),
	) );
?>
