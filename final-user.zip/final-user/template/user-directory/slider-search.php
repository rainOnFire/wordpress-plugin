<?php
	wp_enqueue_style('wp-ep_finaluser-style-111', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_style('wp-ep_finaluser-slider_inline', finaluser_URLPATH . 'admin/files/css/slider_search.css');
	wp_enqueue_script('ep_finaluser-script-122', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	$directory_url='';
	$user_dir_page = get_option( '_ep_finaluser_user_dir_page');
	$directory_url= get_permalink( $user_dir_page) ;
?>
<div class="bootstrap-wrapper ">
	<div class="row">
	<div class="slider-form-wrapper" >
		<form class="form-inline finaluser_form" method="POST"  action="<?php echo esc_url($directory_url); ?>" >			
				<div class="col-sm-5 finaluser_city">
					<div class="form-group m-0 p-0" >
						<input id="city" name="city" type="text" class="form-control form-control-lg" placeholder="<?php esc_html_e('Enter a city', 'finaluser'); ?>"  >
					</div>
				</div>
				<div class="col-sm-5 finaluser_speciality">
					<div class="form-group" >
						<select name="specialties"  id="specialties" class="form-control-solid" >
							<option selected="selected" value=""><?php esc_html_e('Choose a Specialty','finaluser'); ?></option>
							<?php	$Specialities =esc_html__( 'Aerial, Architecture, Automotive, Event, Fashion, Food, Interior, Lifestye, Maternity, Newborns, Nature,Land','finaluser');
								$field_set=get_option('_dir_specialties' );
								if($field_set!=""){
									$Specialities=get_option('_dir_specialties' );
								}
								$i=1;
								$Specialities_fields= explode(",",$Specialities);
								foreach ( $Specialities_fields as $field_value ) {?>
								<option class="some"  value="<?php echo esc_html($field_value); ?>" ><?php echo esc_html($field_value); ?></option>
								<?php
								}
							?>
						</select>
					</div>
				</div>
				<div class="col-sm-2 finaluser_submit">
					<div class="form-group" >
						<button id="submit" name="submit"  class="btn btn-block">
							<?php esc_html_e('Search','finaluser'); ?>
						</button>
					</div>
				</div>			
		</form>
	</div>
</div>
</div>
