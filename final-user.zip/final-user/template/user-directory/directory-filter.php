<?php
	wp_enqueue_style('font-awesome', finaluser_URLPATH . 'admin/files/css/font-awesome/css/font-awesome.min.css');
	wp_enqueue_style('wp-ep_finaluser-style-15', finaluser_URLPATH . 'admin/files/css/ionicons.css');
	wp_enqueue_style('wp-ep_finaluser-style-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_script('wp-ep_finaluser-script-12', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_style('wp-ep_finaluser-user-dir-style', finaluser_URLPATH .'admin/files/css/user-directory.css');
	require(finaluser_DIR .'/admin/files/css/color_style.php');
	wp_enqueue_style('wp-ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');
	global $wpdb;global $current_user;
	$listing_author_link=get_option('listing_author_link');
	if($listing_author_link==""){$listing_author_link='author';}
?>
<?php
	$city ='';
	if(isset($atts['city'])){
		$city = $atts['city'];
	}
	if(isset($atts['per_page'])){
		$no=$atts['per_page'];
		}else{
		$no=9999;
	}
	$dir_display_status=get_option('_dir_display_status');
	if($dir_display_status==""){$dir_display_status='publish';}
	$dir_listing_sort=get_option('_dir_listing_sort');
	if($dir_listing_sort==""){$dir_listing_sort='date';}
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	if($paged==1){
		$offset=0;
		}else {
		$offset= ($paged-1)*$no;
	}
	$args = array();
	$args['number']=$no;
	$args['offset']=$offset;
	$args['count_total']=true;
	
	if($dir_listing_sort=="DESC"){
		$args = array(
		'meta_key' => 'first_name',
		'orderby' => 'meta_value',
		'order' => 'DESC'
		);
	}
	if($dir_listing_sort=="ASC"){
		$args = array(
		'meta_key' => 'first_name',
		'orderby' => 'meta_value',
		'order' => 'ASC'
		);
	}
	if($dir_listing_sort=="date"){
		$args['orderby']='registered';
		$args['order']='DESC';
	}
	if(isset($atts['ids']) AND $atts['ids']!=''){
		$args['include']= $atts['ids'];
	}
	// Meta Query***********************
	$city_mq ='';
	if(isset($atts['city']) AND $atts['city']!=''){
		$city_mq = array(
		'relation' => 'AND',
		array(
		'key'     => 'city',
		'value'   => $atts['city'],
		'compare' => 'LIKE'
		),
		);
	}
	$specialty='';
	if(isset($atts['specialty']) AND $atts['specialty']!=''){
		$specialty = array(
		'relation' => 'AND',
		array(
		'key'     => 'specialties',
		'value'   => $atts['specialty'],
		'compare' => 'LIKE'
		),
		);
	}
	$dir_display='';
	if($dir_display_status=='publish'){
		$dir_display = array(
		'relation' => 'AND',
		array(
		'key'     => 'ep_status',
		'value'   => 'publish',
		'compare' => '='
		),
		);
	}
	$args['meta_query'] = array(
	$city_mq, $specialty,$dir_display,
	);
	$iv_redirect_user = get_option( '_ep_finaluser_profile_public_page');
	$reg_page_user='';
	if($iv_redirect_user!='defult'){
		$reg_page_user= get_permalink( $iv_redirect_user) ;
	}
	if(isset($atts['role'])){
		$args['role']=$atts['role'];
	}
	$user_query = new WP_User_Query( $args );
	$column=4;
	$column_val=3;
	if(isset($atts['column']) and $atts['column']!=''){
		$column=$atts['column'];
		if($column==1){
			$column_val=12;
		}
		if($column==2){
			$column_val=6;
		}
		if($column==3){
			$column_val=4;
		}
		if($column==4){
			$column_val=3;
		}
	}
?>
<div id="directory-temp" class="bootstrap-wrapper user-directory-content user-information-area">
	<section class="main">
		<ul class="ch-grid row">
			<?php				
      	 		if ( ! empty( $user_query->results ) ) {
      	 			foreach ( $user_query->results as $user ) {
      	 				if (isset($user->wp_capabilities['administrator'])!=1 ){
							$iv_profile_pic_url='';
							$iv_profile_pic_url= $this->get_iv_user_image($user->ID);
							if($listing_author_link=='author'){
								$reg_page_u= get_author_posts_url($user->ID);
								}else{
								$reg_page_u=$reg_page_user.'?&id='.$user->ID;
							}
							$profile_buddypress_image=get_option('_profile_buddypress_image');
							if($profile_buddypress_image==""){$profile_buddypress_image='pluginimage';}
							if($profile_buddypress_image=='pluginimage'){
							
								$banner_image=get_user_meta($user->ID, 'iv_background_pic_url',true);
								if($banner_image==""){
									$banner_image=finaluser_URLPATH.'assets/images/version-4bg.jpg';
								}
								}else{
								if(function_exists('bp_is_active')){
									$banner_image = bp_attachments_get_attachment( 'url', array( 'item_id' =>$user->ID) );
									if($banner_image==""){
										$banner_image=finaluser_URLPATH.'assets/images/version-4bg.jpg';
									}
								}
							}
						?>
						<li class="col-md-<?php echo esc_html($column_val);?> col-sm-<?php echo esc_html($column_val);?> col-sx-12">
							<div class="dir-single">
								<div class="ch-item">
									<a href="<?php echo esc_url($reg_page_u); ?>">
										<div class="top-image" style=" background: url('<?php echo esc_url($banner_image); ?>') center center no-repeat;"></div>
										<div class="user-profile-pic" style="background: url(<?php echo esc_url($iv_profile_pic_url); ?>) center center no-repeat;">
										</div>
										<div class="ch-info">
										</div>
									</a>
								</div>
								<div class="user-content">
									<a href="<?php echo esc_url($reg_page_u); ?>" class="user-dir-name">
										<?php
											$name_display=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
											echo (trim($name_display)!=""? $name_display :  $user->display_name );
										?>
									</a>
									<p class="followers text-center">
										<?php
											$socialnetwork_value='';
											$socialnetwork_value = get_user_meta($user->ID,'_follower',true);
											$socialnetwork_value_arr = array_filter( explode(',', $socialnetwork_value), 'strlen' );
											$socialnetwork_value_arr= array_filter(array_map('trim', $socialnetwork_value_arr));
											$profile_follow=get_option('_profile_follow');
											if($profile_follow==""){$profile_follow='show';}
											if($profile_follow=="show"){
												echo sizeof($socialnetwork_value_arr);?> <?php echo esc_html_e(' Followers', 'finaluser');
											}
										?>
									</p>
									<p class="followers text-center">
										<?php
											$profile_email=get_option('_arch_emailaddress');
											if($profile_email==""){$profile_email='yes';}
											if($profile_email=="yes"){
											?>
											<a href="mailto:<?php echo esc_html($user->user_email);?>"><i class="fa fa-envelope"></i> <?php echo esc_html($user->user_email);?> </a>
											<?php
											}
										?>
									</p>
									<p class="followers text-center">
										<?php
											$profile_phone=get_option('_arch_user_phone');
											if($profile_phone==""){$profile_phone='yes';}
											if($profile_phone=="yes"){
												if(get_user_meta($user->ID,'phone',true)!=''){
												?>
												<?php echo'<a href="tel:'.get_user_meta($user->ID,'phone',true).'"><i class="fa fa-phone-square"></i> '.get_user_meta($user->ID,'phone',true).'</a>'; ?>
												<?php
												}
											}
										?>
										&nbsp;
									</p>
									<div class="contact-btn">
										<?php
											$profile_contact=get_option('_profile_contact');
											if($profile_contact==""){$profile_contact='show';}
											if($profile_contact=="show"){
											?>
											<a href="#" class="hire-button"  onclick="call_popup('<?php echo esc_html($user->ID); ?>')" ><i class="fa fa-envelope"></i><?php echo esc_html_e('Contact', 'finaluser'); ?></a>
											<?php
											}
										?>
										<?php
											$profile_follow=get_option('_profile_follow');
											if($profile_follow==""){$profile_follow='show';}
											if($profile_follow=="show"){ ?>
											<span id="follow<?php echo esc_html($user->ID); ?>">
												<?php
													$current_user_ID = $current_user->ID;
													if($current_user_ID>0){
														$my_connect = get_user_meta($current_user_ID,'_following',true);
														$all_users = explode(",", $my_connect);
														if (in_array($user->ID, $all_users)) { ?>
														<a  class="tirtiary-button" onclick="save_unfollow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Following', 'finaluser'); ?></a>
														<?php
														}else{ ?>
														<a  class="tirtiary-button" onclick="save_follow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Follow', 'finaluser'); ?></a>
														<?php
														}
													}else{ ?>
													<a  class="tirtiary-button" onclick="save_follow_dir('<?php echo esc_html($user->ID); ?>')"><?php echo esc_html_e('Follow', 'finaluser'); ?></a>
													<?php
													}
												?>
											</span>
											<?php
											}
										?>
									</div>
									<?php
									}
								}
								}else{
							}
						?>
					</div>
				</div>
			</li>
		</ul>
	</section>	
	<div class="modal fade" id="myModalContact" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog follow-following-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></h4>
				</div>
				<div class="modal-body">
					<div class="modal-contact-form">
						<form action="#" id="contact_form_2" name="contact_form_2"  method="POST" >
							<div class="form-group">
								<label  for="Name"><?php esc_html_e( 'Name', 'finaluser' ); ?></label>
								<input id="subject" class="form-control"  name ="subject" type="text">
							</div>
							<div class="form-group">
								<label  for="eamil"><?php esc_html_e( 'Email', 'finaluser' ); ?></label>
								<input name="email_address" class="form-control"  id="email_address" type="email">
							</div>
							<div class="form-group">
								<label for="message"><?php esc_html_e( 'Message', 'finaluser' ); ?></label>
								<textarea name="message-content" class="form-control"  id="message-content"  cols="20" rows="5"></textarea>
							</div>
						</form>
					</div>
				</div>
				<input type="hidden" name="dir_id" id="dir_id" value="">
				<div class="modal-footer">
					<a onclick="contact_send_message_iv();" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'finaluser' ); ?></a>
					<div id="update_message_popup"></div>
				</div>
			</div>
		</div>
	</div>	
	<div class="text-center">
		<?php
			$total_user = $user_query->total_users;
			$total_pages=ceil($total_user/$no);
			echo '<div id="iv-pagination" class="iv-pagination">';
			echo paginate_links( array(
			'base' =>  '%_%'.'?&city='.$city, 
			'format' => '?&paged=%#%', 
			'prev_text' => esc_html__( '&laquo; Previous','finaluser'), 
			'next_text' => esc_html__( 'Next &raquo;','finaluser'), 
			'total' => $total_pages, 
			'current' => $paged, 
			'end_size' => 1,
			'mid_size' => 5,
			));
			echo '</div>';
		?>
	</div>
	<?php
		wp_enqueue_script('single-profile-js', finaluser_URLPATH.'admin/files/js/single-profile.js', array('jquery'), $ver = true, true );
		wp_localize_script('single-profile-js', 'tiger_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
		'loading_image'		=> '<img src="'.finaluser_URLPATH.'admin/files/images/loader.gif">',
		'current_user_id'	=>get_current_user_id(),
		'login_message'		=> esc_html__( 'Please login to remove favorite','finaluser'),
		'Add_to_Follow'		=> esc_html__( 'Add to Follow','finaluser'),
		'Login_claim'		=> esc_html__( 'Please login to Report/Claim The Profile','finaluser'),
		'login_follw'	=> esc_html__( "Please login to add follow",'finaluser'),
		'following'=> esc_html__( "Following",'finaluser'),
		'finalwpnonce'=>  wp_create_nonce("settings"),
		'follow'=> esc_html__( "Follow",'finaluser'),
		) );
	?>
</div>