<?php
	global $wpdb;

	// Enqueue Styles
	wp_enqueue_style('wp-ep_finaluser-style-signup-11', finaluser_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_style('profile-signup-style', finaluser_URLPATH . 'admin/files/css/profile-registration.css');
	wp_enqueue_style('ep_finaluser-inline', finaluser_URLPATH . 'admin/files/css/inline_css.css');

	// Enqueue Scripts
	wp_enqueue_script('ep_finaluser-script-signup-12', finaluser_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_script("jquery");
	wp_enqueue_script('jquery.form-validator', finaluser_URLPATH . 'admin/files/js/jquery.form-validator.js');
	wp_enqueue_script('fitness-script-30', finaluser_URLPATH . 'admin/files/js/signup.js');

	// Include color style
	require(finaluser_DIR .'/admin/files/css/color_style.php');

	// Initialize variables
	$api_currency = get_option('_ep_finaluser_api_currency', 'USD');
	$iv_gateway = get_option('ep_finaluser_payment_gateway', 'paypal-express');
	$package_id = isset($_REQUEST['package_id']) ? $_REQUEST['package_id'] : '0';

	if($iv_gateway == 'paypal-express') {
		$post_name = 'ep_finaluser_paypal_setting';
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = %s", $post_name));
		$paypal_id = isset($row->ID) ? $row->ID : '0';
		$api_currency = get_post_meta($paypal_id, 'ep_finaluser_paypal_api_currency', true);
	}

	if($package_id != '0') {
		$recurring = get_post_meta($package_id, 'ep_finaluser_package_recurring', true);
		$package_amount = $recurring == 'on' ?
			get_post_meta($package_id, 'ep_finaluser_package_recurring_cost_initial', true) :
			get_post_meta($package_id, 'ep_finaluser_package_cost', true);

		if(empty($package_amount)) {
			$iv_gateway = 'paypal-express';
		}
	}

	$form_meta_data = get_post_meta($package_id, 'ep_finaluser_content', true);
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE id = %s", $package_id));

	$package_name = isset($row->post_title) ? $row->post_title : '';
	$package_amount = get_post_meta($package_id, 'ep_finaluser_package_cost', true);

	$newpost_id = '';
	$post_name = 'ep_finaluser_stripe_setting';
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = %s", $post_name));
	if(isset($row->ID)) {
		$newpost_id = $row->ID;
	}

	$stripe_mode = get_post_meta($newpost_id, 'ep_finaluser_stripe_mode', true);
	$stripe_publishable = $stripe_mode == 'test' ?
		get_post_meta($newpost_id, 'ep_finaluser_stripe_publishable_test', true) :
		get_post_meta($newpost_id, 'ep_finaluser_stripe_live_publishable_key', true);
?>

<div class="registration-style user-information-area bootstrap-wrapper">
	<div class="container">
		<div id="iv-form3" class="col-md-12 user-information">
			<form id="ep_finaluser_registration" name="ep_finaluser_registration" class="form-horizontal" action="<?php the_permalink() ?>?package_id=<?php echo esc_html($package_id); ?>&payment_gateway=<?php echo esc_html($iv_gateway); ?>&iv-submit-listing=register" method="post" role="form">
				
				<!-- User Information Section -->
				<div class="">
					<h2 class="form-title"><?php esc_html_e('User Information', 'finaluser'); ?></h2>
					<div class="photo-setting-single">
						<div class="arrow"></div>
						<div class="form-content">
							<div class="row">
								<div class="col-md-12">
									<!-- Display Error Message if Exists -->
									<?php if(isset($_REQUEST['message-error'])): ?>
										<div class="row alert alert-info alert-dismissable" id='loading-2'>
											<a class="panel-close close" data-dismiss="alert">x</a>
											<?php echo sanitize_text_field($_REQUEST['message-error']); ?>
										</div>
									<?php endif; ?>

									<!-- Username Input -->
									<div class="form-group row">
										<label class="col-md-4"><?php esc_html_e('User Name', 'finaluser'); ?><span class="chili"></span><i class="fa fa-user"></i></label>
										<div class="col-md-8">
											<input type="text" class="form-control form-control-solid ctrl-textbox" name="iv_member_user_name" data-validation="length alphanumeric" data-validation-length="4-12" data-validation-error-msg="<?php esc_html_e('The user name has to be an alphanumeric value between 4-12 characters', 'finaluser'); ?>" placeholder="<?php esc_html_e('Enter User Name', 'finaluser'); ?>">
										</div>
									</div>

									<!-- Email Input -->
									<div class="form-group row">
										<label class="col-md-4"><?php esc_html_e('Email Address', 'finaluser'); ?><span class="chili"></span><i class="fa fa-envelope"></i></label>
										<div class="col-md-8">
											<input type="email" class="form-control form-control-solid ctrl-textbox" name="iv_member_email" data-validation="email" placeholder="<?php esc_html_e('Enter email address', 'finaluser'); ?>" data-validation-error-msg="<?php esc_html_e('Please enter a valid email address', 'finaluser'); ?>">
										</div>
									</div>

									<!-- Password Input -->
									<div class="form-group row">
										<label class="col-md-4"><?php esc_html_e('Password', 'finaluser'); ?><span class="chili"></span><i class="fa fa-key"></i></label>
										<div class="col-md-8">
											<input type="password" class="form-control form-control-solid ctrl-textbox" name="iv_member_password" placeholder="" data-validation="strength" data-validation-strength="2" data-validation-error-msg="<?php esc_html_e('The password is not strong enough', 'finaluser'); ?>">
										</div>
									</div>

									<!-- Custom Fields -->
									<?php
										$default_fields = get_option('ep_finaluser_profile_fields', array());
										$sign_up_array = get_option('ep_finaluser_signup_fields', array());
										$require_array = get_option('ep_finaluser_signup_require', array());

										foreach ($default_fields as $field_key => $field_value) {
											if(isset($sign_up_array[$field_key]) && $sign_up_array[$field_key] == 'yes') {
												$required = isset($require_array[$field_key]) && $require_array[$field_key] == 'yes';
												?>
												<div class="form-group row">
													<label class="col-md-4"><?php echo esc_html($field_value); ?><span class="<?php echo $required ? 'chili' : ''; ?>"></span></label>
													<div class="col-md-8">
														<input type="text" class="form-control form-control-solid ctrl-textbox" name="<?php echo esc_html($field_key); ?>" <?php echo $required ? 'data-validation="length" data-validation-length="2-100"' : ''; ?> placeholder="<?php echo esc_html__('Enter ', 'finaluser') . esc_html($field_value); ?>">
													</div>
												</div>
												<?php
											}
										}
									?>

									<!-- Submit Button (Hidden by default) -->
									<input type="hidden" name="hidden_form_name" id="hidden_form_name" value="ep_finaluser_registration">
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Payment Information Section -->
				<?php
					$sql = "SELECT * FROM $wpdb->posts WHERE post_type = 'ep_finaluser_pack' AND post_status='draft'";
					$membership_pack = $wpdb->get_results($sql);
					$total_package = count($membership_pack);

					if ($total_package > 0): ?>
						<div class="pt50">
							<h3 class="form-title"><?php esc_html_e('Payment Info', 'finaluser'); ?></h3>
							<div class="photo-setting-single">
								<div class="arrow"></div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-content user-information-content">
											<?php
												if ($iv_gateway == 'paypal-express') {
													include(finaluser_template . 'signup/paypal_form_2.php');
												} elseif ($iv_gateway == 'stripe') {
													include(finaluser_template . 'signup/iv_stripe_form_2.php');
												} elseif ($iv_gateway == 'woocommerce') {
													include(finaluser_template . 'signup/woocommerce.php');
												}
											?>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</form>
			</div>
		</div>
	</div>
</div>
