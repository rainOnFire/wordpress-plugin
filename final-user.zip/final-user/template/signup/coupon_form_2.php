<div id="coupon-div">
	<div class="row form-group">
		<label for="text" class="col-md-4"><?php  esc_html_e('Discount Coupon','finaluser');?></label>
		<div class="col-md-7 ">  <input type="text" class="form-control-solid" name="coupon_name" id="coupon_name" value="" placeholder="Enter Coupon Code">
		</div>
		<div class="col-md-1 pull-left" id="coupon-result">
		</div>
	</div>
	<div class="row">
		<label for="text" class="col-md-4 control-label"><?php  esc_html_e('(-) Discount','finaluser');?></label>
		<div class="col-md-8 " id="discount">
		</div>
	</div>
	<div class="row">
		<label for="text" class="col-md-4 control-label"><?php  esc_html_e('Total','finaluser');?></label>
		<div class="col-md-8" id="total"><label class="control-label">  <?php echo esc_html($package_amount).''.esc_html($api_currency); ?></label>
		</div>
	</div>
</div>