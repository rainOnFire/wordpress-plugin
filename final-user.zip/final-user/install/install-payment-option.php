<?php
update_option('ep_finaluser_payment_gateway', 'paypal-express' ); 
update_option('ep_finaluser_payment_terms', 'yes' ); 
update_option('ep_finaluser_price-table', 'style-1' ); 
update_option('_ep_finaluser_api_currency', 'USD' );
update_option('ep_finaluser_payment_terms_text', ' I have read & accept the Terms & Conditions' ); 


?>
