<?php
update_option('ep_finaluser_signup-template', 'signup-style-2'); 
update_option('ep_finaluser_profile-template', 'style-1' ); 
update_option('ep_finaluser_profile-public', 'style-2' ); 
update_option('ep_finaluser_post_approved', 'yes' ); 
update_option('_ep_finaluser_hide_admin_bar', 'yes' ); 


?>
